import 'package:hive/hive.dart';
import '../../domain/models/product.dart';

class ProductRepo {
  final Box<Product> box;
  ProductRepo(this.box);

  List<Product> all() => box.values.toList()..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  Product? getById(String id) => box.get(id);
  Future<void> upsert(Product p) => box.put(p.id, p);
  Future<void> remove(String id) => box.delete(id);
}
