import 'package:hive/hive.dart';

import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/stock_movement.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/app_settings.dart';

class Boxes {
  static const products = 'products';
  static const purchases = 'purchases';
  static const sales = 'sales';
  static const expenses = 'expenses';
  static const debts = 'debts';
  static const movements = 'movements';
  static const cash = 'cash';
  static const settings = 'settings';
}


Future<Box<Product>> openProducts() => Hive.openBox<Product>(Boxes.products);
Future<Box<Purchase>> openPurchases() => Hive.openBox<Purchase>(Boxes.purchases);
Future<Box<Sale>> openSales() => Hive.openBox<Sale>(Boxes.sales);
Future<Box<Expense>> openExpenses() => Hive.openBox<Expense>(Boxes.expenses);
Future<Box<Debt>> openDebts() => Hive.openBox<Debt>(Boxes.debts);

Future<Box<StockMovement>> openMovements() => Hive.openBox<StockMovement>(Boxes.movements);

Future<Box<CashEntry>> openCash() => Hive.openBox<CashEntry>(Boxes.cash);
Future<Box<AppSettings>> openSettings() => Hive.openBox<AppSettings>(Boxes.settings);