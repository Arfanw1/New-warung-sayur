import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../data/repositories/reporting.dart';
import '../../data/repositories/product_repo.dart';
import '../widgets/date_picker_field.dart';

class ReportsPage extends ConsumerStatefulWidget {
  const ReportsPage({super.key});

  @override
  ConsumerState<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends ConsumerState<ReportsPage> {
  DateTime start = DateTime.now().subtract(const Duration(days: 6));
  DateTime end = DateTime.now();

  // Step 2 (Performa): cache perhitungan laporan agar tab switch / rebuild kecil tidak menghitung ulang.
  String? _cacheKey;
  int _cacheSalesLen = -1;
  int _cacheExpLen = -1;
  int _cachePurLen = -1;
  int _cacheMovLen = -1;
  int _cacheDebtLen = -1;
  int _cacheProdLen = -1;

  ReportSummary? _cachedSummary;
  double _cachedTotalPurchase = 0;
  List<_ProdRow> _cachedProdRows = const [];
  List<_StockRow> _cachedStockRows = const [];
  double _cachedTotalStockValue = 0;
  double _cachedTotalPrincipal = 0;
  double _cachedTotalPaid = 0;
  double _cachedTotalRemaining = 0;
  int _cachedOpenCount = 0;
  double _cachedTotalLoss = 0;
  Map<String, double> _cachedLossByType = const {};
  Map<String, double> _cachedLossByProduct = const {};

  int _toEpochDay(DateTime dt) {
    final utc = DateTime.utc(dt.year, dt.month, dt.day);
    final base = DateTime.utc(1970, 1, 1);
    return utc.difference(base).inDays;
  }

  @override
  Widget build(BuildContext context) {
    final sales = ref.watch(salesBoxProvider).values;
    final expenses = ref.watch(expensesBoxProvider).values;
    final purchases = ref.watch(purchasesBoxProvider).values;
    final productsRepo = ref.watch(productRepoProvider);
    final productsAll = productsRepo.all();
    final debts = ref.watch(debtsBoxProvider).values;
    final backup = ref.watch(backupServiceProvider);

    final movements = ref.watch(movementsBoxProvider).values;

    final key = '${_toEpochDay(start)}-${_toEpochDay(end)}';
    final salesLen = sales.length;
    final expLen = expenses.length;
    final purLen = purchases.length;
    final movLen = movements.length;
    final debtLen = debts.length;
    final prodLen = productsAll.length;

    final needRecompute = _cacheKey != key ||
        _cacheSalesLen != salesLen ||
        _cacheExpLen != expLen ||
        _cachePurLen != purLen ||
        _cacheMovLen != movLen ||
        _cacheDebtLen != debtLen ||
        _cacheProdLen != prodLen;

    if (needRecompute) {
      _cacheKey = key;
      _cacheSalesLen = salesLen;
      _cacheExpLen = expLen;
      _cachePurLen = purLen;
      _cacheMovLen = movLen;
      _cacheDebtLen = debtLen;
      _cacheProdLen = prodLen;

      final s0 = _toEpochDay(start);
      final s1 = _toEpochDay(end);

      final salesInRange = sales.where((s) => s.dateEpochDay >= s0 && s.dateEpochDay <= s1);
      final expInRange = expenses.where((e) => e.dateEpochDay >= s0 && e.dateEpochDay <= s1);
      final purchasesInRange = purchases.where((p) => p.dateEpochDay >= s0 && p.dateEpochDay <= s1);

      final lossMoves = movements.where((m) =>
          m.type == 'adjust' && (m.lossType != null) && m.dateEpochDay >= s0 && m.dateEpochDay <= s1);

      // Tahap 10: ringkasan kerugian
      final lossByType = <String, double>{};
      final lossByProduct = <String, double>{};
      for (final m in lossMoves) {
        final t = m.lossType ?? 'lainnya';
        lossByType[t] = (lossByType[t] ?? 0) + m.lossAmount;
        lossByProduct[m.productId] = (lossByProduct[m.productId] ?? 0) + m.lossAmount;
      }
      final totalLoss = lossByType.values.fold<double>(0, (s, v) => s + v);
      _cachedTotalLoss = totalLoss;
      _cachedLossByType = lossByType;
      _cachedLossByProduct = lossByProduct;

      _cachedSummary = summarize(sales: salesInRange, expenses: expInRange);

      // Tahap 3: laporan per produk (berdasarkan penjualan)
      final map = <String, _ProdAgg>{};
      for (final s in salesInRange) {
        for (final it in s.items) {
          final a = map.putIfAbsent(it.productId, () => _ProdAgg());
          a.qty += it.qty;
          a.omzet += it.qty * it.sellPrice;
          a.hpp += it.qty * it.hppAtSale;
        }
      }
      final prodRows = map.entries.map((e) {
        final pr = productsRepo.getById(e.key);
        final name = pr?.name ?? e.key;
        final unit = pr?.unit ?? '';
        final a = e.value;
        return _ProdRow(
          productId: e.key,
          name: name,
          unit: unit,
          qty: a.qty,
          omzet: a.omzet,
          hpp: a.hpp,
        );
      }).toList();
      prodRows.sort((a, b) => b.laba.compareTo(a.laba));
      _cachedProdRows = prodRows;

      // Tahap 3: valuasi stok
      final stockRows = productsAll
          .map((p) => _StockRow(p.id, p.name, p.unit, p.stockQty, p.avgHpp, p.stockQty * p.avgHpp))
          .toList();
      stockRows.sort((a, b) => b.value.compareTo(a.value));
      _cachedStockRows = stockRows;
      _cachedTotalStockValue = stockRows.fold<double>(0, (s, r) => s + r.value);

      // Tahap 3: ringkasan hutang
      _cachedTotalPrincipal = debts.fold<double>(0, (s, d) => s + d.principal);
      _cachedTotalPaid = debts.fold<double>(0, (s, d) => s + d.paid);
      _cachedTotalRemaining = debts.fold<double>(0, (s, d) => s + d.remaining);
      _cachedOpenCount = debts.where((d) => !d.isSettled).length;

      // Tahap 3: ringkasan pembelian dalam range (untuk konteks laporan)
      _cachedTotalPurchase = purchasesInRange.fold<double>(
        0,
        (s, p) => s + p.items.fold<double>(0, (x, it) => x + it.qty * it.buyPrice),
      );
    }

    final summary = _cachedSummary ?? summarize(sales: const [], expenses: const []);
    final prodRows = _cachedProdRows;
    final stockRows = _cachedStockRows;
    final totalStockValue = _cachedTotalStockValue;
    final totalPrincipal = _cachedTotalPrincipal;
    final totalPaid = _cachedTotalPaid;
    final totalRemaining = _cachedTotalRemaining;
    final openCount = _cachedOpenCount;
    final totalPurchase = _cachedTotalPurchase;
    final totalLoss = _cachedTotalLoss;
    final lossByType = _cachedLossByType;
    final lossByProduct = _cachedLossByProduct;

    return DefaultTabController(
      length: 5,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(
              children: [
                Expanded(
                  child: DatePickerField(
                    value: start,
                    onChanged: (d) => setState(() => start = d),
                    label: 'Mulai',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DatePickerField(
                    value: end,
                    onChanged: (d) => setState(() => end = d),
                    label: 'Sampai',
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  tooltip: 'Export CSV detail',
                  icon: const Icon(Icons.share),
                  onPressed: () async {
                    await backup.shareReportDetailCsv(start: start, end: end);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('CSV detail dibagikan.')),
                      );
                    }
                  },
                )
              ],
            ),
          ),
          const SizedBox(height: 8),
          Material(
            color: Theme.of(context).colorScheme.surface,
            child: const TabBar(
              isScrollable: true,
              tabs: [
                Tab(text: 'Ringkasan'),
                Tab(text: 'Per Produk'),
                Tab(text: 'Valuasi Stok'),
                Tab(text: 'Hutang'),
                Tab(text: 'Kerugian'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              children: [
                _summaryTab(context, summary: summary, totalPurchase: totalPurchase),
                _productTab(context, rows: prodRows),
                _stockTab(context, rows: stockRows, totalValue: totalStockValue),
                _debtTab(context, totalPrincipal: totalPrincipal, totalPaid: totalPaid, totalRemaining: totalRemaining, openCount: openCount),
                _lossTab(context, totalLoss: totalLoss, lossByType: lossByType, lossByProduct: lossByProduct, productsRepo: productsRepo),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryTab(BuildContext context, {required ReportSummary summary, required double totalPurchase}) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Ringkasan', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _row('Omzet', fmtMoney(summary.omzet)),
                _row('Total HPP', fmtMoney(summary.totalHpp)),
                _row('Laba Kotor', fmtMoney(summary.labaKotor)),
                const Divider(),
                _row('Total Biaya', fmtMoney(summary.totalBiaya)),
                _row('Laba Bersih', fmtMoney(summary.labaBersih)),
                const Divider(),
                _row('Total Pembelian', fmtMoney(totalPurchase)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Tip: tombol share di kanan atas bisa export CSV detail untuk periode ini.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }

  Widget _productTab(BuildContext context, {required List<_ProdRow> rows}) {
    if (rows.isEmpty) {
      return const Center(child: Text('Belum ada penjualan pada periode ini.'));
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: rows.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final r = rows[i];
        return Card(
          child: ListTile(
            title: Text(r.name),
            subtitle: Text(
              'Qty: ${r.qty.toStringAsFixed(2)} ${r.unit}\nOmzet: ${fmtMoney(r.omzet)} • HPP: ${fmtMoney(r.hpp)}',
            ),
            isThreeLine: true,
            trailing: Text(
              fmtMoney(r.laba),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        );
      },
    );
  }

  Widget _stockTab(BuildContext context, {required List<_StockRow> rows, required double totalValue}) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _row('Total nilai persediaan', fmtMoney(totalValue)),
                const SizedBox(height: 6),
                Text('Nilai persediaan = stok × avg HPP', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        ...rows.map(
          (r) => Card(
            child: ListTile(
              title: Text(r.name),
              subtitle: Text(
                'Stok: ${r.qty.toStringAsFixed(2)} ${r.unit} • Avg HPP: ${fmtMoney(r.avgHpp)}',
              ),
              trailing: Text(fmtMoney(r.value), style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _debtTab(
    BuildContext context, {
    required double totalPrincipal,
    required double totalPaid,
    required double totalRemaining,
    required int openCount,
  }) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Ringkasan Hutang', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _row('Total Hutang', fmtMoney(totalPrincipal)),
                _row('Total Dibayar', fmtMoney(totalPaid)),
                const Divider(),
                _row('Sisa Hutang', fmtMoney(totalRemaining)),
                _row('Hutang belum lunas', '$openCount'),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// Tahap 10: tab ringkasan kerugian (susut/busuk/hilang)
  Widget _lossTab(
    BuildContext context, {
    required double totalLoss,
    required Map<String, double> lossByType,
    required Map<String, double> lossByProduct,
    required ProductRepo productsRepo,
  }) {
    final entriesType = lossByType.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final entriesProd = lossByProduct.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    String labelType(String t) {
      switch (t) {
        case 'susut':
          return 'Susut';
        case 'busuk':
          return 'Busuk';
        case 'hilang':
          return 'Hilang';
        default:
          return t;
      }
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Ringkasan Kerugian', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _row('Total kerugian', fmtMoney(totalLoss)),
                const Divider(),
                if (entriesType.isEmpty)
                  const Text('Belum ada kerugian pada periode ini.')
                else
                  ...entriesType.map((e) => _row(labelType(e.key), fmtMoney(e.value))),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text('Kerugian per produk', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (entriesProd.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Tidak ada data.')))
        else
          ...entriesProd.take(30).map((e) {
            final p = productsRepo.getById(e.key);
            final name = p?.name ?? e.key;
            return Card(
              child: ListTile(
                title: Text(name),
                subtitle: p == null ? null : Text('Unit: ${p.unit}'),
                trailing: Text(fmtMoney(e.value), style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
            );
          }),
      ],
    );
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(k), Text(v, style: const TextStyle(fontWeight: FontWeight.w600))],
        ),
      );
}

class _ProdAgg {
  double qty = 0;
  double omzet = 0;
  double hpp = 0;
}

class _ProdRow {
  final String productId;
  final String name;
  final String unit;
  final double qty;
  final double omzet;
  final double hpp;

  _ProdRow({
    required this.productId,
    required this.name,
    required this.unit,
    required this.qty,
    required this.omzet,
    required this.hpp,
  });

  double get laba => omzet - hpp;
}

class _StockRow {
  final String productId;
  final String name;
  final String unit;
  final double qty;
  final double avgHpp;
  final double value;

  _StockRow(this.productId, this.name, this.unit, this.qty, this.avgHpp, this.value);
}
