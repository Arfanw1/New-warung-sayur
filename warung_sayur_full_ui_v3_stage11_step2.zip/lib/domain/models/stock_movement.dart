class StockMovement {
  final String id;
  int dateEpochDay;
  String productId;

  /// type: purchase | sale | adjust
  String type;

  /// qtyDelta: + for in, - for out
  double qtyDelta;

  /// optional note/reason
  String note;

  /// lossType: susut | busuk | hilang (nullable). Only for adjust-out.
  String? lossType;

  /// lossAmount: nilai kerugian (qtyLoss * avgHpp saat itu). 0 jika tidak ada.
  double lossAmount;

  StockMovement({
    required this.id,
    required this.dateEpochDay,
    required this.productId,
    required this.type,
    required this.qtyDelta,
    required this.note,
    this.lossType,
    this.lossAmount = 0,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateEpochDay': dateEpochDay,
        'productId': productId,
        'type': type,
        'qtyDelta': qtyDelta,
        'note': note,
        'lossType': lossType,
        'lossAmount': lossAmount,
      };

  static StockMovement fromJson(Map<String, dynamic> j) => StockMovement(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        productId: j['productId'] as String,
        type: j['type'] as String,
        qtyDelta: (j['qtyDelta'] as num).toDouble(),
        note: j['note'] as String? ?? '',
        lossType: j['lossType'] as String?,
        lossAmount: (j['lossAmount'] as num?)?.toDouble() ?? 0,
      );
}
