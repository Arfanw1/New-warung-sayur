import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../providers.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/product.dart';

class FastPosPage extends ConsumerStatefulWidget {
  const FastPosPage({super.key});

  @override
  ConsumerState<FastPosPage> createState() => _FastPosPageState();
}

class _FastPosPageState extends ConsumerState<FastPosPage> {
  final qC = TextEditingController();
  final Map<String, double> cart = {}; // productId -> qty
  String paymentMethod = 'Cash';

  @override
  void dispose() {
    qC.dispose();
    super.dispose();
  }

  void _add(String productId) {
    setState(() {
      cart[productId] = (cart[productId] ?? 0) + 1.0;
    });
  }

  void _remove(String productId) {
    setState(() {
      final v = (cart[productId] ?? 0) - 1.0;
      if (v <= 0) {
        cart.remove(productId);
      } else {
        cart[productId] = v;
      }
    });
  }

  double _total(List<Product> products) {
    double sum = 0;
    for (final e in cart.entries) {
      final p = products.firstWhere((x) => x.id == e.key);
      sum += e.value * p.activeSellPrice;
    }
    return sum;
  }

  Future<void> _checkout(List<Product> products) async {
    if (cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Keranjang kosong.')));
      return;
    }

    final res = await showModalBottomSheet<_CheckoutResult>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _CartSheet(
        products: products,
        cart: Map<String, double>.from(cart),
        paymentMethod: paymentMethod,
      ),
    );

    if (res == null) return;

    // apply edits from sheet
    setState(() {
      cart
        ..clear()
        ..addAll(res.cart);
      paymentMethod = res.paymentMethod;
    });
    final salesRepo = ref.read(salesRepoProvider);
    final prodRepo = ref.read(productRepoProvider);

    final items = <SaleItem>[];
    for (final e in res.cart.entries) {
      final p = prodRepo.getById(e.key);
      if (p == null) continue;
      items.add(SaleItem(
        productId: p.id,
        qty: e.value,
        sellPrice: p.activeSellPrice,
        hppAtSale: p.avgHpp,
      ));
    }
    final sale = Sale(
      id: newId('sl'),
      dateEpochDay: epochDay(DateTime.now()),
      items: items,
      paymentMethod: res.paymentMethod,
    );

    try {
      await salesRepo.add(sale);
      if (!mounted) return;
      setState(() => cart.clear());
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Transaksi tersimpan.')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final productsBox = ref.watch(productsBoxProvider);
    final products = productsBox.values.toList()..sort((a, b) => a.name.compareTo(b.name));
    final q = qC.text.trim().toLowerCase();
    final filtered = q.isEmpty
        ? products
        : products.where((p) => p.name.toLowerCase().contains(q)).toList();

    final total = cart.isEmpty ? 0.0 : _total(products);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Fast Mode Kasir'),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'Metode pembayaran',
            onSelected: (v) => setState(() => paymentMethod = v),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'Cash', child: Text('Cash')),
              PopupMenuItem(value: 'QRIS', child: Text('QRIS')),
              PopupMenuItem(value: 'Transfer', child: Text('Transfer')),
              PopupMenuItem(value: 'Hutang', child: Text('Hutang')),
            ],
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  const Icon(Icons.payments_outlined),
                  const SizedBox(width: 6),
                  Text(paymentMethod),
                ],
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: TextField(
              controller: qC,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'Cari produk...',
                suffixIcon: q.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () => setState(() => qC.clear()),
                      ),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 1.05,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              itemCount: filtered.length,
              itemBuilder: (_, i) {
                final p = filtered[i];
                final qty = cart[p.id] ?? 0;
                return InkWell(
                  onTap: () => _add(p.id),
                  onLongPress: qty > 0 ? () => _remove(p.id) : null,
                  borderRadius: BorderRadius.circular(14),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis),
                          const Spacer(),
                          Text(fmtMoney(p.activeSellPrice), style: Theme.of(context).textTheme.titleSmall),
                          if (qty > 0)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text('Qty: ${qty.toStringAsFixed(0)}',
                                  style: Theme.of(context).textTheme.bodySmall),
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              decoration: BoxDecoration(
                border: Border(top: BorderSide(color: Theme.of(context).dividerColor)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Total: ${fmtMoney(total)}',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: () => _checkout(products),
                    icon: const Icon(Icons.check_circle_outline),
                    label: const Text('Bayar'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CheckoutResult {
  final Map<String, double> cart;
  final String paymentMethod;
  const _CheckoutResult(this.cart, this.paymentMethod);
}

class _CartSheet extends StatefulWidget {
  final List<Product> products;
  final Map<String, double> cart;
  final String paymentMethod;

  const _CartSheet({
    required this.products,
    required this.cart,
    required this.paymentMethod,
  });

  @override
  State<_CartSheet> createState() => _CartSheetState();
}

class _CartSheetState extends State<_CartSheet> {
  late Map<String, double> cart;
  late String paymentMethod;

  @override
  void initState() {
    super.initState();
    cart = Map<String, double>.from(widget.cart);
    paymentMethod = widget.paymentMethod;
  }

  double get total {
    double sum = 0;
    for (final e in cart.entries) {
      final p = widget.products.firstWhere((x) => x.id == e.key);
      sum += e.value * p.activeSellPrice;
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) {
    final entries = cart.entries.toList();

    return Padding(
      padding: EdgeInsets.only(
        left: 12,
        right: 12,
        top: 12,
        bottom: 12 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Keranjang', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Row(
            children: [
              const Text('Pembayaran:'),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: paymentMethod,
                items: const [
                  DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                  DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
                  DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                  DropdownMenuItem(value: 'Hutang', child: Text('Hutang')),
                ],
                onChanged: (v) => setState(() => paymentMethod = v ?? 'Cash'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (entries.isEmpty)
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text('Keranjang kosong.'),
            )
          else
            Flexible(
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: entries.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final pid = entries[i].key;
                  final qty = entries[i].value;
                  final p = widget.products.firstWhere((x) => x.id == pid);
                  return ListTile(
                    title: Text(p.name),
                    subtitle: Text(fmtMoney(p.activeSellPrice)),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove_circle_outline),
                          onPressed: () => setState(() {
                            final v = (cart[pid] ?? 0) - 1.0;
                            if (v <= 0) {
                              cart.remove(pid);
                            } else {
                              cart[pid] = v;
                            }
                          }),
                        ),
                        Text(qty.toStringAsFixed(0)),
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline),
                          onPressed: () => setState(() {
                            cart[pid] = (cart[pid] ?? 0) + 1.0;
                          }),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text('Total: ${fmtMoney(total)}', style: Theme.of(context).textTheme.titleMedium),
              ),
              ElevatedButton(
                onPressed: entries.isEmpty
                    ? null
                    : () => Navigator.pop(context, _CheckoutResult(cart, paymentMethod)),
                child: const Text('Simpan'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
