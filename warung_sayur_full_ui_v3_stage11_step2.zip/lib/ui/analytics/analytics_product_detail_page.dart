import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../core/dates.dart';
import '../../providers.dart';
import '../../data/services/analytics_service.dart';

class AnalyticsProductDetailPage extends ConsumerStatefulWidget {
  final String productId;
  final DateTime start;
  final DateTime end;

  const AnalyticsProductDetailPage({
    super.key,
    required this.productId,
    required this.start,
    required this.end,
  });

  @override
  ConsumerState<AnalyticsProductDetailPage> createState() => _AnalyticsProductDetailPageState();
}

class _AnalyticsProductDetailPageState extends ConsumerState<AnalyticsProductDetailPage> {
  // Step 2 (Performa): cache hasil hitung detail produk.
  String? _cacheKey;
  int _cacheSalesLen = -1;
  int _cacheProductsLen = -1;
  ProductKpi? _kpi;
  List<DayPoint> _revTrend = const [];
  List<DayPoint> _qtyTrend = const [];
  List<({int day, double qty, double price, double hppAtSale, double total})> _rows = const [];

  @override
  Widget build(BuildContext context) {
    final salesBox = ref.watch(salesBoxProvider);
    final productsBox = ref.watch(productsBoxProvider);
    final service = const AnalyticsService();

    final key = '${widget.productId}:${epochDay(widget.start)}-${epochDay(widget.end)}';
    final salesLen = salesBox.length;
    final productsLen = productsBox.length;
    if (_cacheKey != key || _cacheSalesLen != salesLen || _cacheProductsLen != productsLen) {
      _cacheKey = key;
      _cacheSalesLen = salesLen;
      _cacheProductsLen = productsLen;

      _kpi = service.productKpi(salesBox, productsBox, widget.productId, widget.start, widget.end);
      _revTrend = service.productRevenueTrend(salesBox, widget.productId, widget.start, widget.end);
      _qtyTrend = service.productQtyTrend(salesBox, widget.productId, widget.start, widget.end);
      _rows = service.productSalesRows(salesBox, widget.productId, widget.start, widget.end, limit: 20);
    }

    final p = productsBox.get(widget.productId);
    final kpi = _kpi ??
        ProductKpi(productId: widget.productId, name: p?.name ?? widget.productId, qty: 0, revenue: 0, hpp: 0, profit: 0);

    final title = p?.name ?? kpi.name;
    final unit = p?.unit ?? '';
    // Hive fields may be `num`; normalize to double for calculations + widgets.
    final double sell = (p?.activeSellPrice ?? 0).toDouble();
    final double hppNow = (p?.avgHpp ?? 0).toDouble();
    final double marginNow = sell <= 0 ? 0.0 : ((sell - hppNow) / sell) * 100.0;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title),
            Text(
              '${fmtDate(widget.start)} → ${fmtDate(widget.end)}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _KpiCards(
            revenue: kpi.revenue,
            profit: kpi.profit,
            qty: kpi.qty,
            unit: unit,
            marginPercent: kpi.marginPercent,
          ),
          const SizedBox(height: 12),
          _CurrentPricingCard(
            sellPrice: sell,
            hpp: hppNow,
            marginPercent: marginNow,
          ),
          const SizedBox(height: 12),
          Text('Tren Omzet', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          _LineChart(points: _revTrend),
          const SizedBox(height: 16),
          Text('Tren Qty Terjual', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          _LineChart(points: _qtyTrend),
          const SizedBox(height: 16),
          Text('Transaksi Terakhir', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (_rows.isEmpty)
            const Text('Belum ada transaksi pada rentang ini.')
          else
            ..._rows.map((r) {
              final d = fromEpochDay(r.day);
              final profit = (r.total - (r.qty * r.hppAtSale));
              return Card(
                child: ListTile(
                  title: Text('${fmtDate(d)} • Qty ${r.qty.toStringAsFixed(2)} $unit'),
                  subtitle: Text('Harga: ${fmtMoney(r.price)} • HPP: ${fmtMoney(r.hppAtSale)}'),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(fmtMoney(r.total)),
                      Text('Laba: ${fmtMoney(profit)}', style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _KpiCards extends StatelessWidget {
  final double revenue;
  final double profit;
  final double qty;
  final String unit;
  final double marginPercent;

  const _KpiCards({
    required this.revenue,
    required this.profit,
    required this.qty,
    required this.unit,
    required this.marginPercent,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: _MiniCard(title: 'Omzet', value: fmtMoney(revenue))),
        const SizedBox(width: 8),
        Expanded(child: _MiniCard(title: 'Laba', value: fmtMoney(profit))),
        const SizedBox(width: 8),
        Expanded(child: _MiniCard(title: 'Qty', value: '${qty.toStringAsFixed(2)} $unit')),
      ],
    );
  }
}

class _CurrentPricingCard extends StatelessWidget {
  final double sellPrice;
  final double hpp;
  final double marginPercent;

  const _CurrentPricingCard({
    required this.sellPrice,
    required this.hpp,
    required this.marginPercent,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Harga Saat Ini', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            _row('Harga jual', fmtMoney(sellPrice)),
            _row('Avg HPP', fmtMoney(hpp)),
            _row('Margin', '${marginPercent.toStringAsFixed(1)}%'),
          ],
        ),
      ),
    );
  }
}

class _MiniCard extends StatelessWidget {
  final String title;
  final String value;

  const _MiniCard({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.titleMedium),
          ],
        ),
      ),
    );
  }
}

Widget _row(String a, String b) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [Text(a), Text(b, style: const TextStyle(fontWeight: FontWeight.w700))],
    ),
  );
}

class _LineChart extends StatelessWidget {
  final List<DayPoint> points;
  const _LineChart({required this.points});

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) {
      return const SizedBox(height: 160, child: Center(child: Text('Belum ada data.')));
    }

    final maxY = points.fold<double>(0, (m, p) => p.value > m ? p.value : m);
    final spots = <FlSpot>[];
    for (int i = 0; i < points.length; i++) {
      spots.add(FlSpot(i.toDouble(), points[i].value));
    }

    return SizedBox(
      height: 180,
      child: LineChart(
        LineChartData(
          minY: 0,
          maxY: maxY <= 0 ? 1 : maxY * 1.1,
          gridData: const FlGridData(show: true),
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: true),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              dotData: const FlDotData(show: false),
            ),
          ],
        ),
      ),
    );
  }
}
