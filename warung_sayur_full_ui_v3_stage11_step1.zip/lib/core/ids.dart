import 'dart:math';
String newId([String prefix = 'id']) {
  final r = Random();
  final ts = DateTime.now().millisecondsSinceEpoch;
  final x = r.nextInt(1 << 32);
  return '$prefix-$ts-$x';
}
