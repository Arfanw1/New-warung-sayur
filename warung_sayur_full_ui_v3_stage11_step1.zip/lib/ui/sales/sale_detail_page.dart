import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../data/services/receipt_service.dart';
import 'sale_form.dart';

class SaleDetailPage extends ConsumerWidget {
  final String saleId;
  const SaleDetailPage({super.key, required this.saleId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final salesBox = ref.watch(salesBoxProvider);
    final sale = salesBox.get(saleId);
    final productsRepo = ref.watch(productRepoProvider);
    final repo = ref.watch(salesRepoProvider);
    final productsById = {
      for (final p in productsRepo.all()) p.id: p,
    };

    if (sale == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Detail Penjualan')),
        body: const Center(child: Text('Data penjualan tidak ditemukan.')),
      );
    }

    final totalQty = sale.items.fold<double>(0, (s, it) => s + it.qty);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Penjualan'),
        actions: [
          IconButton(
            tooltip: 'Edit penjualan',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => SaleFormPage(initial: sale)),
              );
            },
          ),
          IconButton(
            tooltip: 'Share struk (teks)',
            icon: const Icon(Icons.share),
            onPressed: () => ReceiptService.shareSaleText(sale: sale, productsById: productsById),
          ),
          IconButton(
            tooltip: 'Share struk (PDF)',
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: () => ReceiptService.shareSalePdf(sale: sale, productsById: productsById),
          ),
          IconButton(
            tooltip: 'Hapus penjualan',
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Hapus penjualan?'),
                  content: const Text('Stok dan riwayat akan di-rollback otomatis.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                    FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                  ],
                ),
              );
              if (ok != true) return;
              await repo.remove(sale.id);
              if (context.mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('Penjualan dihapus')));
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Tanggal', style: Theme.of(context).textTheme.labelMedium),
                  const SizedBox(height: 4),
                  Text(fmtDateFromEpochDay(sale.dateEpochDay),
                      style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text('Item', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ...sale.items.map((it) {
            final pr = productsRepo.getById(it.productId);
            final name = pr?.name ?? 'Produk';
            final unit = pr?.unit ?? '';
            final subTotal = it.qty * it.sellPrice;
            final subHpp = it.qty * it.hppAtSale;
            final subProfit = subTotal - subHpp;
            return Card(
              child: ListTile(
                title: Text(name),
                subtitle: Text(
                  '${it.qty.toStringAsFixed(2)} $unit × ${fmtMoney(it.sellPrice)}\nHPP: ${fmtMoney(it.hppAtSale)}',
                ),
                isThreeLine: true,
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(fmtMoney(subTotal), style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(fmtMoney(subProfit), style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
            );
          }),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _row('Total Qty', totalQty.toStringAsFixed(2)),
                  const SizedBox(height: 8),
                  _row('Omzet', fmtMoney(sale.totalSales)),
                  const SizedBox(height: 8),
                  _row('Total HPP', fmtMoney(sale.totalHpp)),
                  const Divider(),
                  _row('Laba Kotor', fmtMoney(sale.totalSales - sale.totalHpp)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String k, String v) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(k), Text(v, style: const TextStyle(fontWeight: FontWeight.w700))],
      );
}
