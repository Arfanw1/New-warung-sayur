import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:csv/csv.dart';

import '../db/hive_boxes.dart';
import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/stock_movement.dart';
import '../../core/ids.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/app_settings.dart';
import '../repositories/meta_repo.dart';
import '../repositories/activity_log_repo.dart';

class BackupService {
  final Box<Product> products;
  final Box<Purchase> purchases;
  final Box<Sale> sales;
  final Box<Expense> expenses;
  final Box<Debt> debts;
  final Box<StockMovement> movements;
  final Box<CashEntry> cash;
  final Box<AppSettings> settings;

  BackupService({
    required this.products,
    required this.purchases,
    required this.sales,
    required this.expenses,
    required this.debts,
    required this.movements,
    required this.cash,
    required this.settings,
  });

  Map<String, dynamic> _snapshot() => {
        Boxes.products: products.values.map((e) => e.toJson()).toList(),
        Boxes.purchases: purchases.values.map((e) => e.toJson()).toList(),
        Boxes.sales: sales.values.map((e) => e.toJson()).toList(),
        Boxes.expenses: expenses.values.map((e) => e.toJson()).toList(),
        Boxes.debts: debts.values.map((e) => e.toJson()).toList(),
        Boxes.movements: movements.values.map((e) => e.toJson()).toList(),
        Boxes.cash: cash.values
            .map((e) => {
                  'id': e.id,
                  'dateEpochDay': e.dateEpochDay,
                  'direction': e.direction,
                  'source': e.source,
                  'method': e.method,
                  'note': e.note,
                  'amount': e.amount,
                  'refId': e.refId,
                })
            .toList(),
        Boxes.settings: settings.values
            .map((s) => {
                  'id': s.id,
                  'pinEnabled': s.pinEnabled,
                  'pinHash': s.pinHash,
                })
            .toList(),
        '_meta': {'app': 'warung_sayur', 'ts': DateTime.now().toIso8601String(), 'version': 2}
      };

  Future<File> createBackupFile() async {
    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${dir.path}/warung_sayur_backup_$ts.json');
    await f.writeAsString(jsonEncode(_snapshot()));
    return f;
  }

  Future<void> shareBackup() async {
    final f = await createBackupFile();
    await Share.shareXFiles([XFile(f.path)], text: 'Backup Warung Sayur');
  }

  /// Tahap 11: auto-backup ke folder dokumen (offline) berdasarkan jadwal.
  /// - Tidak mengganggu pemakaian harian.
  /// - Menyimpan beberapa file terakhir.
  Future<void> autoBackupIfDue({
    required MetaRepo meta,
    required ActivityLogRepo logs,
    int keepLast = 10,
  }) async {
    if (!meta.autoBackupEnabled) return;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final lastMs = meta.lastAutoBackupEpochMs;
    final days = meta.autoBackupDays;
    final dueMs = Duration(days: days).inMilliseconds;
    if (lastMs != 0 && (nowMs - lastMs) < dueMs) return;

    final dir = await getApplicationDocumentsDirectory();
    final backupDir = Directory('${dir.path}/auto_backups');
    if (!await backupDir.exists()) {
      await backupDir.create(recursive: true);
    }
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${backupDir.path}/auto_backup_$ts.json');
    await f.writeAsString(jsonEncode(_snapshot()));

    await meta.setLastAutoBackupEpochMs(nowMs);
    await logs.log('auto_backup', 'Auto backup dibuat: ${f.path.split('/').last}');

    // cleanup old backups
    final files = backupDir
        .listSync()
        .whereType<File>()
        .where((x) => x.path.endsWith('.json'))
        .toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    if (files.length > keepLast) {
      for (final old in files.sublist(keepLast)) {
        try {
          await old.delete();
        } catch (_) {}
      }
    }
  }

  Future<void> restoreFromPicker() async {
    final res = await FilePicker.platform.pickFiles(
      dialogTitle: 'Pilih file backup (.json)',
      type: FileType.custom,
      allowedExtensions: ['json'],
    );
    if (res == null || res.files.isEmpty) return;
    final path = res.files.single.path;
    if (path == null) return;

    final raw = await File(path).readAsString();
    final j = jsonDecode(raw) as Map<String, dynamic>;

    await products.clear();
    await purchases.clear();
    await sales.clear();
    await expenses.clear();
    await debts.clear();
    await movements.clear();
    await cash.clear();
    await settings.clear();

    for (final p in (j[Boxes.products] as List? ?? const [])) {
      final obj = Product.fromJson(Map<String, dynamic>.from(p));
      await products.put(obj.id, obj);
    }
    for (final x in (j[Boxes.purchases] as List? ?? const [])) {
      final obj = Purchase.fromJson(Map<String, dynamic>.from(x));
      await purchases.put(obj.id, obj);
    }
    for (final x in (j[Boxes.sales] as List? ?? const [])) {
      final obj = Sale.fromJson(Map<String, dynamic>.from(x));
      await sales.put(obj.id, obj);
    }
    for (final x in (j[Boxes.expenses] as List? ?? const [])) {
      final obj = Expense.fromJson(Map<String, dynamic>.from(x));
      await expenses.put(obj.id, obj);
    }
    for (final x in (j[Boxes.debts] as List? ?? const [])) {
      final obj = Debt.fromJson(Map<String, dynamic>.from(x));
      await debts.put(obj.id, obj);
    }
    for (final x in (j[Boxes.movements] as List? ?? const [])) {
      final obj = StockMovement.fromJson(Map<String, dynamic>.from(x));
      await movements.put(obj.id, obj);
    }

    for (final x in (j[Boxes.cash] as List? ?? const [])) {
      final m = Map<String, dynamic>.from(x);
      final obj = CashEntry(
        id: m['id'] as String,
        dateEpochDay: (m['dateEpochDay'] as num).toInt(),
        direction: (m['direction'] as String?) ?? 'in',
        source: (m['source'] as String?) ?? 'manual',
        method: (m['method'] as String?) ?? 'Cash',
        note: (m['note'] as String?) ?? '',
        amount: (m['amount'] as num).toDouble(),
        refId: (m['refId'] as String?) ?? '',
      );
      await cash.put(obj.id, obj);
    }

    for (final x in (j[Boxes.settings] as List? ?? const [])) {
      final m = Map<String, dynamic>.from(x);
      final obj = AppSettings(
        id: (m['id'] as String?) ?? 'app',
        pinEnabled: (m['pinEnabled'] as bool?) ?? false,
        pinHash: (m['pinHash'] as String?) ?? '',
      );
      await settings.put(obj.id, obj);
    }
  }

  int _toEpochDay(DateTime dt) {
    final utc = DateTime.utc(dt.year, dt.month, dt.day);
    final base = DateTime.utc(1970, 1, 1);
    return utc.difference(base).inDays;
  }

  DateTime _fromEpochDay(int day) {
    final base = DateTime.utc(1970, 1, 1);
    final du = base.add(Duration(days: day));
    return DateTime(du.year, du.month, du.day);
  }

  Future<File> exportReportCsv({required DateTime start, required DateTime end}) async {
    final s0 = _toEpochDay(start);
    final s1 = _toEpochDay(end);

    final mapOmzet = <int, double>{};
    final mapHpp = <int, double>{};
    for (final s in sales.values) {
      if (s.dateEpochDay < s0 || s.dateEpochDay > s1) continue;
      mapOmzet[s.dateEpochDay] = (mapOmzet[s.dateEpochDay] ?? 0) + s.totalSales;
      mapHpp[s.dateEpochDay] = (mapHpp[s.dateEpochDay] ?? 0) + s.totalHpp;
    }

    final mapBiaya = <int, double>{};
    for (final e in expenses.values) {
      if (e.dateEpochDay < s0 || e.dateEpochDay > s1) continue;
      mapBiaya[e.dateEpochDay] = (mapBiaya[e.dateEpochDay] ?? 0) + e.amount;
    }

    final rows = <List<String>>[
      ['tanggal', 'omzet', 'hpp', 'laba_kotor', 'biaya', 'laba_bersih'],
    ];

    for (int day = s0; day <= s1; day++) {
      final omzet = mapOmzet[day] ?? 0;
      final hpp = mapHpp[day] ?? 0;
      final biaya = mapBiaya[day] ?? 0;
      final lk = omzet - hpp;
      final lb = lk - biaya;

      final t = _fromEpochDay(day);
      final tanggal =
          '${t.year.toString().padLeft(4, '0')}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
      rows.add([tanggal, omzet.toStringAsFixed(0), hpp.toStringAsFixed(0), lk.toStringAsFixed(0), biaya.toStringAsFixed(0), lb.toStringAsFixed(0)]);
    }

    final csv = rows.map((r) => r.map(_escapeCsv).join(',')).join('\n');

    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${dir.path}/warung_sayur_report_$ts.csv');
    await f.writeAsString(csv);
    return f;
  }

  Future<void> shareReportCsv({required DateTime start, required DateTime end}) async {
    final f = await exportReportCsv(start: start, end: end);
    await Share.shareXFiles([XFile(f.path)], text: 'Laporan CSV Warung Sayur');
  }

  /// Tahap 3: Export laporan detail (pembelian, penjualan, biaya) per baris item.
  Future<File> exportReportDetailCsv({required DateTime start, required DateTime end}) async {
    final s0 = _toEpochDay(start);
    final s1 = _toEpochDay(end);

    String dateStrFromEpochDay(int day) {
      final t = _fromEpochDay(day);
      return '${t.year.toString().padLeft(4, '0')}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
    }

    final rows = <List<String>>[
      [
        'tanggal',
        'tipe',
        'ref_id',
        'pihak',
        'produk',
        'qty',
        'unit',
        'harga',
        'subtotal',
        'hpp',
        'laba',
        'catatan',
      ],
    ];

    // Pembelian
    for (final p in purchases.values) {
      if (p.dateEpochDay < s0 || p.dateEpochDay > s1) continue;
      final tanggal = dateStrFromEpochDay(p.dateEpochDay);
      final pihak = p.supplier.trim();
      for (final it in p.items) {
        final pr = products.get(it.productId);
        final name = pr?.name ?? it.productId;
        final unit = pr?.unit ?? '';
        final subtotal = it.qty * it.buyPrice;
        rows.add([
          tanggal,
          'pembelian',
          p.id,
          pihak,
          name,
          it.qty.toStringAsFixed(2),
          unit,
          it.buyPrice.toStringAsFixed(0),
          subtotal.toStringAsFixed(0),
          '',
          '',
          '',
        ]);
      }
    }

    // Penjualan
    for (final s in sales.values) {
      if (s.dateEpochDay < s0 || s.dateEpochDay > s1) continue;
      final tanggal = dateStrFromEpochDay(s.dateEpochDay);
      for (final it in s.items) {
        final pr = products.get(it.productId);
        final name = pr?.name ?? it.productId;
        final unit = pr?.unit ?? '';
        final subtotal = it.qty * it.sellPrice;
        final hpp = it.qty * it.hppAtSale;
        final laba = subtotal - hpp;
        rows.add([
          tanggal,
          'penjualan',
          s.id,
          '',
          name,
          it.qty.toStringAsFixed(2),
          unit,
          it.sellPrice.toStringAsFixed(0),
          subtotal.toStringAsFixed(0),
          hpp.toStringAsFixed(0),
          laba.toStringAsFixed(0),
          '',
        ]);
      }
    }

    // Biaya
    for (final e in expenses.values) {
      if (e.dateEpochDay < s0 || e.dateEpochDay > s1) continue;
      final tanggal = dateStrFromEpochDay(e.dateEpochDay);
      rows.add([
        tanggal,
        'biaya',
        e.id,
        '',
        '',
        '',
        '',
        '',
        e.amount.toStringAsFixed(0),
        '',
        '',
        e.note,
      ]);
    }

    // Urutkan berdasarkan tanggal agar enak dibaca.
    final head = rows.first;
    final body = rows.skip(1).toList();
    body.sort((a, b) => a.first.compareTo(b.first));
    final csv = ([head] + body).map((r) => r.map(_escapeCsv).join(',')).join('\n');

    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${dir.path}/warung_sayur_report_detail_$ts.csv');
    await f.writeAsString(csv);
    return f;
  }

  Future<void> shareReportDetailCsv({required DateTime start, required DateTime end}) async {
    final f = await exportReportDetailCsv(start: start, end: end);
    await Share.shareXFiles([XFile(f.path)], text: 'Laporan Detail CSV Warung Sayur');
  }

  String _escapeCsv(String s) {
    if (s.contains(',') || s.contains('"') || s.contains('\n')) {
      return '"${s.replaceAll('"', '""')}"';
    }
    return s;
  }

  /// Tahap 5: Import produk dari CSV.
  /// Format header (bebas urutan):
  /// name, unit, defaultMarginPercent, activeSellPrice, stockQty, avgHpp, minStock
  /// Jika name sama, produk akan di-update. Jika tidak ada, produk baru dibuat.
  Future<int> importProductsFromCsv() async {
    final res = await FilePicker.platform.pickFiles(
      dialogTitle: 'Pilih file CSV Produk',
      type: FileType.custom,
      allowedExtensions: ['csv'],
    );
    if (res == null || res.files.isEmpty) return 0;
    final path = res.files.single.path;
    if (path == null) return 0;

    final raw = await File(path).readAsString();
    final rows = const CsvToListConverter(eol: '\n').convert(raw);
    if (rows.isEmpty) return 0;

    final header = rows.first.map((e) => e.toString().trim()).toList();
    int idx(String key) => header.indexWhere((h) => h.toLowerCase() == key.toLowerCase());

    final iName = idx('name');
    if (iName < 0) {
      // fallback: kolom pertama dianggap name
    }

    int count = 0;
    for (int r = 1; r < rows.length; r++) {
      final row = rows[r];
      if (row.isEmpty) continue;
      final name = (row[(iName >= 0 ? iName : 0)] ?? '').toString().trim();
      if (name.isEmpty) continue;

      String getS(String key, {String def = ''}) {
        final i = idx(key);
        if (i < 0 || i >= row.length) return def;
        return (row[i] ?? def).toString();
      }

      double getD(String key, {double def = 0}) {
        final i = idx(key);
        if (i < 0 || i >= row.length) return def;
        final v = row[i];
        if (v is num) return v.toDouble();
        return double.tryParse(v.toString()) ?? def;
      }

      final unit = getS('unit');
      final margin = getD('defaultMarginPercent');
      final sell = getD('activeSellPrice');
      final stock = getD('stockQty');
      final hpp = getD('avgHpp');
      final minStock = getD('minStock');

      // cari produk existing berdasarkan name (case-insensitive)
      Product? existing;
      for (final p in products.values) {
        if (p.name.toLowerCase().trim() == name.toLowerCase()) {
          existing = p;
          break;
        }
      }

      if (existing != null) {
        existing
          ..unit = unit.isEmpty ? existing.unit : unit
          ..defaultMarginPercent = margin == 0 ? existing.defaultMarginPercent : margin
          ..activeSellPrice = sell == 0 ? existing.activeSellPrice : sell
          ..stockQty = stock
          ..avgHpp = hpp
          ..minStock = minStock;
        await products.put(existing.id, existing);
      } else {
        final id = newId('prd');
        await products.put(
          id,
          Product(
            id: id,
            name: name,
            unit: unit.isEmpty ? 'pcs' : unit,
            defaultMarginPercent: margin,
            activeSellPrice: sell,
            stockQty: stock,
            avgHpp: hpp,
            minStock: minStock,
          ),
        );
      }

      count++;
    }
    return count;
  }
}
