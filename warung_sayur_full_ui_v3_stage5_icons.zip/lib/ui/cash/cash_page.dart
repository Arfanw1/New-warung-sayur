import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/cash_entry.dart';
import '../widgets/date_range_picker.dart';
import '../widgets/money_field.dart';

class CashPage extends ConsumerStatefulWidget {
  const CashPage({super.key});

  @override
  ConsumerState<CashPage> createState() => _CashPageState();
}

class _CashPageState extends ConsumerState<CashPage> {
  DateTimeRange? range;

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(cashRepoProvider);
    final all = repo.all();
    final filtered = range == null
        ? all
        : all.where((e) {
            final d = fromEpochDay(e.dateEpochDay);
            return !d.isBefore(range!.start) && !d.isAfter(range!.end);
          }).toList();

    double cashIn = 0;
    double cashOut = 0;
    for (final e in filtered) {
      if (e.direction == 'in') cashIn += e.amount;
      if (e.direction == 'out') cashOut += e.amount;
    }

    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(child: Text('Periode', style: TextStyle(fontWeight: FontWeight.w600))),
                        TextButton.icon(
                          onPressed: () async {
                            final picked = await pickDateRange(context, initial: range);
                            setState(() => range = picked);
                          },
                          icon: const Icon(Icons.date_range),
                          label: Text(range == null ? 'Pilih' : '${fmtDate(range!.start)} - ${fmtDate(range!.end)}'),
                        ),
                        if (range != null)
                          IconButton(
                            tooltip: 'Reset',
                            onPressed: () => setState(() => range = null),
                            icon: const Icon(Icons.close),
                          ),
                      ],
                    ),
                    const Divider(),
                    _kv('Uang masuk', fmtMoney(cashIn)),
                    _kv('Uang keluar', fmtMoney(cashOut)),
                    const SizedBox(height: 6),
                    _kv('Saldo bersih (masuk - keluar)', fmtMoney(cashIn - cashOut), bold: true),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            ...filtered.map((e) {
              final dirIcon = e.direction == 'in' ? Icons.arrow_downward : Icons.arrow_upward;
              return Card(
                child: ListTile(
                  leading: Icon(dirIcon),
                  title: Text(e.note.isEmpty ? e.source : e.note),
                  subtitle: Text('${fmtDateFromEpochDay(e.dateEpochDay)} • ${e.method} • ${e.source}'),
                  trailing: Text(fmtMoney(e.amount)),
                ),
              );
            }),
            if (filtered.isEmpty)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: Text('Belum ada catatan kas di periode ini.')),
              ),
            const SizedBox(height: 80),
          ],
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ManualCashFormPage())),
            child: Image.asset('assets/icons/ic_add.png', width: 24, height: 24),
          ),
        ),
      ],
    );
  }

  Widget _kv(String k, String v, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.w700 : FontWeight.w400);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Expanded(child: Text(k, style: style)),
          Text(v, style: style),
        ],
      ),
    );
  }
}

class ManualCashFormPage extends ConsumerStatefulWidget {
  const ManualCashFormPage({super.key});

  @override
  ConsumerState<ManualCashFormPage> createState() => _ManualCashFormPageState();
}

class _ManualCashFormPageState extends ConsumerState<ManualCashFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  String direction = 'in';
  String method = 'Cash';
  final noteC = TextEditingController();
  final amountC = TextEditingController();

  @override
  void dispose() {
    noteC.dispose();
    amountC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Kas Manual')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ListTile(
              title: const Text('Tanggal'),
              subtitle: Text(fmtDate(date)),
              trailing: const Icon(Icons.date_range),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: date,
                  firstDate: DateTime(2020),
                  lastDate: DateTime(2100),
                );
                if (picked != null) setState(() => date = picked);
              },
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: direction,
              decoration: const InputDecoration(labelText: 'Arah kas'),
              items: const [
                DropdownMenuItem(value: 'in', child: Text('Uang masuk')),
                DropdownMenuItem(value: 'out', child: Text('Uang keluar')),
              ],
              onChanged: (v) => setState(() => direction = v ?? 'in'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: method,
              decoration: const InputDecoration(labelText: 'Metode'),
              items: const [
                DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
                DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
              ],
              onChanged: (v) => setState(() => method = v ?? 'Cash'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: noteC,
              decoration: const InputDecoration(labelText: 'Catatan (opsional)'),
            ),
            const SizedBox(height: 12),
            MoneyField(controller: amountC, label: 'Jumlah', requiredField: true),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = (parseRupiah(amountC.text.trim()) ?? 0).toDouble();
    final id = newId('cash');
    await ref.read(cashRepoProvider).add(
          CashEntry(
            id: id,
            dateEpochDay: epochDay(date),
            direction: direction,
            source: 'manual',
            method: method,
            note: noteC.text.trim(),
            amount: amount,
            refId: '',
          ),
        );
    if (!mounted) return;
    Navigator.pop(context);
  }
}
