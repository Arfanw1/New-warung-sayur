import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/product.dart';
import '../../domain/models/activity_log.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/number_field.dart';
import '../widgets/money_field.dart';

class PurchaseFormPage extends ConsumerStatefulWidget {
  final Purchase? initial;
  const PurchaseFormPage({super.key, this.initial});

  @override
  ConsumerState<PurchaseFormPage> createState() => _PurchaseFormPageState();
}

class _PurchaseFormPageState extends ConsumerState<PurchaseFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();

  String paymentMethod = 'Cash';

  final supplierC = TextEditingController();

  final List<_Row> rows = [_Row()];

  @override
  void initState() {
    super.initState();
    final init = widget.initial;
    if (init != null) {
      date = fromEpochDay(init.dateEpochDay);
      paymentMethod = init.paymentMethod;
      supplierC.text = init.supplier;
      rows
        ..clear()
        ..addAll(init.items.map((it) {
          final r = _Row();
          r.productId = it.productId;
          r.qtyC.text = it.qty.toStringAsFixed(2);
          r.priceC.text = it.buyPrice.toStringAsFixed(0);
          return r;
        }));
      if (rows.isEmpty) rows.add(_Row());
    }
  }

  @override
  void dispose() {
    supplierC.dispose();
    for (final r in rows) {
      r.qtyC.dispose();
      r.priceC.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productRepoProvider).all();
    final suppliers = ref
        .watch(purchaseRepoProvider)
        .all()
        .map((e) => e.supplier.trim())
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'Tambah Pembelian' : 'Edit Pembelian')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: paymentMethod,
              decoration: const InputDecoration(labelText: 'Metode pembayaran'),
              items: const [
                DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                DropdownMenuItem(value: 'Hutang', child: Text('Hutang')),
              ],
              onChanged: (v) => setState(() => paymentMethod = v ?? 'Cash'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: supplierC,
              decoration: const InputDecoration(labelText: 'Supplier (opsional)'),
            ),
            if (suppliers.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: suppliers.take(8).map((s) {
                  return ActionChip(
                    label: Text(s),
                    onPressed: () => setState(() => supplierC.text = s),
                  );
                }).toList(),
              ),
            ],
            const SizedBox(height: 12),
            if (products.isEmpty) const Text('Belum ada produk. Tambahkan produk dulu di tab Produk.'),
            ...List.generate(rows.length, (i) => _buildRow(products, i)),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => setState(() => rows.add(_Row())),
              icon: Image.asset('assets/icons/ic_add.png', width: 20, height: 20),
              label: const Text('Tambah item'),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: products.isEmpty ? null : _save,
              icon: const Icon(Icons.save),
              label: Text(widget.initial == null ? 'Simpan Pembelian' : 'Simpan Perubahan'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(List<Product> products, int i) {
    final r = rows[i];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: r.productId,
              decoration: const InputDecoration(labelText: 'Produk'),
              items: products.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(),
              onChanged: (v) => setState(() => r.productId = v),
              validator: (v) => (v == null || v.isEmpty) ? 'Pilih produk' : null,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: NumberField(controller: r.qtyC, label: 'Qty', requiredField: true)),
                const SizedBox(width: 12),
                Expanded(
                  child: NumberField(
                    controller: r.priceC,
                    label: 'Harga beli /unit',
                    requiredField: true,
                    integerOnly: true,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: rows.length <= 1 ? null : () => setState(() => rows.removeAt(i)),
                icon: const Icon(Icons.delete_outline),
                label: const Text('Hapus item'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final items = <PurchaseItem>[];
    for (final r in rows) {
      final qty = double.tryParse(r.qtyC.text.trim()) ?? 0;
      final price = (parseRupiah(r.priceC.text.trim()) ?? 0).toDouble();
      if (r.productId == null) continue;
      if (qty <= 0) continue;
      items.add(PurchaseItem(productId: r.productId!, qty: qty, buyPrice: price));
    }

    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Isi minimal 1 item pembelian')));
      return;
    }

    final isEdit = widget.initial != null;
    final id = widget.initial?.id ?? newId('buy');

    final purchase = Purchase(
      id: id,
      dateEpochDay: epochDay(date),
      supplier: supplierC.text.trim(),
      paymentMethod: paymentMethod,
      items: items,
    );

    if (isEdit) {
      final old = widget.initial!;
      await ref.read(purchaseRepoProvider).remove(old.id);
      await ref.read(purchaseRepoProvider).add(purchase);
      await ref.read(activityLogRepoProvider).add(
            ActivityLog(
              id: newId('log'),
              dateEpochDay: purchase.dateEpochDay,
              type: 'edit_purchase',
              refId: old.id,
              oldJson: jsonEncode(old.toJson()),
              newJson: jsonEncode(purchase.toJson()),
            ),
          );
    } else {
      await ref.read(purchaseRepoProvider).add(purchase);
    }

    if (!mounted) return;
    Navigator.pop(context);
  }
}

class _Row {
  String? productId;
  final qtyC = TextEditingController();
  final priceC = TextEditingController();
}
