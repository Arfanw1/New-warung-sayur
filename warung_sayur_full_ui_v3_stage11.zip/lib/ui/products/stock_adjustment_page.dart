import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/stock_movement.dart';
import '../../domain/models/cash_entry.dart';
import '../../providers.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/number_field.dart';

class StockAdjustmentPage extends ConsumerStatefulWidget {
  final String productId;
  const StockAdjustmentPage({super.key, required this.productId});

  @override
  ConsumerState<StockAdjustmentPage> createState() => _StockAdjustmentPageState();
}

class _StockAdjustmentPageState extends ConsumerState<StockAdjustmentPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  bool isIncrease = false; // default decrease (lebih sering untuk busuk/hilang)
  String? lossType; // susut | busuk | hilang | null(koreksi)

  final qtyC = TextEditingController();
  final noteC = TextEditingController();

  @override
  void dispose() {
    qtyC.dispose();
    noteC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final productsRepo = ref.watch(productRepoProvider);
    final p = productsRepo.getById(widget.productId);

    if (p == null) {
      return const Scaffold(body: Center(child: Text('Produk tidak ditemukan')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Penyesuaian Stok')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: ListTile(
                title: Text(p.name),
                subtitle: Text('Stok saat ini: ${p.stockQty.toStringAsFixed(2)} ${p.unit}'),
              ),
            ),
            const SizedBox(height: 12),
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('Tambah')),
                ButtonSegment(value: false, label: Text('Kurangi')),
              ],
              selected: {isIncrease},
              onSelectionChanged: (s) => setState(() => isIncrease = s.first),
            ),
            const SizedBox(height: 12),
            NumberField(controller: qtyC, label: 'Jumlah', requiredField: true),
            const SizedBox(height: 12),
if (!isIncrease) ...[
  DropdownButtonFormField<String?>(
    value: lossType,
    decoration: const InputDecoration(labelText: 'Jenis pengurangan'),
    items: const [
      DropdownMenuItem(value: null, child: Text('Koreksi stok (bukan kerugian)')),
      DropdownMenuItem(value: 'susut', child: Text('Susut')),
      DropdownMenuItem(value: 'busuk', child: Text('Busuk')),
      DropdownMenuItem(value: 'hilang', child: Text('Hilang')),
    ],
    onChanged: (v) => setState(() => lossType = v),
  ),
  const SizedBox(height: 12),
],

            TextFormField(
              controller: noteC,
              decoration: const InputDecoration(labelText: 'Catatan/Alasan (opsional, contoh: pasar, selisih timbangan)'),
              validator: (_) => null,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final qty = double.tryParse(qtyC.text.trim()) ?? 0;
    if (qty <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Jumlah harus > 0')));
      return;
    }

    final productsRepo = ref.read(productRepoProvider);
    final p = productsRepo.getById(widget.productId);
    if (p == null) return;

    if (!isIncrease && qty > p.stockQty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Stok tidak cukup. Stok saat ini: ${p.stockQty.toStringAsFixed(2)}')));
      return;
    }

    final delta = isIncrease ? qty : -qty;

// Jika pengurangan stok karena kerugian, hitung nilai kerugian berdasarkan avgHpp saat ini.
final bool isLoss = (!isIncrease) && (lossType != null);
final double lossAmount = isLoss ? (qty * (p.avgHpp)) : 0;
    p.stockQty = (p.stockQty + delta).clamp(0, double.infinity);
    await productsRepo.upsert(p);

    final mv = StockMovement(
      id: newId('mv'),
      dateEpochDay: epochDay(date),
      productId: widget.productId,
      type: 'adjust',
      qtyDelta: delta,
      note: noteC.text.trim(),
      lossType: (!isIncrease) ? lossType : null,
      lossAmount: lossAmount,
    );
await ref.read(movementRepoProvider).add(mv);

if (isLoss && lossAmount > 0) {
  await ref.read(cashRepoProvider).add(
        CashEntry(
          id: newId('cash'),
          dateEpochDay: epochDay(date),
          direction: 'out',
          source: 'Loss',
          method: 'Cash',
          note: 'Kerugian ${lossType ?? ''} • ${p.name}${noteC.text.trim().isNotEmpty ? ' • ' + noteC.text.trim() : ''}',
          amount: lossAmount,
          refId: mv.id,
        ),
      );
}

    if (!mounted) return;
    Navigator.pop(context);
  }
}
