class CashEntry {
  final String id;
  int dateEpochDay;
  /// 'in' atau 'out'
  String direction;
  /// contoh: 'sale', 'purchase', 'expense', 'debt_payment', 'manual'
  String source;
  /// metode pembayaran: Cash/QRIS/Transfer/Hutang
  String method;
  String note;
  double amount;
  /// id transaksi sumber (opsional)
  String refId;

  CashEntry({
    required this.id,
    required this.dateEpochDay,
    required this.direction,
    required this.source,
    required this.method,
    required this.note,
    required this.amount,
    required this.refId,
  });
}
