import 'package:hive/hive.dart';
import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../core/calc.dart';
import '../../domain/models/stock_movement.dart';
import '../../domain/models/cash_entry.dart';
import '../../core/ids.dart';

class PurchaseRepo {
  final Box<Purchase> purchasesBox;
  final Box<Product> productsBox;
  final Box<StockMovement> movementsBox;
  final Box<CashEntry> cashBox;

  PurchaseRepo(this.purchasesBox, this.productsBox, this.movementsBox, this.cashBox);

  List<Purchase> all() => purchasesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Purchase purchase) async {
    await purchasesBox.put(purchase.id, purchase);

    // Buku kas: pembelian = uang keluar, kecuali jika Hutang.
    if (purchase.paymentMethod.toLowerCase() != 'hutang') {
      final cashId = newId('cash');
      final total = purchase.items.fold<double>(0, (s, it) => s + it.qty * it.buyPrice);
      await cashBox.put(
        cashId,
        CashEntry(
          id: cashId,
          dateEpochDay: purchase.dateEpochDay,
          direction: 'out',
          source: 'purchase',
          method: purchase.paymentMethod,
          note: purchase.supplier.isEmpty ? 'Pembelian' : 'Pembelian (${purchase.supplier})',
          amount: total,
          refId: purchase.id,
        ),
      );
    }

    // Catat pergerakan stok
    for (final item in purchase.items) {
      final mvId = newId('mv');
      await movementsBox.put(
        mvId,
        StockMovement(
          id: mvId,
          dateEpochDay: purchase.dateEpochDay,
          productId: item.productId,
          type: 'purchase',
          qtyDelta: item.qty,
          // Simpan referensi transaksi di note agar bisa di-rollback saat hapus
          note: 'Pembelian#${purchase.id}',
        ),
      );
    }

    for (final item in purchase.items) {
      final product = productsBox.get(item.productId);
      if (product == null) continue;

      final oldQty = product.stockQty;
      final oldHpp = product.avgHpp;

      final incomingQty = item.qty;
      final incomingCost = item.qty * item.buyPrice;

      final oldCost = oldQty * oldHpp;
      final newTotalQty = oldQty + incomingQty;
      final newTotalCost = oldCost + incomingCost;

      product.stockQty = newTotalQty;
      product.avgHpp = hppWeightedAverage(totalQty: newTotalQty, totalCost: newTotalCost);

      await productsBox.put(product.id, product);
    }
  }

  Future<void> remove(String id) async {
    final purchase = purchasesBox.get(id);
    if (purchase == null) {
      await purchasesBox.delete(id);
      return;
    }

    // 1) Hapus movement terkait pembelian ini
    final mvKeysToDelete = <dynamic>[];
    for (final entry in movementsBox.toMap().entries) {
      final mv = entry.value;
      if (mv.type == 'purchase' && mv.note == 'Pembelian#$id') {
        mvKeysToDelete.add(entry.key);
      }
    }
    for (final k in mvKeysToDelete) {
      await movementsBox.delete(k);
    }

    // 2) Hapus transaksi pembelian
    await purchasesBox.delete(id);

    // 2b) Hapus cash entry terkait
    final cashKeys = <dynamic>[];
    for (final entry in cashBox.toMap().entries) {
      final c = entry.value;
      if (c.source == 'purchase' && c.refId == id) cashKeys.add(entry.key);
    }
    for (final k in cashKeys) {
      await cashBox.delete(k);
    }

    // 3) Recalc stok & HPP untuk produk yang terdampak
    final affectedProductIds = purchase.items.map((e) => e.productId).toSet();
    for (final productId in affectedProductIds) {
      final product = productsBox.get(productId);
      if (product == null) continue;

      // stok = total qtyDelta dari semua movement (purchase/sale/adjust)
      final stock = movementsBox.values
          .where((m) => m.productId == productId)
          .fold<double>(0, (sum, m) => sum + m.qtyDelta);
      product.stockQty = stock.clamp(0, double.infinity);

      // avgHpp dihitung ulang dari seluruh pembelian yang tersisa
      double totalQty = 0;
      double totalCost = 0;
      for (final p in purchasesBox.values) {
        for (final it in p.items) {
          if (it.productId != productId) continue;
          totalQty += it.qty;
          totalCost += it.qty * it.buyPrice;
        }
      }
      product.avgHpp = totalQty <= 0 ? 0 : hppWeightedAverage(totalQty: totalQty, totalCost: totalCost);

      await productsBox.put(product.id, product);
    }
  }
}
