import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/dates.dart';
import '../../providers.dart';
import '../products/product_detail_page.dart';
import '../purchases/purchase_form.dart';
import '../sales/sale_form.dart';
import '../expenses/expenses_page.dart';
import '../reports/reports_page.dart';

class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productsRepo = ref.watch(productRepoProvider);
    final salesRepo = ref.watch(salesRepoProvider);
    final expenseRepo = ref.watch(expenseRepoProvider);
    final cashRepo = ref.watch(cashRepoProvider);

    final today = epochDay(DateTime.now());

    final salesToday = salesRepo.all().where((s) => s.dateEpochDay == today).toList();
    final expensesToday = expenseRepo.all().where((e) => e.dateEpochDay == today).toList();

    final omzetToday = salesToday.fold<double>(0, (p, s) => p + s.totalSales);
    final hppToday = salesToday.fold<double>(0, (p, s) => p + s.totalHpp);
    final biayaToday = expensesToday.fold<double>(0, (p, e) => p + e.amount);
    final labaToday = omzetToday - hppToday - biayaToday;

    final cashAll = cashRepo.all();
    final saldoKas = cashAll.fold<double>(0, (p, e) => p + (e.direction == 'in' ? e.amount : -e.amount));

    // Top produk terlaris hari ini
    final soldByProduct = <String, double>{};
    for (final s in salesToday) {
      for (final it in s.items) {
        soldByProduct[it.productId] = (soldByProduct[it.productId] ?? 0) + it.qty;
      }
    }
    final topSold = soldByProduct.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    // Stok menipis
    final lowStock = productsRepo
        .all()
        .where((p) => p.minStock > 0 && p.stockQty <= p.minStock)
        .toList()
      ..sort((a, b) {
        final d = (a.stockQty - a.minStock).compareTo(b.stockQty - b.minStock);
        if (d != 0) return d;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      children: [
        _SectionTitle(title: 'Ringkasan Hari Ini', subtitle: fmtDateFromEpochDay(today)),
        const SizedBox(height: 8),
        _SummaryGrid(
          omzet: omzetToday,
          laba: labaToday,
          saldoKas: saldoKas,
          trx: salesToday.length,
        ),
        const SizedBox(height: 16),
        _QuickActions(
          onAddSale: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SaleFormPage())),
          onAddPurchase: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PurchaseFormPage())),
          onAddExpense: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExpenseFormPage())),
          onOpenReports: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const Scaffold(appBar: AppBar(title: Text('Laporan')), body: ReportsPage()),
            ),
          ),
        ),
        const SizedBox(height: 16),
        _CardSection(
          title: 'Produk Terlaris Hari Ini',
          trailing: Text('${topSold.length} produk'),
          child: topSold.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Belum ada penjualan hari ini.'),
                )
              : Column(
                  children: topSold.take(3).map((e) {
                    final pr = productsRepo.getById(e.key);
                    final name = pr?.name ?? 'Produk';
                    final unit = pr?.unit ?? '';
                    return ListTile(
                      dense: true,
                      title: Text(name),
                      subtitle: Text('Terjual: ${_fmtQty(e.value)} ${unit.isEmpty ? '' : unit}'),
                    );
                  }).toList(),
                ),
        ),
        const SizedBox(height: 12),
        _CardSection(
          title: 'Stok Menipis',
          trailing: Text('${lowStock.length} item'),
          child: lowStock.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('Aman. Tidak ada stok menipis.'),
                )
              : Column(
                  children: lowStock.take(5).map((p) {
                    return ListTile(
                      dense: true,
                      leading: const Icon(Icons.warning_amber_rounded),
                      title: Text(p.name),
                      subtitle: Text('Stok: ${_fmtQty(p.stockQty)} ${p.unit} • Min: ${_fmtQty(p.minStock)}'),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id)),
                      ),
                    );
                  }).toList(),
                ),
        ),
      ],
    );
  }
}

String _fmtQty(num n) {
  final s = n.toStringAsFixed(2);
  return s.replaceAll(RegExp(r'\\.00\$'), '').replaceAll(RegExp(r'(\\.[0-9])0\$'), r'\$1');
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SectionTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 2),
        Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}

class _SummaryGrid extends StatelessWidget {
  final double omzet;
  final double laba;
  final double saldoKas;
  final int trx;
  const _SummaryGrid({required this.omzet, required this.laba, required this.saldoKas, required this.trx});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.6,
      children: [
        _StatCard(title: 'Omzet', value: fmtMoney(omzet), icon: Icons.payments_rounded),
        _StatCard(title: 'Laba', value: fmtMoney(laba), icon: Icons.trending_up_rounded),
        _StatCard(title: 'Saldo Kas', value: fmtMoney(saldoKas), icon: Icons.account_balance_wallet_rounded),
        _StatCard(title: 'Transaksi', value: trx.toString(), icon: Icons.receipt_long_rounded),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const _StatCard({required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickActions extends StatelessWidget {
  final VoidCallback onAddSale;
  final VoidCallback onAddPurchase;
  final VoidCallback onAddExpense;
  final VoidCallback onOpenReports;

  const _QuickActions({
    required this.onAddSale,
    required this.onAddPurchase,
    required this.onAddExpense,
    required this.onOpenReports,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Shortcut Cepat', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                const Icon(Icons.bolt_rounded),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.icon(onPressed: onAddSale, icon: const Icon(Icons.point_of_sale_rounded), label: const Text('Penjualan')),
                FilledButton.icon(onPressed: onAddPurchase, icon: const Icon(Icons.shopping_cart_rounded), label: const Text('Pembelian')),
                FilledButton.icon(onPressed: onAddExpense, icon: const Icon(Icons.request_quote_rounded), label: const Text('Biaya')),
                OutlinedButton.icon(onPressed: onOpenReports, icon: const Icon(Icons.bar_chart_rounded), label: const Text('Laporan')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CardSection extends StatelessWidget {
  final String title;
  final Widget trailing;
  final Widget child;
  const _CardSection({required this.title, required this.trailing, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                DefaultTextStyle(style: Theme.of(context).textTheme.bodySmall!, child: trailing),
              ],
            ),
          ),
          const SizedBox(height: 6),
          child,
        ],
      ),
    );
  }
}
