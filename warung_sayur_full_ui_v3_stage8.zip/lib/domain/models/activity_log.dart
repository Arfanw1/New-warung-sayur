class ActivityLog {
  final String id;
  final int dateEpochDay;
  final String type; // edit_purchase, edit_sale, edit_expense
  final String refId;
  final String oldJson;
  final String newJson;

  ActivityLog({
    required this.id,
    required this.dateEpochDay,
    required this.type,
    required this.refId,
    required this.oldJson,
    required this.newJson,
  });
}
