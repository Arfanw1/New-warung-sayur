import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/activity_log.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/number_field.dart';
import '../widgets/money_field.dart';

class SaleFormPage extends ConsumerStatefulWidget {
  final Sale? initial;
  const SaleFormPage({super.key, this.initial});

  @override
  ConsumerState<SaleFormPage> createState() => _SaleFormPageState();
}

class _SaleFormPageState extends ConsumerState<SaleFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  String paymentMethod = 'Cash';
  final List<_Row> rows = [_Row()];

  @override
  void initState() {
    super.initState();
    final init = widget.initial;
    if (init != null) {
      date = fromEpochDay(init.dateEpochDay);
      paymentMethod = init.paymentMethod;
      rows
        ..clear()
        ..addAll(init.items.map((it) {
          final r = _Row();
          r.productId = it.productId;
          r.qtyC.text = it.qty.toStringAsFixed(2);
          r.sellC.text = it.sellPrice.toStringAsFixed(0);
          return r;
        }));
      if (rows.isEmpty) rows.add(_Row());
    }
  }

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productRepoProvider).all();

    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'Tambah Penjualan' : 'Edit Penjualan')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: paymentMethod,
              decoration: const InputDecoration(labelText: 'Metode pembayaran'),
              items: const [
                DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
                DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                DropdownMenuItem(value: 'Hutang', child: Text('Hutang')),
              ],
              onChanged: (v) => setState(() => paymentMethod = v ?? 'Cash'),
            ),
            const SizedBox(height: 12),
            if (products.isEmpty) const Text('Belum ada produk. Tambahkan produk dulu di tab Produk.'),
            ...List.generate(rows.length, (i) => _buildRow(products, i)),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => setState(() => rows.add(_Row())),
              icon: Image.asset('assets/icons/ic_add.png', width: 20, height: 20),
              label: const Text('Tambah item'),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: products.isEmpty ? null : _save,
              icon: const Icon(Icons.save),
              label: Text(widget.initial == null ? 'Simpan Penjualan' : 'Simpan Perubahan'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(List<Product> products, int i) {
    final r = rows[i];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: r.productId,
              decoration: const InputDecoration(labelText: 'Produk'),
              items: products.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(),
              onChanged: (v) {
                setState(() => r.productId = v);
                if (v != null) {
                  final pr = products.firstWhere((x) => x.id == v);
                  r.sellC.text = pr.activeSellPrice.toStringAsFixed(0);
                }
              },
              validator: (v) => (v == null || v.isEmpty) ? 'Pilih produk' : null,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: NumberField(controller: r.qtyC, label: 'Qty', requiredField: true)),
                const SizedBox(width: 12),
                Expanded(
                  child: MoneyField(
                    controller: r.sellC,
                    label: 'Harga jual /unit',
                    requiredField: true,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: rows.length <= 1 ? null : () => setState(() => rows.removeAt(i)),
                icon: const Icon(Icons.delete_outline),
                label: const Text('Hapus item'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final productsRepo = ref.read(productRepoProvider);
    final items = <SaleItem>[];

    final oldQtyByProduct = <String, double>{};
    for (final it in widget.initial?.items ?? const <SaleItem>[]) {
      oldQtyByProduct[it.productId] = (oldQtyByProduct[it.productId] ?? 0) + it.qty;
    }

    // Akumulasi qty per produk untuk validasi stok (kalau produk yang sama dipilih beberapa kali)
    final qtyByProduct = <String, double>{};

    for (final r in rows) {
      final qty = double.tryParse(r.qtyC.text.trim()) ?? 0;
      final sell = (parseRupiah(r.sellC.text.trim()) ?? 0).toDouble();
      if (r.productId == null) continue;
      if (qty <= 0) continue;

      final p = productsRepo.getById(r.productId!);
      final hpp = p?.avgHpp ?? 0;

      qtyByProduct[r.productId!] = (qtyByProduct[r.productId!] ?? 0) + qty;

      items.add(SaleItem(productId: r.productId!, qty: qty, sellPrice: sell, hppAtSale: hpp));
    }

    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Isi minimal 1 item penjualan')));
      return;
    }

    // Validasi stok cukup
    for (final entry in qtyByProduct.entries) {
      final p = productsRepo.getById(entry.key);
      final stockNow = p?.stockQty ?? 0;
      // Jika edit, stok efektif = stok sekarang + qty lama (karena transaksi lama akan di-rollback dulu)
      final effectiveStock = stockNow + (oldQtyByProduct[entry.key] ?? 0);
      if (entry.value > effectiveStock) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Stok tidak cukup untuk ${p?.name ?? 'produk'}. Stok: ${effectiveStock.toStringAsFixed(2)}')),
        );
        return;
      }
    }

    final isEdit = widget.initial != null;
    final id = widget.initial?.id ?? newId('sell');
    final sale = Sale(
      id: id,
      dateEpochDay: epochDay(date),
      paymentMethod: paymentMethod,
      items: items,
    );
    try {
      if (isEdit) {
        final old = widget.initial!;
        await ref.read(salesRepoProvider).remove(old.id);
        await ref.read(salesRepoProvider).add(sale);
        await ref.read(activityLogRepoProvider).add(
              ActivityLog(
                id: newId('log'),
                dateEpochDay: sale.dateEpochDay,
                type: 'edit_sale',
                refId: old.id,
                oldJson: jsonEncode(old.toJson()),
                newJson: jsonEncode(sale.toJson()),
              ),
            );
      } else {
        await ref.read(salesRepoProvider).add(sale);
      }
    } catch (e) {
      // Fallback kalau repo menolak karena stok berubah (mis. ada transaksi lain)
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      return;
    }

    if (!mounted) return;
    Navigator.pop(context);
  }
}

class _Row {
  String? productId;
  final qtyC = TextEditingController();
  final sellC = TextEditingController();
}
