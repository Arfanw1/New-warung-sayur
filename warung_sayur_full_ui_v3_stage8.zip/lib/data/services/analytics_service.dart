import 'package:hive/hive.dart';

import '../../core/dates.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';

class ProductKpi {
  final String productId;
  final String name;
  final double qty;
  final double revenue;
  final double hpp;
  final double profit;

  const ProductKpi({
    required this.productId,
    required this.name,
    required this.qty,
    required this.revenue,
    required this.hpp,
    required this.profit,
  });

  double get marginPercent => revenue == 0 ? 0 : (profit / revenue) * 100.0;
}

class DayPoint {
  final int epochDayValue;
  final double value;
  const DayPoint(this.epochDayValue, this.value);
}

class AnalyticsService {
  const AnalyticsService();

  List<Sale> _salesInRange(Box<Sale> salesBox, DateTime start, DateTime end) {
    final s = epochDay(start);
    final e = epochDay(end);
    return salesBox.values.where((x) => x.dateEpochDay >= s && x.dateEpochDay <= e).toList();
  }

  List<ProductKpi> topSelling(Box<Sale> salesBox, Box<Product> productsBox, DateTime start, DateTime end) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <String, ({double qty, double rev, double hpp})>{};

    for (final sale in sales) {
      for (final it in sale.items) {
        final cur = map[it.productId] ?? (qty: 0.0, rev: 0.0, hpp: 0.0);
        map[it.productId] = (
          qty: cur.qty + it.qty,
          rev: cur.rev + it.total,
          hpp: cur.hpp + it.totalHpp,
        );
      }
    }

    final res = <ProductKpi>[];
    map.forEach((pid, v) {
      final p = productsBox.get(pid);
      res.add(ProductKpi(
        productId: pid,
        name: p?.name ?? pid,
        qty: v.qty,
        revenue: v.rev,
        hpp: v.hpp,
        profit: v.rev - v.hpp,
      ));
    });

    res.sort((a, b) => b.qty.compareTo(a.qty));
    return res;
  }

  List<ProductKpi> topProfit(Box<Sale> salesBox, Box<Product> productsBox, DateTime start, DateTime end) {
    final list = topSelling(salesBox, productsBox, start, end);
    list.sort((a, b) => b.profit.compareTo(a.profit));
    return list;
  }

  /// Produk yang berpotensi rugi / margin turun berdasarkan data produk saat ini.
  List<(Product product, double marginActual)> lossProducts(Box<Product> productsBox) {
    final res = <(Product, double)>[];
    for (final p in productsBox.values) {
      if (p.activeSellPrice <= 0) continue;
      final profitPerUnit = p.activeSellPrice - p.avgHpp;
      final marginActual = (profitPerUnit / p.activeSellPrice) * 100.0;
      if (p.activeSellPrice < p.avgHpp || marginActual < p.defaultMarginPercent) {
        res.add((p, marginActual));
      }
    }
    // paling parah dulu (margin paling kecil)
    res.sort((a, b) => a.$2.compareTo(b.$2));
    return res;
  }

  /// Tren omzet global per hari (berdasarkan total penjualan).
  List<DayPoint> revenueTrend(Box<Sale> salesBox, DateTime start, DateTime end) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <int, double>{};
    for (final s in sales) {
      final day = s.dateEpochDay;
      map[day] = (map[day] ?? 0) + s.items.fold(0.0, (sum, it) => sum + it.total);
    }

    final sDay = epochDay(start);
    final eDay = epochDay(end);
    final res = <DayPoint>[];
    for (int d = sDay; d <= eDay; d++) {
      res.add(DayPoint(d, map[d] ?? 0));
    }
    return res;
  }

  /// Tren omzet per produk per hari.
  List<DayPoint> productRevenueTrend(Box<Sale> salesBox, String productId, DateTime start, DateTime end) {
    final sales = _salesInRange(salesBox, start, end);
    final map = <int, double>{};
    for (final s in sales) {
      final day = s.dateEpochDay;
      final total = s.items
          .where((it) => it.productId == productId)
          .fold(0.0, (sum, it) => sum + it.total);
      if (total > 0) {
        map[day] = (map[day] ?? 0) + total;
      }
    }

    final sDay = epochDay(start);
    final eDay = epochDay(end);
    final res = <DayPoint>[];
    for (int d = sDay; d <= eDay; d++) {
      res.add(DayPoint(d, map[d] ?? 0));
    }
    return res;
  }
}
