import 'package:hive/hive.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/stock_movement.dart';
import '../../domain/models/cash_entry.dart';
import '../../core/ids.dart';

class SalesRepo {
  final Box<Sale> salesBox;
  final Box<Product> productsBox;
  final Box<StockMovement> movementsBox;
  final Box<CashEntry> cashBox;

  SalesRepo(this.salesBox, this.productsBox, this.movementsBox, this.cashBox);

  List<Sale> all() =>
      salesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Sale sale) async {
    // Buku kas: penjualan = uang masuk, kecuali jika Hutang.
    if (sale.paymentMethod.toLowerCase() != 'hutang') {
      final cashId = newId('cash');
      await cashBox.put(
        cashId,
        CashEntry(
          id: cashId,
          dateEpochDay: sale.dateEpochDay,
          direction: 'in',
          source: 'sale',
          method: sale.paymentMethod,
          note: 'Penjualan',
          amount: sale.totalSales,
          refId: sale.id,
        ),
      );
    }

    for (final item in sale.items) {
      final p = productsBox.get(item.productId);
      if (p == null) continue;

      // Validasi agar tidak jual melebihi stok (lebih aman dibanding clamp ke 0)
      if (item.qty > p.stockQty) {
        throw StateError('Stok tidak cukup untuk ${p.name}. Stok: ${p.stockQty.toStringAsFixed(2)}');
      }

      p.stockQty = (p.stockQty - item.qty).clamp(0, double.infinity);
      await productsBox.put(p.id, p);

      final mvId = newId('mv');
      await movementsBox.put(
        mvId,
        StockMovement(
          id: mvId,
          dateEpochDay: sale.dateEpochDay,
          productId: item.productId,
          type: 'sale',
          qtyDelta: -item.qty,
          // Simpan referensi transaksi di note agar bisa di-rollback saat hapus
          note: 'Penjualan#${sale.id}',
        ),
      );
    }

    await salesBox.put(sale.id, sale);
  }

  Future<void> remove(String id) async {
    final sale = salesBox.get(id);
    if (sale == null) {
      await salesBox.delete(id);
      return;
    }

    // 1) Hapus movement terkait penjualan ini
    final mvKeysToDelete = <dynamic>[];
    for (final entry in movementsBox.toMap().entries) {
      final mv = entry.value;
      if (mv.type == 'sale' && mv.note == 'Penjualan#$id') {
        mvKeysToDelete.add(entry.key);
      }
    }
    for (final k in mvKeysToDelete) {
      await movementsBox.delete(k);
    }

    // 2) Hapus transaksi penjualan
    await salesBox.delete(id);

    // 2b) Hapus cash entry terkait
    final cashKeys = <dynamic>[];
    for (final entry in cashBox.toMap().entries) {
      final c = entry.value;
      if (c.source == 'sale' && c.refId == id) cashKeys.add(entry.key);
    }
    for (final k in cashKeys) {
      await cashBox.delete(k);
    }

    // 3) Recalc stok untuk produk yang terdampak
    final affectedProductIds = sale.items.map((e) => e.productId).toSet();
    for (final productId in affectedProductIds) {
      final product = productsBox.get(productId);
      if (product == null) continue;

      final stock = movementsBox.values
          .where((m) => m.productId == productId)
          .fold<double>(0, (sum, m) => sum + m.qtyDelta);
      product.stockQty = stock.clamp(0, double.infinity);
      await productsBox.put(product.id, product);
    }
  }
}
