import 'package:hive/hive.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/cash_entry.dart';
import '../../core/ids.dart';

class DebtRepo {
  final Box<Debt> box;
  final Box<CashEntry> cashBox;
  DebtRepo(this.box, this.cashBox);

  List<Debt> all() => box.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));
  Future<void> add(Debt d) => box.put(d.id, d);
  Future<void> remove(String id) => box.delete(id);

  Future<void> addPayment(String id, double amount, {required int dateEpochDay, String method = 'Cash'}) async {
    final d = box.get(id);
    if (d == null) return;
    d.paid = (d.paid + amount).clamp(0, d.principal);
    await box.put(d.id, d);

    final cashId = newId('cash');
    await cashBox.put(
      cashId,
      CashEntry(
        id: cashId,
        dateEpochDay: dateEpochDay,
        direction: 'out',
        source: 'debt_payment',
        method: method,
        note: 'Bayar hutang: ${d.creditor}',
        amount: amount,
        refId: d.id,
      ),
    );
  }
}
