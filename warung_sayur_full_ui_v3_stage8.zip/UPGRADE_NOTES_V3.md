# Upgrade v3
Fitur baru:
1) Penyesuaian stok (Tambah/Kurangi) + wajib alasan
   - Akses: Produk -> tap produk (Detail) atau menu (⋮) -> Penyesuaian stok
2) Riwayat stok per produk (Pembelian/Penjualan/Penyesuaian)
3) Field uang format ribuan otomatis (84.000) untuk:
   - Harga beli, harga jual, biaya, hutang, pembayaran hutang

Catatan:
- Penyesuaian stok tidak mengubah HPP (HPP tetap dari pembelian).
