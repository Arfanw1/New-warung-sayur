double hppWeightedAverage({required double totalQty, required double totalCost}) {
  if (totalQty <= 0) return 0;
  return totalCost / totalQty;
}

double recommendedSellPrice({required double hpp, required double marginPercent}) {
  final m = marginPercent / 100.0;
  final clamped = m.clamp(0.0, 0.95);
  final denom = 1 - clamped;
  if (denom <= 0) return hpp;
  return hpp / denom;
}

/// Margin aktual (%) berdasarkan harga jual dan HPP.
/// Jika sellPrice <= 0 maka 0.
double actualMarginPercent({required double sellPrice, required double hpp}) {
  if (sellPrice <= 0) return 0;
  return ((sellPrice - hpp) / sellPrice) * 100.0;
}

/// Pembulatan ke atas ke kelipatan 100 (cocok untuk harga rupiah).
double roundUpToHundreds(double v) {
  if (v <= 0) return 0;
  return (v / 100.0).ceilToDouble() * 100.0;
}

double grossProfit({required double totalSales, required double totalHpp}) => totalSales - totalHpp;

double netProfit({required double totalSales, required double totalHpp, required double totalExpenses}) =>
    grossProfit(totalSales: totalSales, totalHpp: totalHpp) - totalExpenses;
