import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';

import '../dashboard/dashboard_page.dart';
import '../products/products_page.dart';
import '../purchases/purchases_page.dart';
import '../sales/sales_page.dart';
import '../cash/cash_page.dart';

import '../expenses/expenses_page.dart';
import '../debts/debts_page.dart';
import '../reports/reports_page.dart';
import '../settings/backup_page.dart';
import '../analytics/analytics_page.dart';
import '../restock/restock_page.dart';
import '../activity/activity_log_page.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  int index = 0;

  // Bottom navigation: menu inti harian
  final pages = const [
    DashboardPage(),
    ProductsPage(),
    SalesPage(),
    PurchasesPage(),
    CashPage(),
  ];

  final labels = const ['Dashboard', 'Produk', 'Penjualan', 'Pembelian', 'Kas'];

  final iconAssets = const [
    'assets/icons/ic_dashboard.png',
    'assets/icons/ic_products.png',
    'assets/icons/ic_sales.png',
    'assets/icons/ic_purchases.png',
    'assets/icons/ic_cash.png',
  ];

  Widget _navIcon(String asset) => Image.asset(asset, width: 24, height: 24);

  void _openDrawerPage(String title, Widget page) {
    Navigator.of(context).pop(); // close drawer
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: Text(title)),
          body: page,
        ),
      ),
    );
  }

  Future<void> _switchRole() async {
    final meta = ref.read(metaRepoProvider);
    final settings = ref.read(settingsRepoProvider);
    final cur = meta.role;
    final next = cur == 'admin' ? 'kasir' : 'admin';

    if (next == 'admin' && settings.get().pinEnabled) {
      final controller = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Masuk mode Admin'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(labelText: 'PIN Admin'),
            obscureText: true,
            keyboardType: TextInputType.number,
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('OK')),
          ],
        ),
      );
      if (ok != true) return;
      if (!settings.verifyPin(controller.text)) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN salah.')));
        }
        return;
      }
    }

    await meta.setRole(next);
    await ref.read(activityLogRepoProvider).log('switch_role', 'Role berubah: $cur -> $next');
    if (mounted) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Mode: $next')));
    }
  }

  @override
  void initState() {
    super.initState();
    // Tahap 11: auto-backup berjalan saat app dibuka (setelah PIN gate lewat).
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await ref.read(backupServiceProvider).autoBackupIfDue(
              meta: ref.read(metaRepoProvider),
              logs: ref.read(activityLogRepoProvider),
            );
      } catch (_) {}
    });
  }

  @override
  Widget build(BuildContext context) {
    final role = ref.watch(metaRepoProvider).role;
    return Scaffold(
      appBar: AppBar(title: Text(labels[index])),
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            children: [
              const ListTile(
                title: Text('Menu'),
              ),
              ListTile(
                leading: const Icon(Icons.admin_panel_settings_outlined),
                title: Text('Mode: ${role == 'admin' ? 'Admin' : 'Kasir'}'),
                subtitle: const Text('Ketuk untuk ganti mode'),
                onTap: () async {
                  Navigator.of(context).pop();
                  await _switchRole();
                },
              ),
              ListTile(
                leading: const Icon(Icons.receipt_long),
                title: const Text('Laporan'),
                onTap: () => _openDrawerPage('Laporan', const ReportsPage()),
              ),
              ListTile(
                leading: const Icon(Icons.insights),
                title: const Text('Analytics'),
                onTap: () => _openDrawerPage('Analytics', const AnalyticsPage()),
              ),
              ListTile(
                leading: const Icon(Icons.shopping_basket_outlined),
                title: const Text('Saran Belanja'),
                onTap: () => _openDrawerPage('Saran Belanja', const RestockPage()),
              ),
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('Log Aktivitas'),
                onTap: () => _openDrawerPage('Log Aktivitas', const ActivityLogPage()),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.payments_outlined),
                title: const Text('Hutang'),
                onTap: () => _openDrawerPage('Hutang', const DebtsPage()),
              ),
              ListTile(
                leading: const Icon(Icons.request_quote_outlined),
                title: const Text('Biaya'),
                onTap: () => _openDrawerPage('Biaya', const ExpensesPage()),
              ),
              const Divider(),
              if (role == 'admin')
                ListTile(
                  leading: const Icon(Icons.backup_outlined),
                  title: const Text('Backup'),
                  onTap: () => _openDrawerPage('Backup', const BackupPage()),
                ),
            ],
          ),
        ),
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: List.generate(
          labels.length,
          (i) => NavigationDestination(
            icon: _navIcon(iconAssets[i]),
            selectedIcon: _navIcon(iconAssets[i]),
            label: labels[i],
          ),
        ),
      ),
    );
  }
}
