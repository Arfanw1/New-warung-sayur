import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../core/dates.dart';
import '../../core/calc.dart';
import '../../providers.dart';
import 'stock_adjustment_page.dart';

class ProductDetailPage extends ConsumerWidget {
  final String productId;
  const ProductDetailPage({super.key, required this.productId});

  String _titleForType(String t) {
    switch (t) {
      case 'purchase':
        return 'Pembelian';
      case 'sale':
        return 'Penjualan';
      case 'adjust':
        return 'Penyesuaian';
      default:
        return t;
    }
  }

  /// Tahap 5 (Smart Pricing & Alert): Saran harga jual + status margin.
  Widget _smartPricingCard(BuildContext context, WidgetRef ref, dynamic p) {
    final sell = (p.activeSellPrice as num).toDouble();
    final hpp = (p.avgHpp as num).toDouble();
    final target = (p.defaultMarginPercent as num).toDouble();
    final actual = actualMarginPercent(sellPrice: sell, hpp: hpp);
    final recRaw = recommendedSellPrice(hpp: hpp, marginPercent: target);
    final rec = roundUpToHundreds(recRaw);

    final isLoss = sell > 0 && sell < hpp;
    final isBelowTarget = sell > 0 && !isLoss && actual + 1e-9 < target;

    IconData icon = Icons.check_circle_outline;
    String status = 'Margin aman';
    if (isLoss) {
      icon = Icons.error_outline;
      status = 'Rugi (harga jual < HPP)';
    } else if (isBelowTarget) {
      icon = Icons.warning_amber_rounded;
      status = 'Margin di bawah target';
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(status, style: Theme.of(context).textTheme.titleMedium),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text('Target margin: ${target.toStringAsFixed(1)}%  •  Margin aktual: ${actual.toStringAsFixed(1)}%'),
            const SizedBox(height: 6),
            Text('Saran harga jual (dibulatkan): ${fmtMoney(rec)}'),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: rec <= 0
                        ? null
                        : () async {
                            final ok = await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text('Terapkan harga saran?'),
                                content: Text('Ubah harga jual menjadi ${fmtMoney(rec)} ?'),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                                  FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Terapkan')),
                                ],
                              ),
                            );
                            if (ok == true) {
                              final repo = ref.read(productRepoProvider);
                              p.activeSellPrice = rec;
                              await repo.upsert(p);
                              if (context.mounted) {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(const SnackBar(content: Text('Harga jual diperbarui')));
                              }
                            }
                          },
                    icon: const Icon(Icons.price_change_outlined),
                    label: const Text('Terapkan saran'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Tahap 10: Grafik riwayat harga beli (diambil dari transaksi pembelian)
  Widget _buyPriceHistoryCard(BuildContext context, WidgetRef ref) {
    final purchases = ref.watch(purchasesBoxProvider).values;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day).subtract(const Duration(days: 29));

    // dayEpoch -> (sum(qty*price), sum(qty))
    final Map<int, List<double>> agg = {};
    for (final p in purchases) {
      final day = p.dateEpochDay;
      final dt = DateTime.utc(1970, 1, 1).add(Duration(days: day));
      if (dt.isBefore(start)) continue;
      for (final it in p.items) {
        if (it.productId != productId) continue;
        final cur = agg.putIfAbsent(day, () => [0.0, 0.0]);
        cur[0] += it.qty * it.buyPrice;
        cur[1] += it.qty;
      }
    }

    if (agg.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Text('Belum ada data harga beli pada 30 hari terakhir.'),
        ),
      );
    }

    final daysSorted = agg.keys.toList()..sort();
    final spots = <FlSpot>[];
    double minP = double.infinity;
    double maxP = 0;
    double lastP = 0;
    for (var i = 0; i < daysSorted.length; i++) {
      final day = daysSorted[i];
      final sum = agg[day]![0];
      final qty = agg[day]![1];
      final price = qty <= 0 ? 0.0 : sum / qty;
      lastP = price;
      if (price < minP) minP = price;
      if (price > maxP) maxP = price;
      spots.add(FlSpot(i.toDouble(), price));
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Min: ${fmtMoney(minP)}', style: Theme.of(context).textTheme.bodySmall),
                Text('Max: ${fmtMoney(maxP)}', style: Theme.of(context).textTheme.bodySmall),
                Text('Terakhir: ${fmtMoney(lastP)}', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 180,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: true),
                  titlesData: const FlTitlesData(show: false),
                  borderData: FlBorderData(show: true),
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      dotData: const FlDotData(show: false),
                      barWidth: 3,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(productRepoProvider).getById(productId);
    if (p == null) return const Scaffold(body: Center(child: Text('Produk tidak ditemukan')));

    final movements = ref.watch(movementRepoProvider).byProduct(productId).take(50).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(p.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune),
            tooltip: 'Penyesuaian stok',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => StockAdjustmentPage(productId: productId)),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: Text(p.name),
              subtitle: Text('Stok: ${p.stockQty.toStringAsFixed(2)} ${p.unit}\nHPP: ${fmtMoney(p.avgHpp)}\nHarga jual: ${fmtMoney(p.activeSellPrice)}'),
              isThreeLine: true,
            ),
          ),

          const SizedBox(height: 12),
          _smartPricingCard(context, ref, p),

const SizedBox(height: 12),
Text('Riwayat Harga Beli', style: Theme.of(context).textTheme.titleMedium),
const SizedBox(height: 8),
_buyPriceHistoryCard(context, ref),
const SizedBox(height: 12),
Text('Riwayat Stok', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (movements.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Belum ada riwayat stok.'))),
          ...movements.map((m) => Card(
                child: ListTile(
                  title: Text(_titleForType(m.type)),
                  subtitle: Text('${fmtDateFromEpochDay(m.dateEpochDay)} • ${m.note.split('#').first}'),
                  trailing: Text(
                    (m.qtyDelta >= 0 ? '+' : '') + m.qtyDelta.toStringAsFixed(2) + ' ' + p.unit,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: m.qtyDelta >= 0 ? Colors.green : Colors.red,
                    ),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
