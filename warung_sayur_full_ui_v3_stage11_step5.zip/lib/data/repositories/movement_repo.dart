import 'package:hive/hive.dart';
import '../../domain/models/stock_movement.dart';

class MovementRepo {
  final Box<StockMovement> box;
  MovementRepo(this.box);

  List<StockMovement> all() =>
      box.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  List<StockMovement> byProduct(String productId) =>
      box.values.where((m) => m.productId == productId).toList()
        ..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(StockMovement m) => box.put(m.id, m);

  Future<void> clear() => box.clear();
}
