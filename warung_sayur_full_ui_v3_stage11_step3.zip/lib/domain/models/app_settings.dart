class AppSettings {
  final String id;
  bool pinEnabled;
  /// hash SHA256 dari PIN (string). Kosong jika belum diset.
  String pinHash;

  AppSettings({required this.id, required this.pinEnabled, required this.pinHash});
}
