import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../domain/models/product.dart';
import '../products/product_detail_page.dart';
import '../widgets/empty_state.dart';

class RestockPage extends ConsumerWidget {
  const RestockPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(productRepoProvider);
    final products = repo.all();

    final items = <_RestockItem>[];
    for (final p in products) {
      final target = (p.targetStock > 0) ? p.targetStock : p.minStock;
      if (target <= 0) continue;
      if (p.stockQty < target) {
        items.add(_RestockItem(
          product: p,
          target: target,
          suggestQty: (target - p.stockQty),
        ));
      }
    }
    items.sort((a, b) => b.suggestQty.compareTo(a.suggestQty));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Saran Belanja'),
      ),
      body: items.isEmpty
          ? const EmptyState(
              title: 'Tidak ada saran belanja',
              subtitle: 'Semua produk masih aman. Atur Target Stok atau Stok Minimum jika ingin rekomendasi.',
              icon: Icons.check_circle_outline,
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final it = items[i];
                final p = it.product;
                return Card(
                  child: ListTile(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id)),
                    ),
                    title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('Stok: ${_fmt(p.stockQty)} ${p.unit}  •  Target: ${_fmt(it.target)} ${p.unit}'),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        const Text('Beli', style: TextStyle(fontSize: 12)),
                        Text('${_fmt(it.suggestQty)} ${p.unit}', style: const TextStyle(fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  String _fmt(double v) {
    // tampilkan tanpa desimal jika bilangan bulat
    if (v % 1 == 0) return v.toStringAsFixed(0);
    return v.toStringAsFixed(2);
  }
}

class _RestockItem {
  final Product product;
  final double target;
  final double suggestQty;
  _RestockItem({required this.product, required this.target, required this.suggestQty});
}
