import 'package:intl/intl.dart';

int epochDay(DateTime dt) {
  final d = DateTime(dt.year, dt.month, dt.day);
  final base = DateTime.utc(1970, 1, 1);
  final du = DateTime.utc(d.year, d.month, d.day);
  return du.difference(base).inDays;
}

DateTime fromEpochDay(int day) {
  final base = DateTime.utc(1970, 1, 1);
  final du = base.add(Duration(days: day));
  return DateTime(du.year, du.month, du.day);
}

String fmtDate(DateTime dt) => DateFormat('yyyy-MM-dd').format(dt);
String fmtDateFromEpochDay(int day) => fmtDate(fromEpochDay(day));

String fmtMoney(num n) {
  final f = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
  return f.format(n);
}
