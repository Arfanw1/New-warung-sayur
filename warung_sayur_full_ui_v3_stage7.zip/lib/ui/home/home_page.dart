import 'package:flutter/material.dart';

import '../dashboard/dashboard_page.dart';
import '../products/products_page.dart';
import '../purchases/purchases_page.dart';
import '../sales/sales_page.dart';
import '../expenses/expenses_page.dart';
import '../debts/debts_page.dart';
import '../cash/cash_page.dart';
import '../reports/reports_page.dart';
import '../settings/backup_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    DashboardPage(),
    ProductsPage(),
    PurchasesPage(),
    SalesPage(),
    ExpensesPage(),
    DebtsPage(),
    CashPage(),
    ReportsPage(),
    BackupPage(),
  ];

  final labels = const ['Dashboard', 'Produk', 'Pembelian', 'Penjualan', 'Biaya', 'Hutang', 'Kas', 'Laporan', 'Backup'];
  final iconAssets = const [
    'assets/icons/ic_dashboard.png',
    'assets/icons/ic_products.png',
    'assets/icons/ic_purchases.png',
    'assets/icons/ic_sales.png',
    'assets/icons/ic_expenses.png',
    'assets/icons/ic_debts.png',
    'assets/icons/ic_cash.png',
    'assets/icons/ic_reports.png',
    'assets/icons/ic_backup.png',
  ];

  Widget _navIcon(String asset) => Image.asset(asset, width: 24, height: 24);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(labels[index])),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: List.generate(
          labels.length,
          (i) => NavigationDestination(
            icon: _navIcon(iconAssets[i]),
            selectedIcon: _navIcon(iconAssets[i]),
            label: labels[i],
          ),
        ),
      ),
    );
  }
}
