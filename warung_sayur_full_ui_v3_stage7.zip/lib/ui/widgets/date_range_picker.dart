import 'package:flutter/material.dart';

Future<DateTimeRange?> pickDateRange(BuildContext context, {DateTimeRange? initial}) {
  final now = DateTime.now();
  return showDateRangePicker(
    context: context,
    firstDate: DateTime(2020),
    lastDate: DateTime(now.year + 5),
    initialDateRange: initial,
    helpText: 'Pilih rentang tanggal',
  );
}
