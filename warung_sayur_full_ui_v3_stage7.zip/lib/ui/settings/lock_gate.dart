import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';

class LockGate extends ConsumerStatefulWidget {
  final Widget child;
  const LockGate({super.key, required this.child});

  @override
  ConsumerState<LockGate> createState() => _LockGateState();
}

class _LockGateState extends ConsumerState<LockGate> {
  bool unlocked = false;
  final pinC = TextEditingController();

  @override
  void dispose() {
    pinC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsRepoProvider).get();
    final needsPin = settings.pinEnabled;
    if (!needsPin) return widget.child;

    if (unlocked) return widget.child;

    return Scaffold(
      appBar: AppBar(title: const Text('Masukkan PIN')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Aplikasi terkunci. Masukkan PIN untuk membuka.'),
            const SizedBox(height: 12),
            TextField(
              controller: pinC,
              keyboardType: TextInputType.number,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'PIN', border: OutlineInputBorder()),
              maxLength: 8,
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () {
                final ok = ref.read(settingsRepoProvider).verifyPin(pinC.text.trim());
                if (!ok) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PIN salah')));
                  return;
                }
                setState(() => unlocked = true);
              },
              icon: const Icon(Icons.lock_open),
              label: const Text('Buka'),
            ),
          ],
        ),
      ),
    );
  }
}
