# Patch Qty di list

- Pembelian & Penjualan sekarang menampilkan: **Nama qty unit** + **Qty total**.
- File yang diubah:
  - lib/ui/purchases/purchases_page.dart
  - lib/ui/sales/sales_page.dart
