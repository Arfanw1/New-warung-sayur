import 'package:hive/hive.dart';
import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../core/calc.dart';

class PurchaseRepo {
  final Box<Purchase> purchasesBox;
  final Box<Product> productsBox;

  PurchaseRepo(this.purchasesBox, this.productsBox);

  List<Purchase> all() => purchasesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Purchase purchase) async {
    await purchasesBox.put(purchase.id, purchase);

    for (final item in purchase.items) {
      final product = productsBox.get(item.productId);
      if (product == null) continue;

      final oldQty = product.stockQty;
      final oldHpp = product.avgHpp;

      final incomingQty = item.qty;
      final incomingCost = item.qty * item.buyPrice;

      final oldCost = oldQty * oldHpp;
      final newTotalQty = oldQty + incomingQty;
      final newTotalCost = oldCost + incomingCost;

      product.stockQty = newTotalQty;
      product.avgHpp = hppWeightedAverage(totalQty: newTotalQty, totalCost: newTotalCost);

      await product.save();
    }
  }

  Future<void> remove(String id) async => purchasesBox.delete(id);
}
