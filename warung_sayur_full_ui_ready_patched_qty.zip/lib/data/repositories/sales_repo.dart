import 'package:hive/hive.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';

class SalesRepo {
  final Box<Sale> salesBox;
  final Box<Product> productsBox;

  SalesRepo(this.salesBox, this.productsBox);

  List<Sale> all() =>
      salesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Sale sale) async {
    for (final item in sale.items) {
      final p = productsBox.get(item.productId);
      if (p == null) continue;

      p.stockQty = (p.stockQty - item.qty).clamp(0, double.infinity);

      // ✅ simpan kembali ke Hive Box
      await productsBox.put(p.id, p);
    }

    await salesBox.put(sale.id, sale);
  }

  Future<void> remove(String id) async => salesBox.delete(id);
}