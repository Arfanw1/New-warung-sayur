class Expense {
  final String id;
  int dateEpochDay;
  String note;
  double amount;

  Expense({required this.id, required this.dateEpochDay, required this.note, required this.amount});

  Map<String, dynamic> toJson() => {'id': id, 'dateEpochDay': dateEpochDay, 'note': note, 'amount': amount};

  static Expense fromJson(Map<String, dynamic> j) => Expense(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        note: j['note'] as String,
        amount: (j['amount'] as num).toDouble(),
      );
}
