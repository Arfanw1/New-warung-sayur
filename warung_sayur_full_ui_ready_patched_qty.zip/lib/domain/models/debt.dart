class Debt {
  final String id;
  int dateEpochDay;
  String creditor;
  String note;
  double principal;
  double paid;

  Debt({
    required this.id,
    required this.dateEpochDay,
    required this.creditor,
    required this.note,
    required this.principal,
    required this.paid,
  });

  double get remaining => (principal - paid).clamp(0, double.infinity);
  bool get isSettled => remaining <= 0.000001;

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateEpochDay': dateEpochDay,
        'creditor': creditor,
        'note': note,
        'principal': principal,
        'paid': paid,
      };

  static Debt fromJson(Map<String, dynamic> j) => Debt(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        creditor: j['creditor'] as String,
        note: j['note'] as String,
        principal: (j['principal'] as num).toDouble(),
        paid: (j['paid'] as num).toDouble(),
      );
}
