import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../widgets/empty_state.dart';
import 'purchase_form.dart';

class PurchasesPage extends ConsumerWidget {
  const PurchasesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(purchaseRepoProvider);
    final items = repo.all();

    if (items.isEmpty) {
      return Stack(
        children: [
          const EmptyState(
            title: 'Belum ada pembelian',
            subtitle: 'Catat pembelian untuk mengisi stok dan menghitung HPP.',
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PurchaseFormPage())),
              child: const Icon(Icons.add),
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, i) {
            final p = items[i];
            final productsRepo = ref.watch(productRepoProvider);

            final totalQty = p.items.fold<double>(0, (sum, it) => sum + it.qty);
            final total = p.items.fold<double>(0, (sum, it) => sum + it.qty * it.buyPrice);

            final summary = p.items.map((it) {
              final pr = productsRepo.getById(it.productId);
              final name = pr?.name ?? 'Produk';
              final unit = pr?.unit ?? '';
              return '$name ${it.qty.toStringAsFixed(2)} $unit';
            }).join(', ');

            return Card(
              child: ListTile(
                title: Text('Pembelian • ${fmtDateFromEpochDay(p.dateEpochDay)}'),
                subtitle: Text('${p.items.length} item • Total: ${fmtMoney(total)}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    await repo.remove(p.id);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pembelian dihapus')));
                  },
                ),
              ),
            );
          },
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PurchaseFormPage())),
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}
