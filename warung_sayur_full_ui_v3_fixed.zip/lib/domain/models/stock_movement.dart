class StockMovement {
  final String id;
  int dateEpochDay;
  String productId;

  /// type: purchase | sale | adjust
  String type;

  /// qtyDelta: + for in, - for out
  double qtyDelta;

  /// optional note/reason
  String note;

  StockMovement({
    required this.id,
    required this.dateEpochDay,
    required this.productId,
    required this.type,
    required this.qtyDelta,
    required this.note,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateEpochDay': dateEpochDay,
        'productId': productId,
        'type': type,
        'qtyDelta': qtyDelta,
        'note': note,
      };

  static StockMovement fromJson(Map<String, dynamic> j) => StockMovement(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        productId: j['productId'] as String,
        type: j['type'] as String,
        qtyDelta: (j['qtyDelta'] as num).toDouble(),
        note: j['note'] as String? ?? '',
      );
}
