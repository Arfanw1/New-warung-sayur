import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../core/calc.dart';
import '../../domain/models/product.dart';
import '../widgets/empty_state.dart';
import '../widgets/number_field.dart';
import 'product_detail_page.dart';
import 'stock_adjustment_page.dart';
import '../widgets/money_field.dart';

class ProductsPage extends ConsumerWidget {
  const ProductsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(productRepoProvider);
    final items = repo.all();

    if (items.isEmpty) {
      return Stack(
        children: [
          const EmptyState(
            title: 'Belum ada produk',
            subtitle: 'Tambahkan produk dulu, lalu kamu bisa input pembelian & penjualan.',
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton(
              onPressed: () => _openForm(context, ref),
              child: const Icon(Icons.add),
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, i) {
            final p = items[i];
            final rec = recommendedSellPrice(hpp: p.avgHpp, marginPercent: p.defaultMarginPercent);
            return Card(
              child: ListTile(
                title: Text(p.name),
                subtitle: Text(
                  'Stok: ${p.stockQty.toStringAsFixed(2)} ${p.unit} • HPP: ${fmtMoney(p.avgHpp)}\n'
                  'Harga jual: ${fmtMoney(p.activeSellPrice)} • Rekomendasi: ${fmtMoney(rec)}',
                ),
                isThreeLine: true,
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id))),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Hapus produk?'),
                        content: Text('Produk "${p.name}" akan dihapus.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                        ],
                      ),
                    );
                    if (ok == true) {
                      await repo.remove(p.id);
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Produk dihapus')));
                    }
                  },
                ),
              ),
            );
          },
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => _openForm(context, ref),
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }

  Future<void> _openForm(BuildContext context, WidgetRef ref, {Product? product}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ProductFormPage(product: product)),
    );
  }
}

class ProductFormPage extends ConsumerStatefulWidget {
  final Product? product;
  const ProductFormPage({super.key, this.product});

  @override
  ConsumerState<ProductFormPage> createState() => _ProductFormPageState();
}

class _ProductFormPageState extends ConsumerState<ProductFormPage> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController nameC;
  late final TextEditingController unitC;
  late final TextEditingController marginC;
  late final TextEditingController sellC;

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    nameC = TextEditingController(text: p?.name ?? '');
    unitC = TextEditingController(text: p?.unit ?? 'kg');
    marginC = TextEditingController(text: (p?.defaultMarginPercent ?? 20).toStringAsFixed(0));
    sellC = TextEditingController(text: (p?.activeSellPrice ?? 0).toStringAsFixed(0));
  }

  @override
  void dispose() {
    nameC.dispose();
    unitC.dispose();
    marginC.dispose();
    sellC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.product != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Edit Produk' : 'Tambah Produk')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: nameC,
              decoration: const InputDecoration(labelText: 'Nama Produk'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: unitC,
              decoration: const InputDecoration(labelText: 'Satuan (kg/ikat/pcs)'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            NumberField(controller: marginC, label: 'Margin default (%)', requiredField: true),
            const SizedBox(height: 12),
            MoneyField(controller: sellC, label: 'Harga jual aktif', requiredField: true),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final repo = ref.read(productRepoProvider);

    final name = nameC.text.trim();
    final unit = unitC.text.trim();
    final margin = double.parse(marginC.text.trim());
    final sell = (parseRupiah(sellC.text.trim()) ?? 0).toDouble();

    if (margin < 0 || margin > 95) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Margin harus 0–95%')));
      return;
    }

    final p = widget.product;
    if (p == null) {
      final np = Product(
        id: newId('prd'),
        name: name,
        unit: unit,
        defaultMarginPercent: margin,
        activeSellPrice: sell,
        stockQty: 0,
        avgHpp: 0,
      );
      await repo.upsert(np);
    } else {
      p.name = name;
      p.unit = unit;
      p.defaultMarginPercent = margin;
      p.activeSellPrice = sell;
      await repo.upsert(p);
    }

    if (!mounted) return;
    Navigator.pop(context);
  }
}
