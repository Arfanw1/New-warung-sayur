import 'package:hive/hive.dart';

import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/stock_movement.dart';

class ProductAdapter extends TypeAdapter<Product> {
  @override
  final int typeId = 1;
  @override
  Product read(BinaryReader reader) => Product(
        id: reader.readString(),
        name: reader.readString(),
        unit: reader.readString(),
        defaultMarginPercent: reader.readDouble(),
        activeSellPrice: reader.readDouble(),
        stockQty: reader.readDouble(),
        avgHpp: reader.readDouble(),
      );
  @override
  void write(BinaryWriter writer, Product obj) {
    writer
      ..writeString(obj.id)
      ..writeString(obj.name)
      ..writeString(obj.unit)
      ..writeDouble(obj.defaultMarginPercent)
      ..writeDouble(obj.activeSellPrice)
      ..writeDouble(obj.stockQty)
      ..writeDouble(obj.avgHpp);
  }
}

class PurchaseItemAdapter extends TypeAdapter<PurchaseItem> {
  @override
  final int typeId = 2;
  @override
  PurchaseItem read(BinaryReader reader) =>
      PurchaseItem(productId: reader.readString(), qty: reader.readDouble(), buyPrice: reader.readDouble());
  @override
  void write(BinaryWriter writer, PurchaseItem obj) {
    writer
      ..writeString(obj.productId)
      ..writeDouble(obj.qty)
      ..writeDouble(obj.buyPrice);
  }
}

class PurchaseAdapter extends TypeAdapter<Purchase> {
  @override
  final int typeId = 3;
  @override
  Purchase read(BinaryReader reader) =>
      Purchase(id: reader.readString(), dateEpochDay: reader.readInt(), items: (reader.readList()).cast<PurchaseItem>());
  @override
  void write(BinaryWriter writer, Purchase obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeList(obj.items);
  }
}

class SaleItemAdapter extends TypeAdapter<SaleItem> {
  @override
  final int typeId = 4;
  @override
  SaleItem read(BinaryReader reader) => SaleItem(
        productId: reader.readString(),
        qty: reader.readDouble(),
        sellPrice: reader.readDouble(),
        hppAtSale: reader.readDouble(),
      );
  @override
  void write(BinaryWriter writer, SaleItem obj) {
    writer
      ..writeString(obj.productId)
      ..writeDouble(obj.qty)
      ..writeDouble(obj.sellPrice)
      ..writeDouble(obj.hppAtSale);
  }
}

class SaleAdapter extends TypeAdapter<Sale> {
  @override
  final int typeId = 5;
  @override
  Sale read(BinaryReader reader) =>
      Sale(id: reader.readString(), dateEpochDay: reader.readInt(), items: (reader.readList()).cast<SaleItem>());
  @override
  void write(BinaryWriter writer, Sale obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeList(obj.items);
  }
}

class ExpenseAdapter extends TypeAdapter<Expense> {
  @override
  final int typeId = 6;
  @override
  Expense read(BinaryReader reader) =>
      Expense(id: reader.readString(), dateEpochDay: reader.readInt(), note: reader.readString(), amount: reader.readDouble());
  @override
  void write(BinaryWriter writer, Expense obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.note)
      ..writeDouble(obj.amount);
  }
}

class StockMovementAdapter extends TypeAdapter<StockMovement> {
  @override
  final int typeId = 8;

  @override
  StockMovement read(BinaryReader reader) => StockMovement(
        id: reader.readString(),
        dateEpochDay: reader.readInt(),
        productId: reader.readString(),
        type: reader.readString(),
        qtyDelta: reader.readDouble(),
        note: reader.readString(),
      );

  @override
  void write(BinaryWriter writer, StockMovement obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.productId)
      ..writeString(obj.type)
      ..writeDouble(obj.qtyDelta)
      ..writeString(obj.note);
  }
}

class DebtAdapter extends TypeAdapter<Debt> {
  @override
  final int typeId = 7;
  @override
  Debt read(BinaryReader reader) => Debt(
        id: reader.readString(),
        dateEpochDay: reader.readInt(),
        creditor: reader.readString(),
        note: reader.readString(),
        principal: reader.readDouble(),
        paid: reader.readDouble(),
      );
  @override
  void write(BinaryWriter writer, Debt obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.creditor)
      ..writeString(obj.note)
      ..writeDouble(obj.principal)
      ..writeDouble(obj.paid);
  }
}

void registerAdapters() {
  if (!Hive.isAdapterRegistered(1)) Hive.registerAdapter(ProductAdapter());
  if (!Hive.isAdapterRegistered(2)) Hive.registerAdapter(PurchaseItemAdapter());
  if (!Hive.isAdapterRegistered(3)) Hive.registerAdapter(PurchaseAdapter());
  if (!Hive.isAdapterRegistered(4)) Hive.registerAdapter(SaleItemAdapter());
  if (!Hive.isAdapterRegistered(5)) Hive.registerAdapter(SaleAdapter());
  if (!Hive.isAdapterRegistered(6)) Hive.registerAdapter(ExpenseAdapter());
  if (!Hive.isAdapterRegistered(7)) Hive.registerAdapter(DebtAdapter());
  if (!Hive.isAdapterRegistered(8)) Hive.registerAdapter(StockMovementAdapter());
}

