import 'package:hive/hive.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/stock_movement.dart';
import '../../core/ids.dart';

class SalesRepo {
  final Box<Sale> salesBox;
  final Box<Product> productsBox;
  final Box<StockMovement> movementsBox;

  SalesRepo(this.salesBox, this.productsBox, this.movementsBox);

  List<Sale> all() =>
      salesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Sale sale) async {
    for (final item in sale.items) {
      final p = productsBox.get(item.productId);
      if (p == null) continue;

      p.stockQty = (p.stockQty - item.qty).clamp(0, double.infinity);
      await productsBox.put(p.id, p);

      await movementsBox.put(
        newId('mv'),
        StockMovement(
          id: newId('mv'),
          dateEpochDay: sale.dateEpochDay,
          productId: item.productId,
          type: 'sale',
          qtyDelta: -item.qty,
          note: 'Penjualan',
        ),
      );
    }

    await salesBox.put(sale.id, sale);
  }

  Future<void> remove(String id) async => salesBox.delete(id);
}
