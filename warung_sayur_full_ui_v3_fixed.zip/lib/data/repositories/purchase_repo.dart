import 'package:hive/hive.dart';
import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../core/calc.dart';
import '../../domain/models/stock_movement.dart';
import '../../core/ids.dart';

class PurchaseRepo {
  final Box<Purchase> purchasesBox;
  final Box<Product> productsBox;
  final Box<StockMovement> movementsBox;

  PurchaseRepo(this.purchasesBox, this.productsBox, this.movementsBox);

  List<Purchase> all() => purchasesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Purchase purchase) async {
    await purchasesBox.put(purchase.id, purchase);

    // Catat pergerakan stok
    for (final item in purchase.items) {
      await movementsBox.put(
        newId('mv'),
        StockMovement(
          id: newId('mv'),
          dateEpochDay: purchase.dateEpochDay,
          productId: item.productId,
          type: 'purchase',
          qtyDelta: item.qty,
          note: 'Pembelian',
        ),
      );
    }

    for (final item in purchase.items) {
      final product = productsBox.get(item.productId);
      if (product == null) continue;

      final oldQty = product.stockQty;
      final oldHpp = product.avgHpp;

      final incomingQty = item.qty;
      final incomingCost = item.qty * item.buyPrice;

      final oldCost = oldQty * oldHpp;
      final newTotalQty = oldQty + incomingQty;
      final newTotalCost = oldCost + incomingCost;

      product.stockQty = newTotalQty;
      product.avgHpp = hppWeightedAverage(totalQty: newTotalQty, totalCost: newTotalCost);

      await productsBox.put(product.id, product);
    }
  }

  Future<void> remove(String id) async => purchasesBox.delete(id);
}
