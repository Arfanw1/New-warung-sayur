import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../db/hive_boxes.dart';
import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/stock_movement.dart';

class BackupService {
  final Box<Product> products;
  final Box<Purchase> purchases;
  final Box<Sale> sales;
  final Box<Expense> expenses;
  final Box<Debt> debts;
  final Box<StockMovement> movements;

  BackupService({
    required this.products,
    required this.purchases,
    required this.sales,
    required this.expenses,
    required this.debts,
    required this.movements,
  });

  Map<String, dynamic> _snapshot() => {
        Boxes.products: products.values.map((e) => e.toJson()).toList(),
        Boxes.purchases: purchases.values.map((e) => e.toJson()).toList(),
        Boxes.sales: sales.values.map((e) => e.toJson()).toList(),
        Boxes.expenses: expenses.values.map((e) => e.toJson()).toList(),
        Boxes.debts: debts.values.map((e) => e.toJson()).toList(),
        Boxes.movements: movements.values.map((e) => e.toJson()).toList(),
        '_meta': {'app': 'warung_sayur', 'ts': DateTime.now().toIso8601String(), 'version': 1}
      };

  Future<File> createBackupFile() async {
    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${dir.path}/warung_sayur_backup_$ts.json');
    await f.writeAsString(jsonEncode(_snapshot()));
    return f;
  }

  Future<void> shareBackup() async {
    final f = await createBackupFile();
    await Share.shareXFiles([XFile(f.path)], text: 'Backup Warung Sayur');
  }

  Future<void> restoreFromPicker() async {
    final res = await FilePicker.platform.pickFiles(
      dialogTitle: 'Pilih file backup (.json)',
      type: FileType.custom,
      allowedExtensions: ['json'],
    );
    if (res == null || res.files.isEmpty) return;
    final path = res.files.single.path;
    if (path == null) return;

    final raw = await File(path).readAsString();
    final j = jsonDecode(raw) as Map<String, dynamic>;

    await products.clear();
    await purchases.clear();
    await sales.clear();
    await expenses.clear();
    await debts.clear();
    await movements.clear();

    for (final p in (j[Boxes.products] as List? ?? const [])) {
      final obj = Product.fromJson(Map<String, dynamic>.from(p));
      await products.put(obj.id, obj);
    }
    for (final x in (j[Boxes.purchases] as List? ?? const [])) {
      final obj = Purchase.fromJson(Map<String, dynamic>.from(x));
      await purchases.put(obj.id, obj);
    }
    for (final x in (j[Boxes.sales] as List? ?? const [])) {
      final obj = Sale.fromJson(Map<String, dynamic>.from(x));
      await sales.put(obj.id, obj);
    }
    for (final x in (j[Boxes.expenses] as List? ?? const [])) {
      final obj = Expense.fromJson(Map<String, dynamic>.from(x));
      await expenses.put(obj.id, obj);
    }
    for (final x in (j[Boxes.debts] as List? ?? const [])) {
      final obj = Debt.fromJson(Map<String, dynamic>.from(x));
      await debts.put(obj.id, obj);
    }
    for (final x in (j[Boxes.movements] as List? ?? const [])) {
      final obj = StockMovement.fromJson(Map<String, dynamic>.from(x));
      await movements.put(obj.id, obj);
    }
  }

  int _toEpochDay(DateTime dt) {
    final utc = DateTime.utc(dt.year, dt.month, dt.day);
    final base = DateTime.utc(1970, 1, 1);
    return utc.difference(base).inDays;
  }

  DateTime _fromEpochDay(int day) {
    final base = DateTime.utc(1970, 1, 1);
    final du = base.add(Duration(days: day));
    return DateTime(du.year, du.month, du.day);
  }

  Future<File> exportReportCsv({required DateTime start, required DateTime end}) async {
    final s0 = _toEpochDay(start);
    final s1 = _toEpochDay(end);

    final mapOmzet = <int, double>{};
    final mapHpp = <int, double>{};
    for (final s in sales.values) {
      if (s.dateEpochDay < s0 || s.dateEpochDay > s1) continue;
      mapOmzet[s.dateEpochDay] = (mapOmzet[s.dateEpochDay] ?? 0) + s.totalSales;
      mapHpp[s.dateEpochDay] = (mapHpp[s.dateEpochDay] ?? 0) + s.totalHpp;
    }

    final mapBiaya = <int, double>{};
    for (final e in expenses.values) {
      if (e.dateEpochDay < s0 || e.dateEpochDay > s1) continue;
      mapBiaya[e.dateEpochDay] = (mapBiaya[e.dateEpochDay] ?? 0) + e.amount;
    }

    final rows = <List<String>>[
      ['tanggal', 'omzet', 'hpp', 'laba_kotor', 'biaya', 'laba_bersih'],
    ];

    for (int day = s0; day <= s1; day++) {
      final omzet = mapOmzet[day] ?? 0;
      final hpp = mapHpp[day] ?? 0;
      final biaya = mapBiaya[day] ?? 0;
      final lk = omzet - hpp;
      final lb = lk - biaya;

      final t = _fromEpochDay(day);
      final tanggal =
          '${t.year.toString().padLeft(4, '0')}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
      rows.add([tanggal, omzet.toStringAsFixed(0), hpp.toStringAsFixed(0), lk.toStringAsFixed(0), biaya.toStringAsFixed(0), lb.toStringAsFixed(0)]);
    }

    final csv = rows.map((r) => r.map(_escapeCsv).join(',')).join('\n');

    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final f = File('${dir.path}/warung_sayur_report_$ts.csv');
    await f.writeAsString(csv);
    return f;
  }

  Future<void> shareReportCsv({required DateTime start, required DateTime end}) async {
    final f = await exportReportCsv(start: start, end: end);
    await Share.shareXFiles([XFile(f.path)], text: 'Laporan CSV Warung Sayur');
  }

  String _escapeCsv(String s) {
    if (s.contains(',') || s.contains('"') || s.contains('\n')) {
      return '"' + s.replaceAll('"', '""') + '"';
    }
    return s;
  }
}
