import '../../domain/models/sale.dart';
import '../../domain/models/expense.dart';
import '../../core/calc.dart';

class ReportSummary {
  final double omzet;
  final double totalHpp;
  final double labaKotor;
  final double totalBiaya;
  final double labaBersih;

  ReportSummary({
    required this.omzet,
    required this.totalHpp,
    required this.labaKotor,
    required this.totalBiaya,
    required this.labaBersih,
  });
}

ReportSummary summarize({required Iterable<Sale> sales, required Iterable<Expense> expenses}) {
  final omzet = sales.fold(0.0, (p, s) => p + s.totalSales);
  final totalHpp = sales.fold(0.0, (p, s) => p + s.totalHpp);
  final totalBiaya = expenses.fold(0.0, (p, e) => p + e.amount);

  return ReportSummary(
    omzet: omzet,
    totalHpp: totalHpp,
    labaKotor: grossProfit(totalSales: omzet, totalHpp: totalHpp),
    totalBiaya: totalBiaya,
    labaBersih: netProfit(totalSales: omzet, totalHpp: totalHpp, totalExpenses: totalBiaya),
  );
}
