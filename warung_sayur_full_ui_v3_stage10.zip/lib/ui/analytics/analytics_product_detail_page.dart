import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../core/dates.dart';
import '../../providers.dart';
import '../../data/services/analytics_service.dart';

class AnalyticsProductDetailPage extends ConsumerWidget {
  final String productId;
  final DateTime start;
  final DateTime end;

  const AnalyticsProductDetailPage({
    super.key,
    required this.productId,
    required this.start,
    required this.end,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final salesBox = ref.watch(salesBoxProvider);
    final productsBox = ref.watch(productsBoxProvider);
    final service = const AnalyticsService();

    final p = productsBox.get(productId);
    final kpi = service.productKpi(salesBox, productsBox, productId, start, end);
    final revTrend = service.productRevenueTrend(salesBox, productId, start, end);
    final qtyTrend = service.productQtyTrend(salesBox, productId, start, end);
    final rows = service.productSalesRows(salesBox, productId, start, end, limit: 20);

    final title = p?.name ?? kpi.name;
    final unit = p?.unit ?? '';
    // Hive fields may be `num`; normalize to double for calculations + widgets.
    final double sell = (p?.activeSellPrice ?? 0).toDouble();
    final double hppNow = (p?.avgHpp ?? 0).toDouble();
    final double marginNow = sell <= 0 ? 0.0 : ((sell - hppNow) / sell) * 100.0;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title),
            Text(
              '${fmtDate(start)} → ${fmtDate(end)}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _KpiCards(
            revenue: kpi.revenue,
            profit: kpi.profit,
            qty: kpi.qty,
            unit: unit,
            marginPercent: kpi.marginPercent,
          ),
          const SizedBox(height: 12),
          _CurrentPricingCard(
            sellPrice: sell,
            hpp: hppNow,
            marginPercent: marginNow,
          ),
          const SizedBox(height: 12),
          Text('Tren Omzet', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          _LineChart(points: revTrend),
          const SizedBox(height: 16),
          Text('Tren Qty Terjual', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          _LineChart(points: qtyTrend),
          const SizedBox(height: 16),
          Text('Transaksi Terakhir', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (rows.isEmpty)
            const Text('Belum ada transaksi pada rentang ini.')
          else
            ...rows.map((r) {
              final d = fromEpochDay(r.day);
              final profit = (r.total - (r.qty * r.hppAtSale));
              return Card(
                child: ListTile(
                  title: Text('${fmtDate(d)} • Qty ${r.qty.toStringAsFixed(2)} $unit'),
                  subtitle: Text('Harga: ${fmtMoney(r.price)} • HPP: ${fmtMoney(r.hppAtSale)}'),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(fmtMoney(r.total)),
                      Text('Laba: ${fmtMoney(profit)}', style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class _KpiCards extends StatelessWidget {
  final double revenue;
  final double profit;
  final double qty;
  final String unit;
  final double marginPercent;

  const _KpiCards({
    required this.revenue,
    required this.profit,
    required this.qty,
    required this.unit,
    required this.marginPercent,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _MiniCard(
            title: 'Omzet',
            value: fmtMoney(revenue),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _MiniCard(
            title: 'Laba',
            value: fmtMoney(profit),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _MiniCard(
            title: 'Qty',
            value: '${qty.toStringAsFixed(2)} $unit',
            subtitle: '${marginPercent.toStringAsFixed(1)}% margin',
          ),
        ),
      ],
    );
  }
}

class _CurrentPricingCard extends StatelessWidget {
  final double sellPrice;
  final double hpp;
  final double marginPercent;

  const _CurrentPricingCard({
    required this.sellPrice,
    required this.hpp,
    required this.marginPercent,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Harga saat ini', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text('Harga jual: ${fmtMoney(sellPrice)}'),
            Text('HPP rata-rata: ${fmtMoney(hpp)}'),
            Text('Margin saat ini: ${marginPercent.toStringAsFixed(1)}%'),
          ],
        ),
      ),
    );
  }
}

class _MiniCard extends StatelessWidget {
  final String title;
  final String value;
  final String? subtitle;
  const _MiniCard({required this.title, required this.value, this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 6),
            Text(value, style: Theme.of(context).textTheme.titleMedium),
            if (subtitle != null) ...[
              const SizedBox(height: 2),
              Text(subtitle!, style: Theme.of(context).textTheme.bodySmall),
            ]
          ],
        ),
      ),
    );
  }
}

class _LineChart extends StatelessWidget {
  final List<DayPoint> points;
  const _LineChart({required this.points});

  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) {
      return const SizedBox(height: 160, child: Center(child: Text('Tidak ada data.')));
    }
    final minX = points.first.epochDayValue.toDouble();
    final maxX = points.last.epochDayValue.toDouble();
    final maxY = points.map((e) => e.value).fold<double>(0.0, (p, e) => e > p ? e : p);

    return SizedBox(
      height: 180,
      child: LineChart(
        LineChartData(
          minX: minX,
          maxX: maxX,
          minY: 0,
          maxY: maxY == 0 ? 1 : (maxY * 1.2),
          gridData: const FlGridData(show: true),
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: true),
          lineBarsData: [
            LineChartBarData(
              spots: points.map((e) => FlSpot(e.epochDayValue.toDouble(), e.value)).toList(),
              isCurved: true,
              dotData: const FlDotData(show: false),
              barWidth: 3,
            ),
          ],
        ),
      ),
    );
  }
}
