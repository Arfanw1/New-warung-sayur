# Warung Arasaan - Production Ready (Android AAB)

Target:
- App name: Warung Arasaan
- ApplicationId / package: com.warung.arasaan
- Output for Play Store: AAB (release, signed)

## 1) Siapkan keystore (sekali saja)
Buat keystore dengan `keytool` (di PC/Termux yang ada Java):

```
keytool -genkey -v -keystore warung-arasaan.jks -keyalg RSA -keysize 2048 -validity 10000 -alias warung_arasaan
```

## 2) Buat key.properties
Isi contoh (jangan commit ke repo):

```
storePassword=PASSWORD_STORE
keyPassword=PASSWORD_KEY
keyAlias=warung_arasaan
storeFile=warung-arasaan.jks
```

## 3) Simpan ke GitHub Secrets
Di repo GitHub -> Settings -> Secrets and variables -> Actions -> New repository secret:

- `KEYSTORE_BASE64`:
  - isi base64 dari file `warung-arasaan.jks`
  - contoh membuat base64:
    - Linux/macOS: `base64 -w 0 warung-arasaan.jks`
- `KEY_PROPERTIES`:
  - isi text `key.properties` di atas (4 baris)

## 4) Build AAB via GitHub Actions
Workflow: `.github/workflows/build_aab.yml`
Artifact hasil: `app-release-aab` -> `app-release.aab`

## 5) Upload ke Play Console
Upload `app-release.aab` ke track Internal testing / Closed testing / Production.

Catatan:
- Workflow akan generate `android/` dengan `flutter create --org com.warung --project-name arasaan .`
  sehingga package = `com.warung.arasaan`.
