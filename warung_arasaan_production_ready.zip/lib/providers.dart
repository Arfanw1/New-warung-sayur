import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';

import 'domain/models/product.dart';
import 'domain/models/purchase.dart';
import 'domain/models/sale.dart';
import 'domain/models/expense.dart';
import 'domain/models/debt.dart';
import 'domain/models/stock_movement.dart';
import 'domain/models/cash_entry.dart';
import 'domain/models/app_settings.dart';
import 'domain/models/activity_log.dart';

import 'data/repositories/product_repo.dart';
import 'data/repositories/purchase_repo.dart';
import 'data/repositories/sales_repo.dart';
import 'data/repositories/expense_repo.dart';
import 'data/repositories/debt_repo.dart';
import 'data/repositories/movement_repo.dart';
import 'data/repositories/cash_repo.dart';
import 'data/repositories/settings_repo.dart';
import 'data/repositories/activity_log_repo.dart';
import 'data/repositories/meta_repo.dart';
import 'data/services/backup_service.dart';

final productsBoxProvider = Provider<Box<Product>>((ref) => throw UnimplementedError());
final purchasesBoxProvider = Provider<Box<Purchase>>((ref) => throw UnimplementedError());
final salesBoxProvider = Provider<Box<Sale>>((ref) => throw UnimplementedError());
final expensesBoxProvider = Provider<Box<Expense>>((ref) => throw UnimplementedError());
final debtsBoxProvider = Provider<Box<Debt>>((ref) => throw UnimplementedError());
final movementsBoxProvider = Provider<Box<StockMovement>>((ref) => throw UnimplementedError());
final cashBoxProvider = Provider<Box<CashEntry>>((ref) => throw UnimplementedError());
final settingsBoxProvider = Provider<Box<AppSettings>>((ref) => throw UnimplementedError());
final activityLogsBoxProvider = Provider<Box<ActivityLog>>((ref) => throw UnimplementedError());
final metaBoxProvider = Provider<Box>((ref) => throw UnimplementedError());

final productRepoProvider = Provider<ProductRepo>((ref) => ProductRepo(ref.watch(productsBoxProvider)));
final purchaseRepoProvider =
    Provider<PurchaseRepo>((ref) => PurchaseRepo(ref.watch(purchasesBoxProvider), ref.watch(productsBoxProvider), ref.watch(movementsBoxProvider), ref.watch(cashBoxProvider)));
final salesRepoProvider = Provider<SalesRepo>((ref) => SalesRepo(ref.watch(salesBoxProvider), ref.watch(productsBoxProvider), ref.watch(movementsBoxProvider), ref.watch(cashBoxProvider)));
final expenseRepoProvider = Provider<ExpenseRepo>((ref) => ExpenseRepo(ref.watch(expensesBoxProvider), ref.watch(cashBoxProvider)));
final debtRepoProvider = Provider<DebtRepo>((ref) => DebtRepo(ref.watch(debtsBoxProvider), ref.watch(cashBoxProvider)));
final movementRepoProvider = Provider<MovementRepo>((ref) => MovementRepo(ref.watch(movementsBoxProvider)));
final cashRepoProvider = Provider<CashRepo>((ref) => CashRepo(ref.watch(cashBoxProvider)));
final settingsRepoProvider = Provider<SettingsRepo>((ref) => SettingsRepo(ref.watch(settingsBoxProvider)));
final activityLogRepoProvider = Provider<ActivityLogRepo>((ref) => ActivityLogRepo(ref.watch(activityLogsBoxProvider)));
final metaRepoProvider = Provider<MetaRepo>((ref) => MetaRepo(ref.watch(metaBoxProvider)));

final backupServiceProvider = Provider<BackupService>((ref) => BackupService(
      products: ref.watch(productsBoxProvider),
      purchases: ref.watch(purchasesBoxProvider),
      sales: ref.watch(salesBoxProvider),
      expenses: ref.watch(expensesBoxProvider),
      debts: ref.watch(debtsBoxProvider),
      movements: ref.watch(movementsBoxProvider),
      cash: ref.watch(cashBoxProvider),
      settings: ref.watch(settingsBoxProvider),
    ));
