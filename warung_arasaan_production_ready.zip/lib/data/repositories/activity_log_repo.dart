import 'package:hive/hive.dart';

import '../../domain/models/activity_log.dart';
import '../../core/ids.dart';

class ActivityLogRepo {
  final Box<ActivityLog> box;
  ActivityLogRepo(this.box);

  List<ActivityLog> all() => box.values.toList()
    ..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(ActivityLog log) => box.put(log.id, log);

  Future<void> log(String type, String message) {
    final id = newId('log');
    final now = DateTime.now();
    final epochDay = DateTime.utc(now.year, now.month, now.day)
        .difference(DateTime.utc(1970, 1, 1))
        .inDays;
    return add(ActivityLog(id: id, type: type, refId: '', oldJson: '', newJson: message, dateEpochDay: epochDay));
  }

  Future<void> clear() => box.clear();
}
