import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../domain/models/product.dart';
import '../products/product_detail_page.dart';
import '../widgets/empty_state.dart';

/// Step 4: tambah tab Prediksi kebutuhan berbasis histori penjualan.
/// - Window data: 7/14/30 hari
/// - Horizon prediksi: 3/7 hari
/// - Saran beli: max(0, kebutuhan - stok sekarang)
class RestockPage extends ConsumerStatefulWidget {
  const RestockPage({super.key});

  @override
  ConsumerState<RestockPage> createState() => _RestockPageState();
}

class _RestockPageState extends ConsumerState<RestockPage> {
  int windowDays = 7;
  int horizonDays = 3;

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Belanja & Prediksi'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Saran Belanja'),
              Tab(text: 'Prediksi'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _restockTab(context),
            _forecastTab(context),
          ],
        ),
      ),
    );
  }

  Widget _restockTab(BuildContext context) {
    final repo = ref.watch(productRepoProvider);
    final products = repo.all();

    final items = <_RestockItem>[];
    for (final p in products) {
      final target = (p.targetStock > 0) ? p.targetStock : p.minStock;
      if (target <= 0) continue;
      if (p.stockQty < target) {
        items.add(_RestockItem(
          product: p,
          target: target,
          suggestQty: (target - p.stockQty),
        ));
      }
    }
    items.sort((a, b) => b.suggestQty.compareTo(a.suggestQty));

    return items.isEmpty
        ? const EmptyState(
            title: 'Tidak ada saran belanja',
            subtitle: 'Semua produk masih aman. Atur Target Stok atau Stok Minimum jika ingin rekomendasi.',
            icon: Icons.check_circle_outline,
          )
        : ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final it = items[i];
              final p = it.product;
              return Card(
                child: ListTile(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id)),
                  ),
                  title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('Stok: ${_fmt(p.stockQty)} ${p.unit}  •  Target: ${_fmt(it.target)} ${p.unit}'),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text('Beli', style: TextStyle(fontSize: 12)),
                      Text('${_fmt(it.suggestQty)} ${p.unit}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              );
            },
          );
  }

  Widget _forecastTab(BuildContext context) {
    final productsRepo = ref.watch(productRepoProvider);
    final salesBox = ref.watch(salesBoxProvider);
    final products = productsRepo.all();

    final todayEpoch = _epochDay(DateTime.now());
    final startEpoch = todayEpoch - (windowDays - 1);

    final soldQty = <String, double>{};
    for (final s in salesBox.values) {
      if (s.dateEpochDay < startEpoch || s.dateEpochDay > todayEpoch) continue;
      for (final it in s.items) {
        soldQty[it.productId] = (soldQty[it.productId] ?? 0) + it.qty;
      }
    }

    final items = <_ForecastItem>[];
    for (final p in products) {
      final total = soldQty[p.id] ?? 0.0;
      if (total <= 0) continue;
      final avgPerDay = total / windowDays;
      final need = avgPerDay * horizonDays;
      final suggestBuy = (need - p.stockQty);
      items.add(_ForecastItem(
        product: p,
        avgPerDay: avgPerDay,
        horizonNeed: need,
        suggestBuy: suggestBuy > 0 ? suggestBuy : 0,
      ));
    }

    items.sort((a, b) {
      final c = b.suggestBuy.compareTo(a.suggestBuy);
      if (c != 0) return c;
      return b.horizonNeed.compareTo(a.horizonNeed);
    });

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
          child: Row(
            children: [
              Expanded(
                child: _pillDropdown<int>(
                  label: 'Data',
                  value: windowDays,
                  items: const [7, 14, 30],
                  onChanged: (v) => setState(() => windowDays = v),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _pillDropdown<int>(
                  label: 'Prediksi',
                  value: horizonDays,
                  items: const [3, 7],
                  onChanged: (v) => setState(() => horizonDays = v),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: items.isEmpty
              ? const EmptyState(
                  title: 'Belum ada prediksi',
                  subtitle: 'Belum ada penjualan dalam periode ini. Coba pilih 14/30 hari atau mulai catat penjualan.',
                  icon: Icons.show_chart,
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final it = items[i];
                    final p = it.product;
                    return Card(
                      child: ListTile(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => ProductDetailPage(productId: p.id)),
                        ),
                        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(
                          'Rata2: ${_fmt(it.avgPerDay)} ${p.unit}/hari  •  Perkiraan $horizonDays hari: ${_fmt(it.horizonNeed)} ${p.unit}',
                        ),
                        trailing: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            const Text('Saran beli', style: TextStyle(fontSize: 12)),
                            Text('${_fmt(it.suggestBuy)} ${p.unit}', style: const TextStyle(fontWeight: FontWeight.w800)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _pillDropdown<T>({
    required String label,
    required T value,
    required List<T> items,
    required void Function(T v) onChanged,
  }) {
    return InputDecorator(
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(
          value: value,
          isExpanded: true,
          items: items
              .map((e) => DropdownMenuItem<T>(
                    value: e,
                    child: Text(e.toString()),
                  ))
              .toList(),
          onChanged: (v) {
            if (v == null) return;
            onChanged(v);
          },
        ),
      ),
    );
  }

  String _fmt(double v) {
    if (v % 1 == 0) return v.toStringAsFixed(0);
    return v.toStringAsFixed(2);
  }

  int _epochDay(DateTime dt) {
    final d = DateTime(dt.year, dt.month, dt.day);
    final base = DateTime.utc(1970, 1, 1);
    final du = DateTime.utc(d.year, d.month, d.day);
    return du.difference(base).inDays;
  }
}

class _RestockItem {
  final Product product;
  final double target;
  final double suggestQty;
  _RestockItem({required this.product, required this.target, required this.suggestQty});
}

class _ForecastItem {
  final Product product;
  final double avgPerDay;
  final double horizonNeed;
  final double suggestBuy;
  _ForecastItem({required this.product, required this.avgPerDay, required this.horizonNeed, required this.suggestBuy});
}
