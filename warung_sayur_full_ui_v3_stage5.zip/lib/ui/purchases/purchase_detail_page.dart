import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';

class PurchaseDetailPage extends ConsumerWidget {
  final String purchaseId;
  const PurchaseDetailPage({super.key, required this.purchaseId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final purchasesBox = ref.watch(purchasesBoxProvider);
    final purchase = purchasesBox.get(purchaseId);
    final productsRepo = ref.watch(productRepoProvider);
    final repo = ref.watch(purchaseRepoProvider);

    if (purchase == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Detail Pembelian')),
        body: const Center(child: Text('Data pembelian tidak ditemukan.')),
      );
    }

    final totalQty = purchase.items.fold<double>(0, (s, it) => s + it.qty);
    final total = purchase.items.fold<double>(0, (s, it) => s + it.qty * it.buyPrice);
    final supplier = purchase.supplier.trim();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Pembelian'),
        actions: [
          IconButton(
            tooltip: 'Hapus pembelian',
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Hapus pembelian?'),
                  content: const Text('Stok dan riwayat akan di-rollback otomatis.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
                    FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus')),
                  ],
                ),
              );
              if (ok != true) return;
              await repo.remove(purchase.id);
              if (context.mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('Pembelian dihapus')));
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Tanggal', style: Theme.of(context).textTheme.labelMedium),
                  const SizedBox(height: 4),
                  Text(fmtDateFromEpochDay(purchase.dateEpochDay),
                      style: Theme.of(context).textTheme.titleMedium),
                  if (supplier.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text('Supplier', style: Theme.of(context).textTheme.labelMedium),
                    const SizedBox(height: 4),
                    Text(supplier, style: Theme.of(context).textTheme.titleMedium),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text('Item', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ...purchase.items.map((it) {
            final pr = productsRepo.getById(it.productId);
            final name = pr?.name ?? 'Produk';
            final unit = pr?.unit ?? '';
            final subTotal = it.qty * it.buyPrice;
            return Card(
              child: ListTile(
                title: Text(name),
                subtitle: Text(
                  '${it.qty.toStringAsFixed(2)} $unit × ${it.buyPrice.toStringAsFixed(0)}',
                ),
                trailing: Text(
                  subTotal.toStringAsFixed(0),
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            );
          }),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _row('Total Qty', totalQty.toStringAsFixed(2)),
                  const SizedBox(height: 8),
                  _row('Total', fmtMoney(total)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String k, String v) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(k), Text(v, style: const TextStyle(fontWeight: FontWeight.w700))],
      );

}
