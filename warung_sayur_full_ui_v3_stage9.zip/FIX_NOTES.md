# v3 Fixed
Perbaikan build:
- lib/data/db/hive_boxes.dart: import StockMovement dipindah ke bagian atas (Dart directives rule).
- lib/ui/purchases/purchases_page.dart: string subtitle dibuat satu baris dengan \n.
- lib/ui/sales/sales_page.dart: string subtitle dibuat satu baris dengan \n.
