import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MoneyField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final bool requiredField;

  const MoneyField({
    super.key,
    required this.controller,
    required this.label,
    this.requiredField = false,
  });

  @override
  State<MoneyField> createState() => _MoneyFieldState();
}

class _MoneyFieldState extends State<MoneyField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      keyboardType: TextInputType.number,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly, _RupiahFormatter()],
      decoration: InputDecoration(
        labelText: widget.label,
        helperText: 'Otomatis format ribuan (contoh: 84000 → 84.000)',
      ),
      validator: (v) {
        if (!widget.requiredField) return null;
        if (v == null || v.trim().isEmpty) return 'Wajib diisi';
        final n = parseRupiah(v);
        if (n == null) return 'Angka tidak valid';
        return null;
      },
    );
  }
}

/// Parse string Rupiah formatted like "84.000" into int
int? parseRupiah(String s) {
  final digits = s.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.isEmpty) return null;
  return int.tryParse(digits);
}

class _RupiahFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) {
      return newValue.copyWith(text: '');
    }
    final formatted = _formatThousands(digits);
    // keep cursor at end (simple + reliable)
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  String _formatThousands(String digits) {
    final chars = digits.split('');
    final buf = StringBuffer();
    for (int i = 0; i < chars.length; i++) {
      final idxFromEnd = chars.length - i;
      buf.write(chars[i]);
      if (idxFromEnd > 1 && idxFromEnd % 3 == 1) {
        buf.write('.');
      }
    }
    return buf.toString();
  }
}
