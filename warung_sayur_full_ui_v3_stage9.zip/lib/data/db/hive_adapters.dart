import 'package:hive/hive.dart';

import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/debt.dart';
import '../../domain/models/stock_movement.dart';
import '../../domain/models/cash_entry.dart';
import '../../domain/models/app_settings.dart';
import '../../domain/models/activity_log.dart';

class ProductAdapter extends TypeAdapter<Product> {
  @override
  final int typeId = 1;
  @override
  Product read(BinaryReader reader) {
    // Backward compatible: versi lama belum punya minStock.
    final id = reader.readString();
    final name = reader.readString();
    final unit = reader.readString();
    final margin = reader.readDouble();
    final sell = reader.readDouble();
    final stock = reader.readDouble();
    final avgHpp = reader.readDouble();
    double minStock = 0;
    try {
      minStock = reader.readDouble();
    } catch (_) {
      minStock = 0;
    }
    return Product(
      id: id,
      name: name,
      unit: unit,
      defaultMarginPercent: margin,
      activeSellPrice: sell,
      stockQty: stock,
      avgHpp: avgHpp,
      minStock: minStock,
    );
  }
  @override
  void write(BinaryWriter writer, Product obj) {
    writer
      ..writeString(obj.id)
      ..writeString(obj.name)
      ..writeString(obj.unit)
      ..writeDouble(obj.defaultMarginPercent)
      ..writeDouble(obj.activeSellPrice)
      ..writeDouble(obj.stockQty)
      ..writeDouble(obj.avgHpp)
      ..writeDouble(obj.minStock);
  }
}

class PurchaseItemAdapter extends TypeAdapter<PurchaseItem> {
  @override
  final int typeId = 2;
  @override
  PurchaseItem read(BinaryReader reader) =>
      PurchaseItem(productId: reader.readString(), qty: reader.readDouble(), buyPrice: reader.readDouble());
  @override
  void write(BinaryWriter writer, PurchaseItem obj) {
    writer
      ..writeString(obj.productId)
      ..writeDouble(obj.qty)
      ..writeDouble(obj.buyPrice);
  }
}

class PurchaseAdapter extends TypeAdapter<Purchase> {
  @override
  final int typeId = 3;
  @override
  Purchase read(BinaryReader reader) {
    // Backward compatible: versi lama belum punya supplier/paymentMethod.
    final id = reader.readString();
    final day = reader.readInt();
    final dynamic next = reader.read();
    if (next is String) {
      // Kemungkinan: supplier -> paymentMethod -> items
      String payment = 'Cash';
      dynamic maybePayment;
      try {
        maybePayment = reader.read();
      } catch (_) {
        maybePayment = null;
      }
      if (maybePayment is String) {
        payment = maybePayment;
      } else {
        // jika bukan string, anggap itu items (format lama)
        if (maybePayment is List) {
          return Purchase(id: id, dateEpochDay: day, supplier: next, paymentMethod: 'Cash', items: maybePayment.cast<PurchaseItem>());
        }
      }
      final items = (reader.readList()).cast<PurchaseItem>();
      return Purchase(id: id, dateEpochDay: day, supplier: next, paymentMethod: payment, items: items);
    }
    if (next is List) {
      return Purchase(id: id, dateEpochDay: day, supplier: '', paymentMethod: 'Cash', items: next.cast<PurchaseItem>());
    }
    // Fallback aman.
    return Purchase(id: id, dateEpochDay: day, supplier: '', items: const []);
  }
  @override
  void write(BinaryWriter writer, Purchase obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.supplier)
      ..writeString(obj.paymentMethod)
      ..writeList(obj.items);
  }
}

class SaleItemAdapter extends TypeAdapter<SaleItem> {
  @override
  final int typeId = 4;
  @override
  SaleItem read(BinaryReader reader) => SaleItem(
        productId: reader.readString(),
        qty: reader.readDouble(),
        sellPrice: reader.readDouble(),
        hppAtSale: reader.readDouble(),
      );
  @override
  void write(BinaryWriter writer, SaleItem obj) {
    writer
      ..writeString(obj.productId)
      ..writeDouble(obj.qty)
      ..writeDouble(obj.sellPrice)
      ..writeDouble(obj.hppAtSale);
  }
}

class SaleAdapter extends TypeAdapter<Sale> {
  @override
  final int typeId = 5;
  @override
  Sale read(BinaryReader reader) {
    // Backward compatible: versi lama belum punya paymentMethod.
    final id = reader.readString();
    final day = reader.readInt();
    dynamic next;
    try {
      next = reader.read();
    } catch (_) {
      next = null;
    }
    if (next is String) {
      final items = (reader.readList()).cast<SaleItem>();
      return Sale(id: id, dateEpochDay: day, paymentMethod: next, items: items);
    }
    if (next is List) {
      return Sale(id: id, dateEpochDay: day, paymentMethod: 'Cash', items: next.cast<SaleItem>());
    }
    // fallback
    final items = (reader.readList()).cast<SaleItem>();
    return Sale(id: id, dateEpochDay: day, paymentMethod: 'Cash', items: items);
  }
  @override
  void write(BinaryWriter writer, Sale obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.paymentMethod)
      ..writeList(obj.items);
  }
}

class ExpenseAdapter extends TypeAdapter<Expense> {
  @override
  final int typeId = 6;
  @override
  Expense read(BinaryReader reader) {
    // Backward compatible: versi lama belum punya paymentMethod.
    final id = reader.readString();
    final day = reader.readInt();
    final note = reader.readString();
    final amount = reader.readDouble();
    String method = 'Cash';
    try {
      method = reader.readString();
    } catch (_) {
      method = 'Cash';
    }
    return Expense(id: id, dateEpochDay: day, note: note, amount: amount, paymentMethod: method);
  }
  @override
  void write(BinaryWriter writer, Expense obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.note)
      ..writeDouble(obj.amount)
      ..writeString(obj.paymentMethod);
  }
}

class CashEntryAdapter extends TypeAdapter<CashEntry> {
  @override
  final int typeId = 9;

  @override
  CashEntry read(BinaryReader reader) {
    return CashEntry(
      id: reader.readString(),
      dateEpochDay: reader.readInt(),
      direction: reader.readString(),
      source: reader.readString(),
      method: reader.readString(),
      note: reader.readString(),
      amount: reader.readDouble(),
      refId: reader.readString(),
    );
  }

  @override
  void write(BinaryWriter writer, CashEntry obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.direction)
      ..writeString(obj.source)
      ..writeString(obj.method)
      ..writeString(obj.note)
      ..writeDouble(obj.amount)
      ..writeString(obj.refId);
  }
}

class AppSettingsAdapter extends TypeAdapter<AppSettings> {
  @override
  final int typeId = 10;

  @override
  AppSettings read(BinaryReader reader) {
    final id = reader.readString();
    bool enabled = false;
    String hash = '';
    try {
      enabled = reader.readBool();
      hash = reader.readString();
    } catch (_) {
      enabled = false;
      hash = '';
    }
    return AppSettings(id: id, pinEnabled: enabled, pinHash: hash);
  }

  @override
  void write(BinaryWriter writer, AppSettings obj) {
    writer
      ..writeString(obj.id)
      ..writeBool(obj.pinEnabled)
      ..writeString(obj.pinHash);
  }
}

class StockMovementAdapter extends TypeAdapter<StockMovement> {
  @override
  final int typeId = 8;

  @override
  StockMovement read(BinaryReader reader) => StockMovement(
        id: reader.readString(),
        dateEpochDay: reader.readInt(),
        productId: reader.readString(),
        type: reader.readString(),
        qtyDelta: reader.readDouble(),
        note: reader.readString(),
      );

  @override
  void write(BinaryWriter writer, StockMovement obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.productId)
      ..writeString(obj.type)
      ..writeDouble(obj.qtyDelta)
      ..writeString(obj.note);
  }
}

class DebtAdapter extends TypeAdapter<Debt> {
  @override
  final int typeId = 7;
  @override
  Debt read(BinaryReader reader) => Debt(
        id: reader.readString(),
        dateEpochDay: reader.readInt(),
        creditor: reader.readString(),
        note: reader.readString(),
        principal: reader.readDouble(),
        paid: reader.readDouble(),
      );
  @override
  void write(BinaryWriter writer, Debt obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.creditor)
      ..writeString(obj.note)
      ..writeDouble(obj.principal)
      ..writeDouble(obj.paid);
  }
}

class ActivityLogAdapter extends TypeAdapter<ActivityLog> {
  @override
  final int typeId = 11;

  @override
  ActivityLog read(BinaryReader reader) {
    return ActivityLog(
      id: reader.readString(),
      dateEpochDay: reader.readInt(),
      type: reader.readString(),
      refId: reader.readString(),
      oldJson: reader.readString(),
      newJson: reader.readString(),
    );
  }

  @override
  void write(BinaryWriter writer, ActivityLog obj) {
    writer
      ..writeString(obj.id)
      ..writeInt(obj.dateEpochDay)
      ..writeString(obj.type)
      ..writeString(obj.refId)
      ..writeString(obj.oldJson)
      ..writeString(obj.newJson);
  }
}

void registerAdapters() {
  if (!Hive.isAdapterRegistered(1)) Hive.registerAdapter(ProductAdapter());
  if (!Hive.isAdapterRegistered(2)) Hive.registerAdapter(PurchaseItemAdapter());
  if (!Hive.isAdapterRegistered(3)) Hive.registerAdapter(PurchaseAdapter());
  if (!Hive.isAdapterRegistered(4)) Hive.registerAdapter(SaleItemAdapter());
  if (!Hive.isAdapterRegistered(5)) Hive.registerAdapter(SaleAdapter());
  if (!Hive.isAdapterRegistered(6)) Hive.registerAdapter(ExpenseAdapter());
  if (!Hive.isAdapterRegistered(7)) Hive.registerAdapter(DebtAdapter());
  if (!Hive.isAdapterRegistered(8)) Hive.registerAdapter(StockMovementAdapter());
  if (!Hive.isAdapterRegistered(9)) Hive.registerAdapter(CashEntryAdapter());
  if (!Hive.isAdapterRegistered(10)) Hive.registerAdapter(AppSettingsAdapter());
  if (!Hive.isAdapterRegistered(11)) Hive.registerAdapter(ActivityLogAdapter());
}

