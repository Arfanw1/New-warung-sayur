import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'data/db/hive_adapters.dart';
import 'data/db/hive_boxes.dart';
import 'providers.dart';
import 'ui/home/home_page.dart';
import 'ui/settings/lock_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();
  registerAdapters();

  final products = await openProducts();
  final purchases = await openPurchases();
  final sales = await openSales();
  final expenses = await openExpenses();
  final debts = await openDebts();
  final movements = await openMovements();
  final cash = await openCash();
  final settings = await openSettings();
  final activityLogs = await openActivityLogs();

  runApp(
    ProviderScope(
      overrides: [
        productsBoxProvider.overrideWithValue(products),
        purchasesBoxProvider.overrideWithValue(purchases),
        salesBoxProvider.overrideWithValue(sales),
        expensesBoxProvider.overrideWithValue(expenses),
        debtsBoxProvider.overrideWithValue(debts),
        movementsBoxProvider.overrideWithValue(movements),
        cashBoxProvider.overrideWithValue(cash),
        settingsBoxProvider.overrideWithValue(settings),
        activityLogsBoxProvider.overrideWithValue(activityLogs),
      ],
      child: const App(),
    ),
  );
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Warung Sayur',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('id', 'ID')],
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.green), useMaterial3: true),
      home: const LockGate(child: HomePage()),
    );
  }
}
