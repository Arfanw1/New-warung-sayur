import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/expense.dart';
import '../widgets/empty_state.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/number_field.dart';

class ExpensesPage extends ConsumerWidget {
  const ExpensesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(expenseRepoProvider);
    final items = repo.all();

    return Stack(
      children: [
        items.isEmpty
            ? const EmptyState(title: 'Belum ada biaya', subtitle: 'Catat biaya harian (transport, plastik, dll).')
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) {
                  final e = items[i];
                  return Card(
                    child: ListTile(
                      title: Text(e.note),
                      subtitle: Text('${fmtDateFromEpochDay(e.dateEpochDay)} • ${fmtMoney(e.amount)}'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          await repo.remove(e.id);
                          ScaffoldMessenger.of(context)
                              .showSnackBar(const SnackBar(content: Text('Biaya dihapus')));
                        },
                      ),
                    ),
                  );
                },
              ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExpenseFormPage())),
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}

class ExpenseFormPage extends ConsumerStatefulWidget {
  const ExpenseFormPage({super.key});

  @override
  ConsumerState<ExpenseFormPage> createState() => _ExpenseFormPageState();
}

class _ExpenseFormPageState extends ConsumerState<ExpenseFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  final noteC = TextEditingController();
  final amountC = TextEditingController();

  @override
  void dispose() {
    noteC.dispose();
    amountC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Biaya')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            TextFormField(
              controller: noteC,
              decoration: const InputDecoration(labelText: 'Keterangan'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            NumberField(controller: amountC, label: 'Jumlah biaya', requiredField: true, integerOnly: true),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = double.parse(amountC.text.trim());
    final e = Expense(id: newId('exp'), dateEpochDay: epochDay(date), note: noteC.text.trim(), amount: amount);
    await ref.read(expenseRepoProvider).add(e);
    if (!mounted) return;
    Navigator.pop(context);
  }
}
