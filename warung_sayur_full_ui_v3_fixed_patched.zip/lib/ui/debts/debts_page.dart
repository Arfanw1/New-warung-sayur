import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/debt.dart';
import '../widgets/empty_state.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/number_field.dart';
import '../widgets/money_field.dart';

class DebtsPage extends ConsumerWidget {
  const DebtsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(debtRepoProvider);
    final items = repo.all();

    return Stack(
      children: [
        items.isEmpty
            ? const EmptyState(title: 'Belum ada hutang', subtitle: 'Catat hutang supplier/pinjaman dan pembayarannya.')
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) {
                  final d = items[i];
                  return Card(
                    child: ListTile(
                      title: Text('${d.creditor} • ${fmtMoney(d.principal)}'),
                      subtitle: Text('${fmtDateFromEpochDay(d.dateEpochDay)} • Terbayar: ${fmtMoney(d.paid)} • Sisa: ${fmtMoney(d.remaining)}'),
                      isThreeLine: true,
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DebtPaymentPage(debtId: d.id))),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          await repo.remove(d.id);
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Hutang dihapus')));
                        },
                      ),
                    ),
                  );
                },
              ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DebtFormPage())),
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}

class DebtFormPage extends ConsumerStatefulWidget {
  const DebtFormPage({super.key});

  @override
  ConsumerState<DebtFormPage> createState() => _DebtFormPageState();
}

class _DebtFormPageState extends ConsumerState<DebtFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  final creditorC = TextEditingController();
  final noteC = TextEditingController();
  final principalC = TextEditingController();

  @override
  void dispose() {
    creditorC.dispose();
    noteC.dispose();
    principalC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Hutang')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            TextFormField(
              controller: creditorC,
              decoration: const InputDecoration(labelText: 'Kreditur (supplier/nama)'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(controller: noteC, decoration: const InputDecoration(labelText: 'Catatan (opsional)')),
            const SizedBox(height: 12),
            MoneyField(controller: principalC, label: 'Jumlah hutang', requiredField: true),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Simpan')),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final d = Debt(
      id: newId('debt'),
      dateEpochDay: epochDay(date),
      creditor: creditorC.text.trim(),
      note: noteC.text.trim(),
      principal: (parseRupiah(principalC.text.trim()) ?? 0).toDouble(),
      paid: 0,
    );
    await ref.read(debtRepoProvider).add(d);
    if (!mounted) return;
    Navigator.pop(context);
  }
}

class DebtPaymentPage extends ConsumerStatefulWidget {
  final String debtId;
  const DebtPaymentPage({super.key, required this.debtId});

  @override
  ConsumerState<DebtPaymentPage> createState() => _DebtPaymentPageState();
}

class _DebtPaymentPageState extends ConsumerState<DebtPaymentPage> {
  final _formKey = GlobalKey<FormState>();
  final payC = TextEditingController();

  @override
  void dispose() {
    payC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final box = ref.watch(debtsBoxProvider);
    final debt = box.get(widget.debtId);
    if (debt == null) {
      return const Scaffold(body: Center(child: Text('Data hutang tidak ditemukan')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Pembayaran Hutang')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: Text(debt.creditor),
              subtitle: Text('Total: ${fmtMoney(debt.principal)}\nTerbayar: ${fmtMoney(debt.paid)}\nSisa: ${fmtMoney(debt.remaining)}'),
              isThreeLine: true,
            ),
          ),
          const SizedBox(height: 12),
          Form(
            key: _formKey,
            child: Column(
              children: [
                MoneyField(controller: payC, label: 'Tambah pembayaran', requiredField: true),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: debt.isSettled ? null : _pay,
                  icon: const Icon(Icons.payments),
                  label: const Text('Simpan Pembayaran'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _pay() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = (parseRupiah(payC.text.trim()) ?? 0).toDouble();
    if (amount <= 0) return;
    await ref.read(debtRepoProvider).addPayment(widget.debtId, amount);
    if (!mounted) return;
    payC.clear();
    setState(() {});
  }
}
