import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';

class BackupPage extends ConsumerStatefulWidget {
  const BackupPage({super.key});

  @override
  ConsumerState<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends ConsumerState<BackupPage> {
  DateTime start = DateTime.now().subtract(const Duration(days: 6));
  DateTime end = DateTime.now();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final svc = ref.watch(backupServiceProvider);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            title: const Text('Buat Backup (.json)'),
            subtitle: const Text('Membuat backup data lalu share ke WhatsApp/Drive, dll.'),
            trailing: const Icon(Icons.share),
            onTap: busy
                ? null
                : () async {
                    setState(() => busy = true);
                    try {
                      await svc.shareBackup();
                    } finally {
                      if (mounted) setState(() => busy = false);
                    }
                  },
          ),
        ),
        Card(
          child: ListTile(
            title: const Text('Restore dari Backup (.json)'),
            subtitle: const Text('Memulihkan data dari file backup (overwrite).'),
            trailing: const Icon(Icons.restore),
            onTap: busy
                ? null
                : () async {
                    setState(() => busy = true);
                    try {
                      await svc.restoreFromPicker();
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Restore selesai')));
                      }
                    } catch (_) {
                      if (mounted) {
                        ScaffoldMessenger.of(context)
                            .showSnackBar(const SnackBar(content: Text('Restore gagal. Pastikan file backup valid.')));
                      }
                    } finally {
                      if (mounted) setState(() => busy = false);
                    }
                  },
          ),
        ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Export Laporan Ringkas CSV', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () async {
                          final p = await showDatePicker(
                            context: context,
                            initialDate: start,
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2100),
                          );
                          if (p != null) setState(() => start = p);
                        },
                        child: InputDecorator(decoration: const InputDecoration(labelText: 'Mulai'), child: Text(fmtDate(start))),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: InkWell(
                        onTap: () async {
                          final p = await showDatePicker(
                            context: context,
                            initialDate: end,
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2100),
                          );
                          if (p != null) setState(() => end = p);
                        },
                        child: InputDecorator(decoration: const InputDecoration(labelText: 'Sampai'), child: Text(fmtDate(end))),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: busy
                      ? null
                      : () async {
                          setState(() => busy = true);
                          try {
                            await svc.shareReportCsv(start: start, end: end);
                          } finally {
                            if (mounted) setState(() => busy = false);
                          }
                        },
                  icon: const Icon(Icons.table_view),
                  label: const Text('Export & Share CSV'),
                ),
                const SizedBox(height: 8),
                Text(
                  'CSV berisi ringkasan per tanggal: omzet, HPP, laba kotor, biaya, laba bersih.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
