class Product {
  final String id;
  String name;
  String unit;
  double defaultMarginPercent;
  double activeSellPrice;
  double stockQty;
  double avgHpp;

  Product({
    required this.id,
    required this.name,
    required this.unit,
    required this.defaultMarginPercent,
    required this.activeSellPrice,
    required this.stockQty,
    required this.avgHpp,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'unit': unit,
        'defaultMarginPercent': defaultMarginPercent,
        'activeSellPrice': activeSellPrice,
        'stockQty': stockQty,
        'avgHpp': avgHpp,
      };

  static Product fromJson(Map<String, dynamic> j) => Product(
        id: j['id'] as String,
        name: j['name'] as String,
        unit: j['unit'] as String,
        defaultMarginPercent: (j['defaultMarginPercent'] as num).toDouble(),
        activeSellPrice: (j['activeSellPrice'] as num).toDouble(),
        stockQty: (j['stockQty'] as num).toDouble(),
        avgHpp: (j['avgHpp'] as num).toDouble(),
      );
}
