import 'package:flutter_test/flutter_test.dart';
import 'package:warung_sayur/core/calc.dart';

void main() {
  test('HPP weighted average', () {
    final hpp = hppWeightedAverage(totalQty: 15, totalCost: 200000);
    expect(hpp, closeTo(13333.3333, 0.01));
  });

  test('recommended sell price', () {
    final price = recommendedSellPrice(hpp: 10000, marginPercent: 20);
    expect(price, closeTo(12500, 0.0001));
  });
}
