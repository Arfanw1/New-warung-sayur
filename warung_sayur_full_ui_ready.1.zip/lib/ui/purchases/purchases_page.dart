import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../widgets/empty_state.dart';
import 'purchase_form.dart';

class PurchasesPage extends ConsumerWidget {
  const PurchasesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(purchaseRepoProvider);
    final items = repo.all();

    if (items.isEmpty) {
      return Stack(
        children: [
          const EmptyState(
            title: 'Belum ada pembelian',
            subtitle: 'Catat pembelian untuk mengisi stok dan menghitung HPP.',
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PurchaseFormPage())),
              child: const Icon(Icons.add),
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, i) {
            final p = items[i];
            final total = p.items.fold<double>(0, (sum, it) => sum + it.qty * it.buyPrice);
            return Card(
              child: ListTile(
                title: Text('Pembelian • ${fmtDateFromEpochDay(p.dateEpochDay)}'),
                subtitle: Text('${p.items.length} item • Total: ${fmtMoney(total)}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    await repo.remove(p.id);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pembelian dihapus')));
                  },
                ),
              ),
            );
          },
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PurchaseFormPage())),
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}
