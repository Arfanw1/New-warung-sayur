import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/product.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/number_field.dart';

class PurchaseFormPage extends ConsumerStatefulWidget {
  const PurchaseFormPage({super.key});

  @override
  ConsumerState<PurchaseFormPage> createState() => _PurchaseFormPageState();
}

class _PurchaseFormPageState extends ConsumerState<PurchaseFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();

  final List<_Row> rows = [_Row()];

  @override
  Widget build(BuildContext context) {
    final products = ref.watch(productRepoProvider).all();
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Pembelian')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            if (products.isEmpty) const Text('Belum ada produk. Tambahkan produk dulu di tab Produk.'),
            ...List.generate(rows.length, (i) => _buildRow(products, i)),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => setState(() => rows.add(_Row())),
              icon: const Icon(Icons.add),
              label: const Text('Tambah item'),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: products.isEmpty ? null : _save,
              icon: const Icon(Icons.save),
              label: const Text('Simpan Pembelian'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(List<Product> products, int i) {
    final r = rows[i];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: r.productId,
              decoration: const InputDecoration(labelText: 'Produk'),
              items: products.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))).toList(),
              onChanged: (v) => setState(() => r.productId = v),
              validator: (v) => (v == null || v.isEmpty) ? 'Pilih produk' : null,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: NumberField(controller: r.qtyC, label: 'Qty', requiredField: true)),
                const SizedBox(width: 12),
                Expanded(
                  child: NumberField(
                    controller: r.priceC,
                    label: 'Harga beli /unit',
                    requiredField: true,
                    integerOnly: true,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: rows.length <= 1 ? null : () => setState(() => rows.removeAt(i)),
                icon: const Icon(Icons.delete_outline),
                label: const Text('Hapus item'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final items = <PurchaseItem>[];
    for (final r in rows) {
      final qty = double.tryParse(r.qtyC.text.trim()) ?? 0;
      final price = double.tryParse(r.priceC.text.trim()) ?? 0;
      if (r.productId == null) continue;
      if (qty <= 0) continue;
      items.add(PurchaseItem(productId: r.productId!, qty: qty, buyPrice: price));
    }

    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Isi minimal 1 item pembelian')));
      return;
    }

    final purchase = Purchase(id: newId('buy'), dateEpochDay: epochDay(date), items: items);
    await ref.read(purchaseRepoProvider).add(purchase);

    if (!mounted) return;
    Navigator.pop(context);
  }
}

class _Row {
  String? productId;
  final qtyC = TextEditingController();
  final priceC = TextEditingController();
}
