import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../data/repositories/reporting.dart';
import '../widgets/date_picker_field.dart';

class ReportsPage extends ConsumerStatefulWidget {
  const ReportsPage({super.key});

  @override
  ConsumerState<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends ConsumerState<ReportsPage> {
  DateTime start = DateTime.now().subtract(const Duration(days: 6));
  DateTime end = DateTime.now();

  int _toEpochDay(DateTime dt) {
    final utc = DateTime.utc(dt.year, dt.month, dt.day);
    final base = DateTime.utc(1970, 1, 1);
    return utc.difference(base).inDays;
  }

  @override
  Widget build(BuildContext context) {
    final sales = ref.watch(salesBoxProvider).values;
    final expenses = ref.watch(expensesBoxProvider).values;

    final s0 = _toEpochDay(start);
    final s1 = _toEpochDay(end);

    final salesInRange = sales.where((s) => s.dateEpochDay >= s0 && s.dateEpochDay <= s1);
    final expInRange = expenses.where((e) => e.dateEpochDay >= s0 && e.dateEpochDay <= s1);

    final summary = summarize(sales: salesInRange, expenses: expInRange);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Expanded(child: DatePickerField(value: start, onChanged: (d) => setState(() => start = d), label: 'Mulai')),
            const SizedBox(width: 12),
            Expanded(child: DatePickerField(value: end, onChanged: (d) => setState(() => end = d), label: 'Sampai')),
          ],
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Ringkasan', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _row('Omzet', fmtMoney(summary.omzet)),
                _row('Total HPP', fmtMoney(summary.totalHpp)),
                _row('Laba Kotor', fmtMoney(summary.labaKotor)),
                const Divider(),
                _row('Total Biaya', fmtMoney(summary.totalBiaya)),
                _row('Laba Bersih', fmtMoney(summary.labaBersih)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(k), Text(v, style: const TextStyle(fontWeight: FontWeight.w600))],
        ),
      );
}
