import 'package:hive/hive.dart';
import '../../domain/models/expense.dart';

class ExpenseRepo {
  final Box<Expense> box;
  ExpenseRepo(this.box);

  List<Expense> all() => box.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));
  Future<void> add(Expense e) => box.put(e.id, e);
  Future<void> remove(String id) => box.delete(id);
}
