import 'package:hive/hive.dart';
import '../../domain/models/debt.dart';

class DebtRepo {
  final Box<Debt> box;
  DebtRepo(this.box);

  List<Debt> all() => box.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));
  Future<void> add(Debt d) => box.put(d.id, d);
  Future<void> remove(String id) => box.delete(id);

  Future<void> addPayment(String id, double amount) async {
    final d = box.get(id);
    if (d == null) return;
    d.paid = (d.paid + amount).clamp(0, d.principal);
    await box.put(d.id, d);
  }
}
