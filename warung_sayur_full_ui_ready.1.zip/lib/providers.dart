import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';

import 'domain/models/product.dart';
import 'domain/models/purchase.dart';
import 'domain/models/sale.dart';
import 'domain/models/expense.dart';
import 'domain/models/debt.dart';

import 'data/repositories/product_repo.dart';
import 'data/repositories/purchase_repo.dart';
import 'data/repositories/sales_repo.dart';
import 'data/repositories/expense_repo.dart';
import 'data/repositories/debt_repo.dart';
import 'data/services/backup_service.dart';

final productsBoxProvider = Provider<Box<Product>>((ref) => throw UnimplementedError());
final purchasesBoxProvider = Provider<Box<Purchase>>((ref) => throw UnimplementedError());
final salesBoxProvider = Provider<Box<Sale>>((ref) => throw UnimplementedError());
final expensesBoxProvider = Provider<Box<Expense>>((ref) => throw UnimplementedError());
final debtsBoxProvider = Provider<Box<Debt>>((ref) => throw UnimplementedError());

final productRepoProvider = Provider<ProductRepo>((ref) => ProductRepo(ref.watch(productsBoxProvider)));
final purchaseRepoProvider =
    Provider<PurchaseRepo>((ref) => PurchaseRepo(ref.watch(purchasesBoxProvider), ref.watch(productsBoxProvider)));
final salesRepoProvider = Provider<SalesRepo>((ref) => SalesRepo(ref.watch(salesBoxProvider), ref.watch(productsBoxProvider)));
final expenseRepoProvider = Provider<ExpenseRepo>((ref) => ExpenseRepo(ref.watch(expensesBoxProvider)));
final debtRepoProvider = Provider<DebtRepo>((ref) => DebtRepo(ref.watch(debtsBoxProvider)));

final backupServiceProvider = Provider<BackupService>((ref) => BackupService(
      products: ref.watch(productsBoxProvider),
      purchases: ref.watch(purchasesBoxProvider),
      sales: ref.watch(salesBoxProvider),
      expenses: ref.watch(expensesBoxProvider),
      debts: ref.watch(debtsBoxProvider),
    ));
