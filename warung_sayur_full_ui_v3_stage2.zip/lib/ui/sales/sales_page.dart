import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../widgets/empty_state.dart';
import 'sale_form.dart';

class SalesPage extends ConsumerStatefulWidget {
  const SalesPage({super.key});

  @override
  ConsumerState<SalesPage> createState() => _SalesPageState();
}

class _SalesPageState extends ConsumerState<SalesPage> {
  final qC = TextEditingController();
  DateTimeRange? range;

  @override
  void dispose() {
    qC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ref.watch(salesRepoProvider);
    final itemsAll = repo.all();
    final productsRepo = ref.watch(productRepoProvider);

    final q = qC.text.trim().toLowerCase();

    final filtered = itemsAll.where((s) {
      if (range != null) {
        final d = fromEpochDay(s.dateEpochDay);
        final afterStart = !d.isBefore(DateTime(range!.start.year, range!.start.month, range!.start.day));
        final beforeEnd = !d.isAfter(DateTime(range!.end.year, range!.end.month, range!.end.day));
        if (!afterStart || !beforeEnd) return false;
      }
      if (q.isEmpty) return true;
      for (final it in s.items) {
        final pr = productsRepo.getById(it.productId);
        final name = (pr?.name ?? '').toLowerCase();
        if (name.contains(q)) return true;
      }
      return false;
    }).toList();

    if (itemsAll.isEmpty) {
      return Stack(
        children: [
          const EmptyState(
            title: 'Belum ada penjualan',
            subtitle: 'Catat transaksi penjualan untuk laporan omzet & laba.',
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SaleFormPage())),
              child: const Icon(Icons.add),
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: qC,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search),
                        hintText: 'Cari produk...',
                        suffixIcon: q.isEmpty
                            ? null
                            : IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () => setState(() => qC.clear()),
                              ),
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    tooltip: 'Filter tanggal',
                    icon: Icon(range == null ? Icons.filter_alt_outlined : Icons.filter_alt),
                    onPressed: () async {
                      final picked = await showDateRangePicker(
                        context: context,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                        initialDateRange: range,
                      );
                      setState(() => range = picked);
                    },
                  ),
                ],
              ),
            ),
            if (range != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Periode: ${fmtDate(range!.start)} – ${fmtDate(range!.end)}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () => setState(() => range = null),
                      icon: const Icon(Icons.close, size: 18),
                      label: const Text('Reset'),
                    ),
                  ],
                ),
              ),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(child: Text('Tidak ada data yang cocok.'))
                  : ListView.separated(
                      padding: const EdgeInsets.all(12),
                      itemCount: filtered.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (context, i) {
                        final s = filtered[i];
                        final totalQty = s.items.fold<double>(0, (sum, it) => sum + it.qty);
                        final summary = s.items.map((it) {
                          final pr = productsRepo.getById(it.productId);
                          final name = pr?.name ?? 'Produk';
                          final unit = pr?.unit ?? '';
                          return '$name ${it.qty.toStringAsFixed(2)} $unit';
                        }).join(', ');

                        return Card(
                          child: ListTile(
                            title: Text('Penjualan • ${fmtDateFromEpochDay(s.dateEpochDay)}'),
                            subtitle: Text(
                              'Qty total: ${totalQty.toStringAsFixed(2)} • Total: ${fmtMoney(s.totalSales)} • HPP: ${fmtMoney(s.totalHpp)}\n$summary',
                            ),
                            isThreeLine: true,
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () async {
                                await repo.remove(s.id);
                                if (mounted) {
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(const SnackBar(content: Text('Penjualan dihapus')));
                                }
                              },
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SaleFormPage())),
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}
