class PurchaseItem {
  String productId;
  double qty;
  double buyPrice;

  PurchaseItem({required this.productId, required this.qty, required this.buyPrice});

  Map<String, dynamic> toJson() => {'productId': productId, 'qty': qty, 'buyPrice': buyPrice};

  static PurchaseItem fromJson(Map<String, dynamic> j) => PurchaseItem(
        productId: j['productId'] as String,
        qty: (j['qty'] as num).toDouble(),
        buyPrice: (j['buyPrice'] as num).toDouble(),
      );
}

class Purchase {
  final String id;
  int dateEpochDay;
  /// Nama supplier (opsional). Tahap 2: supplier sederhana.
  String supplier;
  List<PurchaseItem> items;

  Purchase({required this.id, required this.dateEpochDay, required this.items, this.supplier = ''});

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateEpochDay': dateEpochDay,
        'supplier': supplier,
        'items': items.map((e) => e.toJson()).toList(),
      };

  static Purchase fromJson(Map<String, dynamic> j) => Purchase(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        supplier: (j['supplier'] ?? '') as String,
        items: (j['items'] as List).map((e) => PurchaseItem.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}
