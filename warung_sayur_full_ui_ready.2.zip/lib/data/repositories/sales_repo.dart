import 'package:hive/hive.dart';
import '../../domain/models/product.dart';
import '../../domain/models/sale.dart';

class SalesRepo {
  final Box<Sale> salesBox;
  final Box<Product> productsBox;

  SalesRepo(this.salesBox, this.productsBox);

  List<Sale> all() => salesBox.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(Sale sale) async {
    for (final item in sale.items) {
      final product = productsBox.get(item.productId);
      if (product == null) continue;
      product.stockQty = (product.stockQty - item.qty).clamp(0, double.infinity);
      await product.save();
    }
    await productsBox.put(product.id, product);
  }

  Future<void> remove(String id) async => salesBox.delete(id);
}
