import 'package:hive/hive.dart';

import '../../domain/models/product.dart';
import '../../domain/models/purchase.dart';
import '../../domain/models/sale.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/debt.dart';

class Boxes {
  static const products = 'products';
  static const purchases = 'purchases';
  static const sales = 'sales';
  static const expenses = 'expenses';
  static const debts = 'debts';
}

Future<Box<Product>> openProducts() => Hive.openBox<Product>(Boxes.products);
Future<Box<Purchase>> openPurchases() => Hive.openBox<Purchase>(Boxes.purchases);
Future<Box<Sale>> openSales() => Hive.openBox<Sale>(Boxes.sales);
Future<Box<Expense>> openExpenses() => Hive.openBox<Expense>(Boxes.expenses);
Future<Box<Debt>> openDebts() => Hive.openBox<Debt>(Boxes.debts);
