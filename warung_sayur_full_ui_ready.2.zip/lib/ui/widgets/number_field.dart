import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NumberField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final bool integerOnly;
  final bool requiredField;

  const NumberField({
    super.key,
    required this.controller,
    required this.label,
    this.integerOnly = false,
    this.requiredField = false,
  });

  @override
  Widget build(BuildContext context) {
    final fmt = <TextInputFormatter>[
      FilteringTextInputFormatter.allow(RegExp(integerOnly ? r'[0-9]' : r'[0-9\.]')),
    ];
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: fmt,
      decoration: InputDecoration(labelText: label),
      validator: (v) {
        if (!requiredField) return null;
        if (v == null || v.trim().isEmpty) return 'Wajib diisi';
        final n = double.tryParse(v.trim());
        if (n == null) return 'Angka tidak valid';
        return null;
      },
    );
  }
}
