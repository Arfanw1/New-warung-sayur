import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/dates.dart';
import '../../providers.dart';
import '../../domain/models/stock_movement.dart';
import 'stock_adjustment_page.dart';

class ProductDetailPage extends ConsumerWidget {
  final String productId;
  const ProductDetailPage({super.key, required this.productId});

  String _titleForType(String t) {
    switch (t) {
      case 'purchase':
        return 'Pembelian';
      case 'sale':
        return 'Penjualan';
      case 'adjust':
        return 'Penyesuaian';
      default:
        return t;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(productRepoProvider).getById(productId);
    if (p == null) return const Scaffold(body: Center(child: Text('Produk tidak ditemukan')));

    final movements = ref.watch(movementRepoProvider).byProduct(productId).take(50).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(p.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune),
            tooltip: 'Penyesuaian stok',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => StockAdjustmentPage(productId: productId)),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: Text(p.name),
              subtitle: Text('Stok: ${p.stockQty.toStringAsFixed(2)} ${p.unit}\nHPP: ${fmtMoney(p.avgHpp)}\nHarga jual: ${fmtMoney(p.activeSellPrice)}'),
              isThreeLine: true,
            ),
          ),
          const SizedBox(height: 12),
          Text('Riwayat Stok', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (movements.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Belum ada riwayat stok.'))),
          ...movements.map((m) => Card(
                child: ListTile(
                  title: Text(_titleForType(m.type)),
                  subtitle: Text('${fmtDateFromEpochDay(m.dateEpochDay)} • ${m.note}'),
                  trailing: Text(
                    (m.qtyDelta >= 0 ? '+' : '') + m.qtyDelta.toStringAsFixed(2) + ' ' + p.unit,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: m.qtyDelta >= 0 ? Colors.green : Colors.red,
                    ),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
