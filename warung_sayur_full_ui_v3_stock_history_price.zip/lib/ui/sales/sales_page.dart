import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';
import '../widgets/empty_state.dart';
import 'sale_form.dart';

class SalesPage extends ConsumerWidget {
  const SalesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(salesRepoProvider);
    final items = repo.all();

    if (items.isEmpty) {
      return Stack(
        children: [
          const EmptyState(
            title: 'Belum ada penjualan',
            subtitle: 'Catat transaksi penjualan untuk laporan omzet & laba.',
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SaleFormPage())),
              child: const Icon(Icons.add),
            ),
          ),
        ],
      );
    }

    return Stack(
      children: [
        ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, i) {
            final s = items[i];
            final productsRepo = ref.watch(productRepoProvider);

            final totalQty = s.items.fold<double>(0, (sum, it) => sum + it.qty);

            final summary = s.items.map((it) {
              final pr = productsRepo.getById(it.productId);
              final name = pr?.name ?? 'Produk';
              final unit = pr?.unit ?? '';
              return '$name ${it.qty.toStringAsFixed(2)} $unit';
            }).join(', ');

            return Card(
              child: ListTile(
                title: Text('Penjualan • ${fmtDateFromEpochDay(s.dateEpochDay)}'),
                subtitle: Text(
                  'Qty total: ${totalQty.toStringAsFixed(2)} • Total: ${fmtMoney(s.totalSales)} • HPP: ${fmtMoney(s.totalHpp)}
$summary',
                ),
                isThreeLine: true,
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    await repo.remove(s.id);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Penjualan dihapus')));
                  },
                ),
              ),
            );
          },
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SaleFormPage())),
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}
