import 'package:hive/hive.dart';

import '../../domain/models/activity_log.dart';

class ActivityLogRepo {
  final Box<ActivityLog> box;
  ActivityLogRepo(this.box);

  List<ActivityLog> all() => box.values.toList()
    ..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

  Future<void> add(ActivityLog log) => box.put(log.id, log);

  Future<void> clear() => box.clear();
}
