import 'package:hive/hive.dart';

import '../../domain/models/cash_entry.dart';

class CashRepo {
  final Box<CashEntry> cashBox;
  CashRepo(this.cashBox);

  List<CashEntry> all() => cashBox.values.toList()
    ..sort((a, b) {
      final d = b.dateEpochDay.compareTo(a.dateEpochDay);
      if (d != 0) return d;
      return b.id.compareTo(a.id);
    });

  Future<void> add(CashEntry e) => cashBox.put(e.id, e);
  Future<void> remove(String id) => cashBox.delete(id);

  Future<void> removeByRef(String source, String refId) async {
    final keys = <dynamic>[];
    for (final entry in cashBox.toMap().entries) {
      final v = entry.value;
      if (v.source == source && v.refId == refId) keys.add(entry.key);
    }
    for (final k in keys) {
      await cashBox.delete(k);
    }
  }
}
