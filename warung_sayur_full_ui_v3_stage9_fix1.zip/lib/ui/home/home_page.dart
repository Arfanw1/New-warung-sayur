import 'package:flutter/material.dart';

import '../dashboard/dashboard_page.dart';
import '../products/products_page.dart';
import '../purchases/purchases_page.dart';
import '../sales/sales_page.dart';
import '../cash/cash_page.dart';

import '../expenses/expenses_page.dart';
import '../debts/debts_page.dart';
import '../reports/reports_page.dart';
import '../settings/backup_page.dart';
import '../analytics/analytics_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  // Bottom navigation: menu inti harian
  final pages = const [
    DashboardPage(),
    ProductsPage(),
    SalesPage(),
    PurchasesPage(),
    CashPage(),
  ];

  final labels = const ['Dashboard', 'Produk', 'Penjualan', 'Pembelian', 'Kas'];

  final iconAssets = const [
    'assets/icons/ic_dashboard.png',
    'assets/icons/ic_products.png',
    'assets/icons/ic_sales.png',
    'assets/icons/ic_purchases.png',
    'assets/icons/ic_cash.png',
  ];

  Widget _navIcon(String asset) => Image.asset(asset, width: 24, height: 24);

  void _openDrawerPage(String title, Widget page) {
    Navigator.of(context).pop(); // close drawer
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(title: Text(title)),
          body: page,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(labels[index])),
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            children: [
              const ListTile(
                title: Text('Menu'),
              ),
              ListTile(
                leading: const Icon(Icons.receipt_long),
                title: const Text('Laporan'),
                onTap: () => _openDrawerPage('Laporan', const ReportsPage()),
              ),
              ListTile(
                leading: const Icon(Icons.insights),
                title: const Text('Analytics'),
                onTap: () => _openDrawerPage('Analytics', const AnalyticsPage()),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.payments_outlined),
                title: const Text('Hutang'),
                onTap: () => _openDrawerPage('Hutang', const DebtsPage()),
              ),
              ListTile(
                leading: const Icon(Icons.request_quote_outlined),
                title: const Text('Biaya'),
                onTap: () => _openDrawerPage('Biaya', const ExpensesPage()),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.backup_outlined),
                title: const Text('Backup'),
                onTap: () => _openDrawerPage('Backup', const BackupPage()),
              ),
            ],
          ),
        ),
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: List.generate(
          labels.length,
          (i) => NavigationDestination(
            icon: _navIcon(iconAssets[i]),
            selectedIcon: _navIcon(iconAssets[i]),
            label: labels[i],
          ),
        ),
      ),
    );
  }
}
