import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:hive/hive.dart';

import '../../domain/models/app_settings.dart';

class SettingsRepo {
  final Box<AppSettings> box;
  SettingsRepo(this.box);

  static const _id = 'app';

  AppSettings get() {
    return box.get(_id) ?? AppSettings(id: _id, pinEnabled: false, pinHash: '');
  }

  Future<void> setPin(String pin) async {
    final hash = sha256.convert(utf8.encode(pin)).toString();
    await box.put(_id, AppSettings(id: _id, pinEnabled: true, pinHash: hash));
  }

  Future<void> disablePin() async {
    await box.put(_id, AppSettings(id: _id, pinEnabled: false, pinHash: ''));
  }

  bool verifyPin(String pin) {
    final s = get();
    if (!s.pinEnabled) return true;
    final hash = sha256.convert(utf8.encode(pin)).toString();
    return hash == s.pinHash;
  }
}
