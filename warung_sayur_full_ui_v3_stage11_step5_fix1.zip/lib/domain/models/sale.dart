class SaleItem {
  String productId;
  double qty;
  double sellPrice;
  double hppAtSale;

  SaleItem({required this.productId, required this.qty, required this.sellPrice, required this.hppAtSale});

  double get total => qty * sellPrice;
  double get totalHpp => qty * hppAtSale;

  Map<String, dynamic> toJson() =>
      {'productId': productId, 'qty': qty, 'sellPrice': sellPrice, 'hppAtSale': hppAtSale};

  static SaleItem fromJson(Map<String, dynamic> j) => SaleItem(
        productId: j['productId'] as String,
        qty: (j['qty'] as num).toDouble(),
        sellPrice: (j['sellPrice'] as num).toDouble(),
        hppAtSale: (j['hppAtSale'] as num).toDouble(),
      );
}

class Sale {
  final String id;
  int dateEpochDay;
  List<SaleItem> items;
  String paymentMethod; // Cash/QRIS/Transfer/Hutang

  Sale({required this.id, required this.dateEpochDay, required this.items, required this.paymentMethod});

  double get totalSales => items.fold(0.0, (p, e) => p + e.total);
  double get totalHpp => items.fold(0.0, (p, e) => p + e.totalHpp);

  Map<String, dynamic> toJson() => {
        'id': id,
        'dateEpochDay': dateEpochDay,
        'paymentMethod': paymentMethod,
        'items': items.map((e) => e.toJson()).toList(),
      };

  static Sale fromJson(Map<String, dynamic> j) => Sale(
        id: j['id'] as String,
        dateEpochDay: j['dateEpochDay'] as int,
        paymentMethod: (j['paymentMethod'] as String?) ?? 'Cash',
        items: (j['items'] as List).map((e) => SaleItem.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}
