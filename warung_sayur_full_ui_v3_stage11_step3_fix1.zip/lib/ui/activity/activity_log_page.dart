import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers.dart';
import '../../core/dates.dart';

class ActivityLogPage extends ConsumerWidget {
  const ActivityLogPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final logs = ref.watch(activityLogsBoxProvider).values.toList()
      ..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));

    if (logs.isEmpty) {
      return const Center(child: Text('Belum ada log aktivitas.'));
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: logs.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final l = logs[i];
        return Card(
          child: ListTile(
            title: Text(l.type),
            subtitle: Text(fmtDateFromEpochDay(l.dateEpochDay)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text(l.type),
                  content: SingleChildScrollView(
                    child: Text(
                      (l.newJson.isNotEmpty ? l.newJson : '') +
                          (l.oldJson.isNotEmpty ? '\n\nOLD:\n${l.oldJson}' : ''),
                    ),
                  ),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup')),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }
}
