import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:convert';

import '../../providers.dart';
import '../../core/dates.dart';
import '../../core/ids.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/activity_log.dart';
import '../widgets/empty_state.dart';
import '../widgets/date_picker_field.dart';
import '../widgets/money_field.dart';

class ExpensesPage extends ConsumerWidget {
  const ExpensesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final repo = ref.watch(expenseRepoProvider);
    final items = repo.all();

    return Stack(
      children: [
        items.isEmpty
            ? const EmptyState(title: 'Belum ada biaya', subtitle: 'Catat biaya harian (transport, plastik, dll).')
            : ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) {
                  final e = items[i];
                  return Card(
                    child: ListTile(
                      title: Text(e.note),
                      subtitle: Text('${fmtDateFromEpochDay(e.dateEpochDay)} • ${e.paymentMethod} • ${fmtMoney(e.amount)}'),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => ExpenseFormPage(initial: e)),
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.edit_outlined),
                        tooltip: 'Edit',
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => ExpenseFormPage(initial: e)),
                        ),
                      ),
                      leading: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        tooltip: 'Hapus',
                        onPressed: () async {
                          final messenger = ScaffoldMessenger.of(context);
                          await repo.remove(e.id);
                          messenger.showSnackBar(const SnackBar(content: Text('Biaya dihapus')));
                        },
                      ),
                    ),
                  );
                },
              ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExpenseFormPage())),
            child: Image.asset('assets/icons/ic_add.png', width: 24, height: 24),
          ),
        ),
      ],
    );
  }
}

class ExpenseFormPage extends ConsumerStatefulWidget {
  final Expense? initial;
  const ExpenseFormPage({super.key, this.initial});

  @override
  ConsumerState<ExpenseFormPage> createState() => _ExpenseFormPageState();
}

class _ExpenseFormPageState extends ConsumerState<ExpenseFormPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime date = DateTime.now();
  final noteC = TextEditingController();
  final amountC = TextEditingController();
  String paymentMethod = 'Cash';

  @override
  void initState() {
    super.initState();
    final init = widget.initial;
    if (init != null) {
      date = fromEpochDay(init.dateEpochDay);
      noteC.text = init.note;
      amountC.text = init.amount.toStringAsFixed(0);
      paymentMethod = init.paymentMethod;
    }
  }

  @override
  void dispose() {
    noteC.dispose();
    amountC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'Tambah Biaya' : 'Edit Biaya')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePickerField(value: date, onChanged: (d) => setState(() => date = d), label: 'Tanggal'),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: paymentMethod,
              decoration: const InputDecoration(labelText: 'Metode pembayaran'),
              items: const [
                DropdownMenuItem(value: 'Cash', child: Text('Cash')),
                DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
              ],
              onChanged: (v) => setState(() => paymentMethod = v ?? 'Cash'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: noteC,
              decoration: const InputDecoration(labelText: 'Keterangan'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 12),
            MoneyField(controller: amountC, label: 'Jumlah biaya', requiredField: true),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(widget.initial == null ? 'Simpan' : 'Simpan Perubahan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final amount = (parseRupiah(amountC.text.trim()) ?? 0).toDouble();
    final isEdit = widget.initial != null;
    final id = widget.initial?.id ?? newId('exp');
    final e = Expense(
      id: id,
      dateEpochDay: epochDay(date),
      note: noteC.text.trim(),
      amount: amount,
      paymentMethod: paymentMethod,
    );

    if (isEdit) {
      final old = widget.initial!;
      await ref.read(expenseRepoProvider).remove(old.id);
      await ref.read(expenseRepoProvider).add(e);
      await ref.read(activityLogRepoProvider).add(
            ActivityLog(
              id: newId('log'),
              dateEpochDay: e.dateEpochDay,
              type: 'edit_expense',
              refId: old.id,
              oldJson: jsonEncode(old.toJson()),
              newJson: jsonEncode(e.toJson()),
            ),
          );
    } else {
      await ref.read(expenseRepoProvider).add(e);
    }
    if (!mounted) return;
    Navigator.pop(context);
  }
}
