import 'package:hive/hive.dart';

/// Tahap 11: penyimpanan setting tambahan tanpa migrasi model.
class MetaRepo {
  final Box box;
  MetaRepo(this.box);

  static const kRole = 'role'; // 'admin' | 'kasir'
  static const kAutoBackupEnabled = 'auto_backup_enabled';
  static const kAutoBackupDays = 'auto_backup_days'; // int
  static const kLastAutoBackupEpochMs = 'last_auto_backup_ms'; // int

  String get role => (box.get(kRole) as String?) ?? 'admin';
  Future<void> setRole(String role) => box.put(kRole, role);

  bool get autoBackupEnabled => (box.get(kAutoBackupEnabled) as bool?) ?? false;
  Future<void> setAutoBackupEnabled(bool v) => box.put(kAutoBackupEnabled, v);

  int get autoBackupDays => (box.get(kAutoBackupDays) as int?) ?? 7;
  Future<void> setAutoBackupDays(int days) => box.put(kAutoBackupDays, days);

  int get lastAutoBackupEpochMs => (box.get(kLastAutoBackupEpochMs) as int?) ?? 0;
  Future<void> setLastAutoBackupEpochMs(int ms) => box.put(kLastAutoBackupEpochMs, ms);
}
