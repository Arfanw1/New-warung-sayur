import 'package:hive/hive.dart';
import '../../domain/models/expense.dart';
import '../../domain/models/cash_entry.dart';
import '../../core/ids.dart';

class ExpenseRepo {
  final Box<Expense> box;
  final Box<CashEntry> cashBox;
  ExpenseRepo(this.box, this.cashBox);

  List<Expense> all() => box.values.toList()..sort((a, b) => b.dateEpochDay.compareTo(a.dateEpochDay));
  Future<void> add(Expense e) async {
    await box.put(e.id, e);
    final cashId = newId('cash');
    await cashBox.put(
      cashId,
      CashEntry(
        id: cashId,
        dateEpochDay: e.dateEpochDay,
        direction: 'out',
        source: 'expense',
        method: e.paymentMethod,
        note: e.note,
        amount: e.amount,
        refId: e.id,
      ),
    );
  }

  Future<void> remove(String id) async {
    await box.delete(id);
    final keys = <dynamic>[];
    for (final entry in cashBox.toMap().entries) {
      final c = entry.value;
      if (c.source == 'expense' && c.refId == id) keys.add(entry.key);
    }
    for (final k in keys) {
      await cashBox.delete(k);
    }
  }
}
